import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  DEFAULT_CONTENT_INTELLIGENCE_PROFILE,
  normalizeContentIntelligenceProfile,
  profileDurationRange,
  type ContentIntelligenceProfile
} from '../../src/shared/analysis/content-intelligence'
import type { TranscriptSegment } from '../../src/shared/types'
import { runHeuristicAnalysis } from '../../src/main/services/ai/heuristic'

const ANALYZED_AT = '2026-10-03T12:00:00.000Z'

function profile(patch: Partial<ContentIntelligenceProfile>): ContentIntelligenceProfile {
  return normalizeContentIntelligenceProfile({ ...DEFAULT_CONTENT_INTELLIGENCE_PROFILE, ...patch })
}

function transcript(lines: string[], options: { step?: number; start?: number; speakers?: boolean } = {}): TranscriptSegment[] {
  const step = options.step ?? 6
  const start = options.start ?? 0
  return lines.map((text, index) => ({
    id: index + 1,
    startTime: start + index * step,
    endTime: start + (index + 1) * step - 0.15,
    text,
    speaker: options.speakers ? `speaker-${index % 2 + 1}` : null,
    confidence: 0.96,
    words: null
  }))
}

function analyze(segments: TranscriptSegment[], selected: ContentIntelligenceProfile) {
  const range = profileDurationRange(selected)
  return runHeuristicAnalysis(segments, {
    minSeconds: range.min,
    maxSeconds: range.max,
    maxCandidates: selected.requestedCandidates,
    intelligenceProfile: selected,
    engine: 'heuristic-local',
    analyzedAt: ANALYZED_AT
  })
}

afterEach(() => {
  vi.unstubAllGlobals()
  vi.restoreAllMocks()
})

describe('Content Intelligence synthetic cases A–G', () => {
  it('A — favors a relationship breakup story when category, subcategory, and moment type are selected', () => {
    const selected = profile({
      categoryId: 'relationships-dating',
      subcategoryIds: ['breakups-cheating'],
      momentTypeIds: ['emotional-story'],
      durationMode: 'preset',
      durationPreset: '30-45',
      requestedCandidates: 5,
      minimumQualityScore: 25,
      sensitivity: 'low'
    })
    const segments = transcript([
      'My relationship looked perfect from the outside, but I was afraid to admit how lonely I felt.',
      'When my partner and I started dating, we promised that honesty would always come first.',
      'After our breakup, I discovered they had been cheating for months and I felt completely betrayed.',
      'I cried in the car because I thought losing that relationship meant losing my whole future.',
      'My sister reminded me that love should feel safe, and that conversation helped me breathe again.',
      'Eventually I stopped blaming myself and learned to ask for respect instead of accepting excuses.',
      'The hardest part was telling our families that the marriage plans were over.',
      'In the end, I chose my own wellbeing and realized leaving was the first honest thing I had done.'
    ])
    const candidates = analyze(segments, selected)
    expect(candidates.length).toBeGreaterThan(0)
    expect(candidates[0].intelligence?.categoryId).toBe('relationships-dating')
    expect(candidates[0].intelligence?.scores.categoryFit).toBeGreaterThanOrEqual(50)
    expect(candidates[0].intelligence?.momentTypeId).toBe('emotional-story')
    expect(candidates[0].intelligence?.scores.emotion).toBeGreaterThan(40)
    expect(candidates[0].intelligence?.scores.completeness).toBeGreaterThan(40)
  })

  it('B — ranks actionable entrepreneurship advice for an entrepreneur audience', () => {
    const selected = profile({
      categoryId: 'money-business',
      subcategoryIds: ['entrepreneurship'],
      momentTypeIds: ['practical-advice'],
      audienceId: 'entrepreneurs',
      durationMode: 'preset',
      durationPreset: '30-45',
      discoveryMode: 'educational-value',
      requestedCandidates: 5,
      minimumQualityScore: 25,
      sensitivity: 'low'
    })
    const segments = transcript([
      'When I founded my startup, I spent too much money building a product before talking to customers.',
      'A small business does not need a perfect office, it needs one useful offer that solves a real problem.',
      'You should interview ten potential customers and write down the exact words they use to describe the problem.',
      'Then test a simple price, because revenue tells you more than compliments from friends.',
      'Our first business model failed, but the customer interviews showed us a better market opportunity.',
      'Track cash flow every week and negotiate supplier terms before you commit to a large order.',
      'For example, we changed one service package and increased our profit without hiring anyone.',
      'My advice is to validate demand first, protect your runway, and only then invest in growth.'
    ])
    const candidates = analyze(segments, selected)
    expect(candidates.length).toBeGreaterThan(0)
    expect(candidates[0].intelligence?.categoryId).toBe('money-business')
    expect(candidates[0].intelligence?.scores.categoryFit).toBeGreaterThanOrEqual(50)
    expect(candidates[0].intelligence?.momentTypeId).toBe('practical-advice')
    expect(candidates[0].intelligence?.scores.informationDensity).toBeGreaterThan(45)
    expect(candidates[0].intelligence?.scores.audienceFit).toBeGreaterThan(70)
  })

  it('C — finds a clean funny exchange using speaker turns and payoff, not only topic words', () => {
    const selected = profile({
      categoryId: 'comedy-entertainment',
      subcategoryIds: ['unexpected-answers', 'funny-conversations'],
      momentTypeIds: ['funny-unexpected-moment'],
      durationMode: 'preset',
      durationPreset: '15-30',
      requestedCandidates: 5,
      minimumQualityScore: 20,
      sensitivity: 'low'
    })
    const segments = transcript([
      'The host asked what the most organized thing in my kitchen was.',
      'I said the fridge, because everything inside it is technically in a different container.',
      'My friend asked if I had a system for the containers or just a drawer full of chaos.',
      'I said wait what, the containers are organized by how loudly their lids refuse to fit.',
      'Everyone started laughing, and then I admitted that one lid belongs to a pot from another apartment.',
      'The host said that is not a kitchen system, that is a very small mystery with a punchline.'
    ], { step: 4.5, speakers: true })
    const candidates = analyze(segments, selected)
    expect(candidates.length).toBeGreaterThan(0)
    expect(candidates[0].intelligence?.momentTypeId).toBe('funny-unexpected-moment')
    expect(candidates[0].intelligence?.scores.audioVisualInterest).not.toBeNull()
    expect(candidates[0].intelligence?.audioSignalsAvailable).toBe(true)
    expect(candidates[0].intelligence?.scores.payoff).toBeGreaterThan(40)
  })

  it('D — keeps a long survival narrative together when the selected type needs a complete story', () => {
    const selected = profile({
      categoryId: 'storytelling',
      subcategoryIds: ['survival', 'unexpected-events'],
      momentTypeIds: ['complete-story'],
      durationMode: 'preset',
      durationPreset: '90-180',
      requestedCandidates: 5,
      minimumQualityScore: 20,
      sensitivity: 'low',
      discoveryMode: 'storytelling'
    })
    const segments = transcript([
      'When I was twenty, our small boat lost power several miles from shore during a sudden storm.',
      'At first we thought the radio had simply lost its signal, so we checked every cable twice.',
      'Then the rain became so heavy that we could barely see the lights from the coast.',
      'My brother stayed calm and tied a bright jacket to the highest point on the boat.',
      'I was terrified because the waves kept pushing us farther away from the route we knew.',
      'We tried the engine again, but the battery was almost dead and the wind turned us sideways.',
      'After midnight a fishing crew noticed the jacket moving between the waves and changed direction.',
      'They called our names over the radio, and that was the first moment I believed someone could hear us.',
      'We followed their instructions slowly while they kept a light pointed toward our little boat.',
      'The rescue crew reached us before sunrise, although the nearest harbour was still hours away.',
      'I remember stepping onto the larger boat and realizing my hands had been shaking the whole night.',
      'The next morning we learned that the storm had closed the main channel behind us.',
      'Our family met us at the dock, and nobody cared that we had lost the boat equipment.',
      'For weeks I replayed the choices we made and wondered whether we should have turned back sooner.',
      'Eventually I understood that asking for help early is not the same as giving up.',
      'That experience changed how I prepare, because now we check every signal and safety light before leaving.',
      'The story ended with a repaired boat, a new radio, and a promise to listen when the weather shifts.',
      'In the end, we survived because we stayed together, communicated clearly, and accepted help from strangers.',
      'I still think about that night whenever someone says preparation is a waste of time.',
      'It was frightening, but it also taught our whole family how much a calm voice can matter.'
    ], { step: 7.5 })
    const candidates = analyze(segments, selected)
    expect(candidates.length).toBeGreaterThan(0)
    expect(candidates.some((candidate) => candidate.endTime - candidate.startTime >= 90)).toBe(true)
    const complete = candidates.find((candidate) => candidate.endTime - candidate.startTime >= 90)!
    expect(complete.intelligence?.momentTypeId).toBe('complete-story')
    expect(complete.intelligence?.scores.completeness).toBeGreaterThan(55)
    expect(complete.intelligence?.suggestedPayoff).toMatch(/end|survived|help|matter/i)
    expect(complete.intelligence?.originalStartTime).toBeLessThanOrEqual(complete.startTime)
    expect(complete.intelligence?.originalEndTime).toBeGreaterThanOrEqual(complete.endTime)
  })

  it('E — scores an educational explanation for structure, clarity, and information density', () => {
    const selected = profile({
      categoryId: 'educational-informational',
      subcategoryIds: ['explanations', 'practical-knowledge'],
      momentTypeIds: ['educational-explanation'],
      audienceId: 'students',
      durationMode: 'preset',
      durationPreset: '30-45',
      discoveryMode: 'educational-value',
      requestedCandidates: 5,
      minimumQualityScore: 20,
      sensitivity: 'low'
    })
    const segments = transcript([
      'A checksum is a short value calculated from a file so that software can notice when data changes.',
      'The important idea is that even a tiny edit usually produces a different checksum.',
      'For example, a download page can publish the expected value beside the file.',
      'After downloading, you calculate the checksum again and compare both values character by character.',
      'If they match, the file is likely complete, although a checksum is not a replacement for encryption.',
      'This means checksums are useful for finding accidental damage during storage or transfer.',
      'First use the same checksum algorithm on both copies, because different methods produce unrelated values.',
      'Then compare the full result rather than checking only the first few characters.',
      'A mismatch tells you to download or copy the file again before trusting it.',
      'That simple check prevents many confusing installation and backup problems.'
    ])
    const candidates = analyze(segments, selected)
    expect(candidates.length).toBeGreaterThan(0)
    expect(candidates[0].intelligence?.momentTypeId).toBe('educational-explanation')
    expect(candidates[0].intelligence?.scores.informationDensity).toBeGreaterThan(50)
    expect(candidates[0].intelligence?.scores.clarity).toBeGreaterThan(50)
    expect(candidates[0].intelligence?.scores.categoryFit).toBeGreaterThanOrEqual(50)
  })

  it('F — diversifies a mixed podcast transcript across topics and moment structures', () => {
    const selected = profile({
      categoryId: 'general-mixed',
      subcategoryIds: [],
      momentTypeIds: ['automatic-best'],
      durationMode: 'automatic',
      requestedCandidates: 10,
      minimumQualityScore: 20,
      sensitivity: 'low',
      discoveryMode: 'balanced'
    })
    const segments = transcript([
      'My relationship changed when we stopped avoiding honest conversations about money and family.',
      'After our breakup I learned that a clear boundary can protect both people from more hurt.',
      'Dating advice is useful only when it leaves room for two people to disagree respectfully.',
      'Eventually we chose separate paths, and I felt hopeful about building a healthier future.',
      'A small business can survive a slow month if the founder understands cash flow and real customer demand.',
      'Our startup tested a new price with ten customers before spending money on another feature.',
      'The first business model failed, but the revenue numbers showed us a better opportunity.',
      'For entrepreneurs, negotiating one supplier contract can matter more than a flashy office.',
      'The host asked whether I had a plan for keeping my desk tidy during a live interview.',
      'I said yes, then my friend opened the drawer and a hundred mismatched lids fell onto the floor.',
      'Everyone laughed because the most organized thing in my kitchen was apparently the pile of chaos.',
      'The unexpected answer became our running joke for the rest of the conversation.',
      'A checksum helps a computer detect accidental changes to a file during copying or download.',
      'For example, calculate the same value before and after transfer and compare the complete result.',
      'This means a mismatch can warn you before you rely on a damaged document or installer.',
      'A checksum does not encrypt data, so it solves a different problem from a password.',
      'When I was a student, I kept rereading notes instead of explaining the lesson in my own words.',
      'The useful discovery was that a short practice question showed what I actually remembered.',
      'I started testing myself before exams and stopped spending hours on material I already knew.',
      'In the end, that study habit made revision more focused and much less stressful.'
    ], { step: 5.5, speakers: true })
    const candidates = analyze(segments, selected)
    const categories = new Set(candidates.map((candidate) => candidate.intelligence?.inferredCategoryId))
    const types = new Set(candidates.map((candidate) => candidate.intelligence?.momentTypeId))
    expect(candidates.length).toBeGreaterThan(2)
    expect(categories.size).toBeGreaterThanOrEqual(2)
    expect(types.size).toBeGreaterThanOrEqual(2)
    expect(candidates.every((candidate) => candidate.intelligence?.analysisEngine === 'heuristic-local')).toBe(true)
  })

  it('G — the local engine works without network access or provider credentials and is deterministic', () => {
    const fetchSpy = vi.fn(() => Promise.reject(new Error('Network access is disabled in this test.')))
    vi.stubGlobal('fetch', fetchSpy)
    const selected = profile({
      categoryId: 'educational-informational',
      momentTypeIds: ['educational-explanation'],
      engine: 'heuristic-local',
      durationMode: 'preset',
      durationPreset: '30-45',
      requestedCandidates: 5,
      minimumQualityScore: 20,
      sensitivity: 'low'
    })
    const segments = transcript([
      'The first step is to describe the problem in one clear sentence before choosing a tool.',
      'For example, a backup protects a second copy of your files if the original is lost.',
      'This means synchronization and backup are not the same, because a deletion can sync too.',
      'Keep one separate version and test that it can be restored when you need it.',
      'A simple restore test proves whether the process works instead of merely looking reassuring.',
      'In the end, a backup is useful only when you can recover the information.'
    ])
    const first = analyze(segments, selected)
    const second = analyze(segments, selected)
    expect(first).toEqual(second)
    expect(first.length).toBeGreaterThan(0)
    expect(fetchSpy).not.toHaveBeenCalled()
    expect(first[0].intelligence?.analysisEngine).toBe('heuristic-local')

    const range = profileDurationRange(selected)
    const progress: number[] = []
    runHeuristicAnalysis(segments, {
      minSeconds: range.min, maxSeconds: range.max, maxCandidates: selected.requestedCandidates,
      intelligenceProfile: selected, analyzedAt: ANALYZED_AT, onProgress: (value) => progress.push(value)
    })
    expect(progress.at(0)).toBe(0)
    expect(progress.at(-1)).toBe(1)
    const controller = new AbortController()
    controller.abort()
    expect(() => runHeuristicAnalysis(segments, {
      minSeconds: range.min, maxSeconds: range.max, maxCandidates: selected.requestedCandidates,
      intelligenceProfile: selected, signal: controller.signal
    })).toThrow('Content analysis was cancelled.')
  })
})
