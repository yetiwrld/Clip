import React, { useEffect, useMemo, useRef, useState } from 'react'
import {
  BarChart3, Check, ChevronRight, Cpu, GitCompare, Pencil, Play, Scissors,
  ThumbsDown, Eye, X
} from 'lucide-react'
import { api, errMessage, mediaUrl } from '../../api/client'
import { useAppStore } from '../../stores/app'
import { useDataStore } from '../../stores/data'
import { EmptyState, ErrorBox, Field, Modal, ScoreValue, Spinner, scoreColor } from '../../components/ui'
import type { ClipCandidate, Project, ScoreBreakdown } from '@shared/types'
import {
  ANALYSIS_ENGINES,
  AUDIENCES,
  CONTENT_CATEGORIES,
  MOMENT_TYPES,
  normalizeContentIntelligenceProfile,
  type CandidateMomentTypeId,
  type ContentIntelligenceProfile,
  type ContentIntelligenceScores
} from '@shared/analysis/content-intelligence'
import { formatClock } from '@shared/utils/time'
import { ContentIntelligenceControls } from './ContentIntelligenceControls'

const DIMENSION_LABELS: Record<keyof ScoreBreakdown, string> = {
  hook: 'Hook strength',
  contextCompleteness: 'Context completeness',
  clarity: 'Clarity',
  retention: 'Retention potential',
  emotionalImpact: 'Emotional impact',
  standaloneValue: 'Standalone value',
  shareability: 'Shareability',
  visualSuitability: 'Audio / visual proxy'
}

const INTELLIGENCE_LABELS: Record<keyof ContentIntelligenceScores, string> = {
  hook: 'Hook strength',
  emotion: 'Emotion',
  curiosity: 'Curiosity',
  completeness: 'Standalone completeness',
  informationDensity: 'Information density',
  categoryFit: 'Category fit',
  typeFit: 'Moment-type fit',
  clarity: 'Clarity',
  shareability: 'Shareability heuristic',
  payoff: 'Ending payoff',
  audioVisualInterest: 'Audio / speaker interest',
  audienceFit: 'Audience relevance'
}

type ProviderId = 'heuristic-local' | 'local-ai-model' | 'openai-compatible' | 'anthropic'
type ResultStatusFilter = 'all' | 'unreviewed' | 'approved' | 'converted'

export function MomentsTab() {
  const app = useAppStore()
  const data = useDataStore()
  const project = data.activeProject!
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<unknown>(null)
  const [sectionTaskId, setSectionTaskId] = useState<string | null>(null)
  const [profileDraft, setProfileDraft] = useState<ContentIntelligenceProfile>(() => normalizeContentIntelligenceProfile(project.settings.contentIntelligence))
  const [profileSaving, setProfileSaving] = useState(false)
  const [profileSaveError, setProfileSaveError] = useState<string | null>(null)
  const [minimumScoreFilter, setMinimumScoreFilter] = useState(0)
  const [categoryFilter, setCategoryFilter] = useState('all')
  const [typeFilter, setTypeFilter] = useState('all')
  const [statusFilter, setStatusFilter] = useState<ResultStatusFilter>('all')
  const [compareIds, setCompareIds] = useState<string[]>([])
  const [compareOpen, setCompareOpen] = useState(false)
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const saveQueue = useRef<Promise<void>>(Promise.resolve())
  const lastSavedProfile = useRef(JSON.stringify(project.settings.contentIntelligence))
  const currentProjectId = useRef(project.id)

  useEffect(() => {
    if (currentProjectId.current === project.id) return
    currentProjectId.current = project.id
    if (saveTimer.current) clearTimeout(saveTimer.current)
    const next = normalizeContentIntelligenceProfile(project.settings.contentIntelligence)
    setProfileDraft(next)
    setProfileSaveError(null)
    lastSavedProfile.current = JSON.stringify(next)
    setCompareIds([])
  }, [project.id, project.settings.contentIntelligence])

  useEffect(() => () => {
    if (saveTimer.current) clearTimeout(saveTimer.current)
  }, [])

  const analyzeTask = data.tasks.find((task) => task.type === 'analyze' && task.projectId === project.id && (task.state === 'running' || task.state === 'queued'))
  const analyzing = project.status === 'analyzing' || Boolean(analyzeTask)
  const trackedSectionTask = data.tasks.find((task) => task.id === sectionTaskId)
  const activeSectionTask = trackedSectionTask && (trackedSectionTask.state === 'running' || trackedSectionTask.state === 'queued')
    ? trackedSectionTask
    : data.tasks.find((task) => task.type === 'download' && task.projectId === project.id && task.stage === 'section-download' && (task.state === 'running' || task.state === 'queued'))

  const engineInfo = ANALYSIS_ENGINES.find((engine) => engine.id === profileDraft.engine)!
  const engineAvailability = app.providers.find((provider) => provider.id === profileDraft.engine)
  const canRunSelectedEngine = profileDraft.engine === 'heuristic-local' || Boolean(engineAvailability?.available)
  const aiFixHint = engineAvailability?.fixHint ?? 'Settings → AI providers'

  const moments = useMemo(() => {
    const groups = new Map<string, ClipCandidate[]>()
    for (const candidate of data.candidates) {
      if (candidate.status === 'rejected') continue
      const list = groups.get(candidate.momentKey) ?? []
      list.push(candidate)
      groups.set(candidate.momentKey, list)
    }
    return [...groups.values()].map((list) => list.sort((a, b) => a.rankInMoment - b.rankInMoment))
  }, [data.candidates])

  const filteredMoments = useMemo(() => moments
    .map((list) => list.filter((candidate) => matchesFilters(candidate, {
      minimumScore: minimumScoreFilter,
      categoryId: categoryFilter,
      momentTypeId: typeFilter,
      status: statusFilter
    })))
    .filter((list) => list.length > 0), [moments, minimumScoreFilter, categoryFilter, typeFilter, statusFilter])

  const selectedForCompare = useMemo(
    () => compareIds.map((id) => data.candidates.find((candidate) => candidate.id === id)).filter((item): item is ClipCandidate => Boolean(item)),
    [compareIds, data.candidates]
  )

  function persistProfile(profile: ContentIntelligenceProfile): Promise<void> {
    const normalized = normalizeContentIntelligenceProfile(profile)
    const serialized = JSON.stringify(normalized)
    if (serialized === lastSavedProfile.current) return Promise.resolve()
    setProfileSaving(true)
    setProfileSaveError(null)
    saveQueue.current = saveQueue.current.catch(() => undefined).then(async () => {
      const updated = await api['projects.updateSettings']({
        id: project.id,
        settings: {
          contentIntelligence: normalized,
          maxCandidates: normalized.requestedCandidates,
          durationPreset: normalized.durationMode === 'automatic' ? 'mixed'
            : normalized.durationMode === 'preset' && normalized.durationPreset === '15-30' ? 'short'
              : normalized.durationMode === 'preset' && ['60-90', '90-180'].includes(normalized.durationPreset) ? 'long'
                : 'medium'
        }
      })
      lastSavedProfile.current = serialized
      if (useDataStore.getState().activeProject?.id === project.id) {
        useDataStore.setState({ activeProject: updated })
      }
    }).finally(() => setProfileSaving(false))
    return saveQueue.current
  }

  function updateProfile(nextValue: ContentIntelligenceProfile) {
    const next = normalizeContentIntelligenceProfile(nextValue)
    setProfileDraft(next)
    setProfileSaveError(null)
    useDataStore.setState((state) => state.activeProject?.id === project.id ? {
      activeProject: {
        ...state.activeProject,
        settings: { ...state.activeProject.settings, contentIntelligence: next, maxCandidates: next.requestedCandidates }
      }
    } : {})
    if (saveTimer.current) clearTimeout(saveTimer.current)
    saveTimer.current = setTimeout(() => {
      void persistProfile(next).catch((saveError) => setProfileSaveError(errMessage(saveError).message))
    }, 350)
  }

  async function analyze() {
    if (data.tasks.some((task) => task.type === 'analyze' && task.projectId === project.id && (task.state === 'running' || task.state === 'queued'))) {
      app.toast({ level: 'warn', message: 'An analysis is already running for this project.' })
      return
    }
    if (profileDraft.engine !== 'heuristic-local' && !canRunSelectedEngine) {
      setError(new Error(`${engineInfo.label} is not configured. Configure it in ${aiFixHint}, or explicitly choose the local analyzer.`))
      return
    }
    setError(null)
    setBusy(true)
    try {
      if (saveTimer.current) {
        clearTimeout(saveTimer.current)
        saveTimer.current = null
      }
      await persistProfile(profileDraft)
      await api['analysis.start']({ projectId: project.id, providerId: profileDraft.engine as ProviderId })
      const providerLabel = profileDraft.engine === 'heuristic-local'
        ? 'Local Heuristic Analyzer (offline)'
        : `${engineInfo.label} — only transcript text and timing are sent to the explicitly selected engine`
      app.toast({ level: 'info', message: `Content Intelligence started with ${providerLabel}.` })
    } catch (analysisError) {
      setError(analysisError)
      setProfileSaveError(errMessage(analysisError).message)
    } finally {
      setBusy(false)
    }
  }

  async function updateStatus(candidate: ClipCandidate, status: ClipCandidate['status']) {
    try {
      await api['analysis.updateCandidate']({ id: candidate.id, patch: { status } })
      await data.loadCandidates(project.id)
    } catch (actionError) {
      app.toast({ level: 'error', ...errMessage(actionError) })
    }
  }

  async function saveBoundary(candidate: ClipCandidate, startTime: number, endTime: number) {
    try {
      await api['analysis.updateCandidate']({ id: candidate.id, patch: { startTime, endTime } })
      await data.loadCandidates(project.id)
      app.toast({ level: 'success', message: 'Moment boundaries updated. Original detected timestamps remain in the audit.' })
    } catch (actionError) {
      app.toast({ level: 'error', ...errMessage(actionError) })
      throw actionError
    }
  }

  async function createClip(candidate: ClipCandidate) {
    try {
      if (project.sourceMode === 'audio-first') {
        const { taskId } = await api['clips.fetchCandidateSection']({ candidateId: candidate.id })
        setSectionTaskId(taskId)
        await data.loadTasks(project.id)
        app.toast({ level: 'info', message: 'Fetching only this moment’s video section. The full video will not be downloaded.' })
        return
      }
      const clip = await api['clips.createFromCandidate']({ candidateId: candidate.id })
      await data.loadClips(project.id)
      await data.loadCandidates(project.id)
      app.openEditor(clip.id, project.id)
    } catch (actionError) {
      app.toast({ level: 'error', ...errMessage(actionError) })
    }
  }

  async function cancelSectionDownload() {
    if (!activeSectionTask) return
    try {
      await api['tasks.cancel']({ id: activeSectionTask.id })
      setSectionTaskId(null)
    } catch (actionError) {
      app.toast({ level: 'error', ...errMessage(actionError) })
    }
  }

  function toggleCompare(candidate: ClipCandidate) {
    setCompareIds((current) => {
      if (current.includes(candidate.id)) return current.filter((id) => id !== candidate.id)
      if (current.length >= 3) {
        app.toast({ level: 'warn', message: 'Compare up to three candidates at a time.' })
        return current
      }
      return [...current, candidate.id]
    })
  }

  return (
    <div className="stack">
      <div className="toolbar" style={{ borderBottom: 'none', paddingBottom: 0, marginBottom: 4 }}>
        <span style={{ fontSize: 12.5, color: 'var(--text-2)' }}>
          <strong style={{ color: 'var(--text-1)' }}>{moments.length}</strong> moment{moments.length === 1 ? '' : 's'}
          <span style={{ color: 'var(--text-3)' }}> · {data.candidates.filter((candidate) => candidate.status !== 'rejected').length} candidates</span>
        </span>
        {project.sourceMode === 'audio-first' && <span className="tiny">Audio-only source · selected sections only</span>}
        {activeSectionTask && (
          <span className="row" style={{ fontSize: 12, color: 'var(--text-2)', gap: 7 }}>
            <Spinner size={12} /> {activeSectionTask.message ?? 'Fetching selected video section'}
            {activeSectionTask.progress != null && ` · ${Math.round(activeSectionTask.progress * 100)}%`}
            <button className="btn danger sm" onClick={() => void cancelSectionDownload()}>Cancel</button>
          </span>
        )}
        {analyzeTask?.message && (
          <span className="row" style={{ fontSize: 12, color: 'var(--text-2)', gap: 7 }}>
            <Spinner size={12} /> {analyzeTask.message} {analyzeTask.progress != null && `· ${Math.round(analyzeTask.progress * 100)}%`}
          </span>
        )}
        <span style={{ flex: 1 }} />
        {selectedForCompare.length >= 2 && (
          <button className="btn sm" onClick={() => setCompareOpen(true)}>
            <GitCompare size={13} /> Compare {selectedForCompare.length}
          </button>
        )}
        <button className={`btn ${profileDraft.engine === 'heuristic-local' ? 'primary' : ''}`} onClick={() => void analyze()} disabled={analyzing || busy || !canRunSelectedEngine || data.transcript.length === 0}>
          {busy || analyzing ? <Spinner size={13} /> : profileDraft.engine === 'heuristic-local' ? <Cpu size={13} /> : <Eye size={13} />}
          {analyzing ? 'Analyzing…' : `Analyze — ${engineInfo.label}`}
        </button>
      </div>

      <section className="ci-panel">
        <div className="ci-panel-head">
          <div>
            <div className="section-title">Content Intelligence profile</div>
            <div className="field-hint">Choose a topic, moment structure and audience before discovery. Preferences are saved to this project; existing clips and approvals are preserved.</div>
          </div>
          <span className={`ci-save-state ${profileSaving ? 'saving' : profileSaveError ? 'error' : ''}`}>
            {profileSaving ? 'Saving…' : profileSaveError ? 'Save failed' : 'Project profile'}
          </span>
        </div>
        {profileSaveError && <div className="error-hint" role="alert">{profileSaveError}</div>}
        <ContentIntelligenceControls value={profileDraft} onChange={updateProfile} showTuning />
        {profileDraft.engine !== 'heuristic-local' && !canRunSelectedEngine && (
          <div className="error-box" role="status">
            <div className="error-title">{engineInfo.label} is not configured.</div>
            <div className="error-hint">No fallback will run. Configure it in {aiFixHint}, or explicitly change the engine above to the offline local analyzer.</div>
          </div>
        )}
      </section>

      {error ? <ErrorBox error={error} onRetry={() => void analyze()} retryLabel="Retry selected analysis" /> : null}

      {data.transcript.length === 0 ? (
        <EmptyState
          icon={<BarChart3 size={28} />}
          title="Analysis needs a transcript"
          hint={`Choose and save the profile now, then transcribe the ${project.sourceMode === 'audio-first' ? 'downloaded audio' : 'source'} or import a transcript. Moment analysis reads transcript text and never the raw video.`}
        />
      ) : moments.length === 0 && !analyzing ? (
        <EmptyState
          icon={<BarChart3 size={28} />}
          title="No moments discovered yet"
          hint="Run the selected engine to find candidate clips. The Local Heuristic Analyzer works offline; cloud analysis runs only when explicitly selected and configured. Scores are estimates, not predictions of views."
        />
      ) : (
        <>
          <div className="ci-filter-bar">
            <Field label="Category">
              <select className="select" value={categoryFilter} onChange={(event) => setCategoryFilter(event.target.value)}>
                <option value="all">All categories</option>
                {CONTENT_CATEGORIES.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}
              </select>
            </Field>
            <Field label="Moment type">
              <select className="select" value={typeFilter} onChange={(event) => setTypeFilter(event.target.value)}>
                <option value="all">All moment types</option>
                {MOMENT_TYPES.filter((item) => item.id !== 'automatic-best' && item.id !== 'all-moments').map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}
              </select>
            </Field>
            <Field label="Minimum score">
              <select className="select" value={minimumScoreFilter} onChange={(event) => setMinimumScoreFilter(Number(event.target.value))}>
                <option value={0}>Any score</option><option value={40}>40+</option><option value={55}>55+</option><option value={70}>70+</option><option value={80}>80+</option>
              </select>
            </Field>
            <Field label="Review status">
              <select className="select" value={statusFilter} onChange={(event) => setStatusFilter(event.target.value as ResultStatusFilter)}>
                <option value="all">All active moments</option><option value="unreviewed">Unreviewed</option><option value="approved">Approved</option><option value="converted">Clip created</option>
              </select>
            </Field>
            <div className="ci-filter-count">Showing {filteredMoments.length} of {moments.length}</div>
          </div>

          {filteredMoments.length === 0 ? (
            <EmptyState icon={<BarChart3 size={24} />} title="No moments match these filters" hint="Clear one or more filters to see the rest of your candidates." />
          ) : (
            <div className="moment-list">
              {filteredMoments.map((list, index) => (
                <MomentRow
                  key={list[0].momentKey}
                  index={index}
                  project={project}
                  candidates={list}
                  compareIds={compareIds}
                  onToggleCompare={toggleCompare}
                  onCreate={(candidate) => void createClip(candidate)}
                  onStatus={(candidate, status) => void updateStatus(candidate, status)}
                  onSaveBoundary={saveBoundary}
                  createLabel={project.sourceMode === 'audio-first' ? 'Fetch section & create clip' : 'Create clip'}
                  sectionBusy={Boolean(activeSectionTask)}
                />
              ))}
            </div>
          )}
        </>
      )}

      {compareOpen && selectedForCompare.length >= 2 && (
        <CandidateCompareModal candidates={selectedForCompare} onClose={() => setCompareOpen(false)} />
      )}
    </div>
  )
}

function matchesFilters(candidate: ClipCandidate, filters: {
  minimumScore: number
  categoryId: string
  momentTypeId: string
  status: ResultStatusFilter
}): boolean {
  if ((candidate.overallScore ?? 0) < filters.minimumScore) return false
  if (filters.status === 'unreviewed' && candidate.status !== 'discovered') return false
  if (filters.status === 'approved' && candidate.status !== 'approved') return false
  if (filters.status === 'converted' && candidate.status !== 'converted') return false
  if (filters.categoryId !== 'all' && getCandidateCategory(candidate) !== filters.categoryId) return false
  if (filters.momentTypeId !== 'all') {
    const intelligence = candidate.intelligence
    if (intelligence?.momentTypeId !== filters.momentTypeId && !intelligence?.matchedMomentTypeIds.includes(filters.momentTypeId as CandidateMomentTypeId)) return false
  }
  return true
}

function getCandidateCategory(candidate: ClipCandidate): string {
  const id = candidate.intelligence?.categoryId === 'general-mixed'
    ? candidate.intelligence.inferredCategoryId
    : candidate.intelligence?.categoryId
  return id ?? 'general-mixed'
}

function categoryLabel(candidate: ClipCandidate): string {
  const id = getCandidateCategory(candidate)
  return CONTENT_CATEGORIES.find((item) => item.id === id)?.label ?? 'General / Mixed Content'
}

function momentTypeLabel(candidate: ClipCandidate): string {
  const id = candidate.intelligence?.momentTypeId
  if (id) return MOMENT_TYPES.find((item) => item.id === id)?.label ?? id
  return candidate.clipType.replace(/-/g, ' ')
}

function MomentRow(props: {
  index: number
  project: Project
  candidates: ClipCandidate[]
  compareIds: string[]
  onToggleCompare: (candidate: ClipCandidate) => void
  onCreate: (candidate: ClipCandidate) => void
  onStatus: (candidate: ClipCandidate, status: ClipCandidate['status']) => void
  onSaveBoundary: (candidate: ClipCandidate, start: number, end: number) => Promise<void>
  createLabel: string
  sectionBusy: boolean
}) {
  const [expanded, setExpanded] = useState(false)
  const [variationIdx, setVariationIdx] = useState(0)
  const [previewOpen, setPreviewOpen] = useState(false)
  const [editingBoundaries, setEditingBoundaries] = useState(false)
  const [startDraft, setStartDraft] = useState('')
  const [endDraft, setEndDraft] = useState('')
  const [savingBoundary, setSavingBoundary] = useState(false)
  const candidate = props.candidates[variationIdx] ?? props.candidates[0]
  const isComparing = props.compareIds.includes(candidate.id)
  const existingClip = useDataStore((state) => state.clips.find((clip) => clip.candidateId === candidate.id))
  const isAudioOnly = props.project.sourceMode === 'audio-first' || !props.project.videoCodec || props.project.videoCodec === 'none'
  const sourceUrl = props.project.sourcePath ? mediaUrl(props.project.sourcePath) : ''
  const intelligence = candidate.intelligence

  useEffect(() => {
    setVariationIdx(0)
  }, [props.candidates[0]?.id])
  useEffect(() => {
    setStartDraft(candidate.startTime.toFixed(1))
    setEndDraft(candidate.endTime.toFixed(1))
  }, [candidate.id, candidate.startTime, candidate.endTime])

  async function applyBoundaries() {
    const start = Number(startDraft)
    const end = Number(endDraft)
    if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || end <= start) return
    setSavingBoundary(true)
    try {
      await props.onSaveBoundary(candidate, start, end)
      setEditingBoundaries(false)
    } catch {
      /* parent displays a safe, user-facing message */
    } finally {
      setSavingBoundary(false)
    }
  }

  function stopPreview(event: React.SyntheticEvent<HTMLMediaElement>) {
    const media = event.currentTarget
    if (media.currentTime >= candidate.endTime) {
      media.pause()
      media.currentTime = candidate.endTime
    }
  }

  function seekStart(event: React.SyntheticEvent<HTMLMediaElement>) {
    event.currentTarget.currentTime = candidate.startTime
  }

  return (
    <div className="moment-row">
      <div
        className="moment-head"
        role="button"
        tabIndex={0}
        onClick={() => setExpanded((value) => !value)}
        onKeyDown={(event) => {
          if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault()
            setExpanded((value) => !value)
          }
        }}
        aria-expanded={expanded}
      >
        <span className="moment-index">Moment {String(props.index + 1).padStart(2, '0')}</span>
        <span className="moment-timecodes">
          {formatClock(candidate.startTime)} — {formatClock(candidate.endTime)}
          <span style={{ color: 'var(--text-3)' }}> · {Math.round(candidate.endTime - candidate.startTime)}s</span>
        </span>
        <span className="moment-title" title={candidate.title}>{candidate.title}</span>
        <span className="moment-audit"><ScoreValue score={candidate.overallScore} label={`Heuristic estimate: ${candidate.overallScore ?? '–'}/100`} /></span>
        <ChevronRight size={14} className="muted" style={{ transform: expanded ? 'rotate(90deg)' : 'none', transition: 'transform 120ms' }} />
      </div>

      {expanded && (
        <div className="moment-body">
          <div className="row wrap" style={{ gap: 8 }}>
            <span className="chip">{categoryLabel(candidate)}</span>
            <span className="chip">{momentTypeLabel(candidate)}</span>
            {candidate.status === 'approved' && <span className="chip success">Approved</span>}
            {candidate.status === 'converted' && <span className="chip success">Clip created</span>}
            <span className="tiny" title={intelligence ? `${intelligence.analysisEngine} · ${intelligence.analyzerVersion} · ${intelligence.analyzedAt}` : `Produced by ${candidate.provider}`}>
              {intelligence?.analysisEngine ?? candidate.provider}{intelligence ? ` · ${intelligence.analyzerVersion}` : ''}
            </span>
            {intelligence?.analyzedAt && <span className="tiny">· {new Date(intelligence.analyzedAt).toLocaleString()}</span>}
            <span style={{ flex: 1 }} />
            {props.candidates.length > 1 && (
              <span className="row" style={{ gap: 8 }}>
                <span className="tiny">variations</span>
                <span className="segmented">
                  {props.candidates.map((item, index) => (
                    <button key={item.id} className={index === variationIdx ? 'active' : ''} onClick={() => setVariationIdx(index)} title={`${Math.round(item.endTime - item.startTime)}s · score ${item.overallScore ?? '–'}`}>
                      {index === 0 ? 'Best' : `Alt ${index}`}
                    </button>
                  ))}
                </span>
              </span>
            )}
          </div>

          {candidate.hook && <div className="ci-copy"><span className="audit-label">Opening</span><em>“{candidate.hook}”</em></div>}
          {intelligence?.suggestedPayoff && <div className="ci-copy"><span className="audit-label">Suggested payoff</span><em>“{intelligence.suggestedPayoff}”</em></div>}
          {candidate.reason && <div className="tiny" style={{ color: 'var(--text-2)', lineHeight: 1.55 }}>{candidate.reason}</div>}
          {intelligence?.durationDeviationReason && <div className="ci-boundary-note">{intelligence.durationDeviationReason}</div>}
          {intelligence?.boundaryRationale && <div className="tiny" style={{ color: 'var(--text-3)' }}>{intelligence.boundaryRationale}</div>}

          {intelligence ? (
            <IntelligenceScoreBreakdownView candidate={candidate} />
          ) : candidate.scores ? (
            <ScoreBreakdownView scores={candidate.scores} explanation={candidate.scoreExplanation} provider={candidate.provider} />
          ) : null}

          <details className="ci-transcript-preview">
            <summary>Transcript preview</summary>
            <div className="excerpt">“{candidate.transcriptExcerpt}”</div>
          </details>

          {previewOpen && sourceUrl && (
            <div className="ci-preview">
              {isAudioOnly ? (
                <audio controls preload="metadata" src={sourceUrl} onLoadedMetadata={seekStart} onPlay={seekStart} onTimeUpdate={stopPreview} />
              ) : (
                <video controls preload="metadata" src={sourceUrl} onLoadedMetadata={seekStart} onPlay={seekStart} onTimeUpdate={stopPreview} />
              )}
              <span className="tiny">Preview is limited to the suggested source range. Use edit boundaries to adjust the selection.</span>
            </div>
          )}
          {!sourceUrl && previewOpen && <div className="field-hint">A local source file is not available for preview in this project.</div>}

          {editingBoundaries && (
            <div className="ci-boundary-editor">
              <div className="tiny">Edit source-time boundaries in seconds. Original detected timestamps stay stored in the audit.</div>
              <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: 10 }}>
                <Field label="Start (seconds)"><input className="input" type="number" min={0} max={props.project.duration ?? 86400} step={0.1} value={startDraft} onChange={(event) => setStartDraft(event.target.value)} /></Field>
                <Field label="End (seconds)"><input className="input" type="number" min={0} max={props.project.duration ?? 86400} step={0.1} value={endDraft} onChange={(event) => setEndDraft(event.target.value)} /></Field>
              </div>
              <div className="row wrap" style={{ gap: 8 }}>
                <button className="btn primary sm" onClick={() => void applyBoundaries()} disabled={savingBoundary || Number(endDraft) <= Number(startDraft)}>{savingBoundary ? <Spinner size={12} /> : <Check size={12} />} Save boundaries</button>
                <button className="btn ghost sm" onClick={() => setEditingBoundaries(false)}>Cancel</button>
              </div>
            </div>
          )}

          <div className="row wrap" style={{ gap: 8 }}>
            <button className="btn primary sm" onClick={() => props.onCreate(candidate)} disabled={existingClip != null || props.sectionBusy}>
              {props.sectionBusy ? <Spinner size={12} /> : <Scissors size={12} />} {existingClip ? 'Clip created' : props.createLabel}
            </button>
            {existingClip && <button className="btn sm" onClick={() => useAppStore.getState().openEditor(existingClip.id, existingClip.projectId)}>Open editor</button>}
            <button className="btn sm" onClick={() => setPreviewOpen((value) => !value)} disabled={!sourceUrl} aria-pressed={previewOpen}>
              {previewOpen ? <X size={12} /> : <Play size={12} />} {previewOpen ? 'Hide preview' : 'Preview'}
            </button>
            <button className="btn sm" onClick={() => setEditingBoundaries((value) => !value)}><Pencil size={12} /> Edit boundaries</button>
            <button className={`btn sm ${candidate.status === 'approved' ? 'success' : ''}`} onClick={() => props.onStatus(candidate, candidate.status === 'approved' ? 'discovered' : 'approved')} aria-pressed={candidate.status === 'approved'}>
              <Check size={12} /> {candidate.status === 'approved' ? 'Approved · undo' : 'Approve'}
            </button>
            <button className={`btn sm ${isComparing ? 'primary' : ''}`} onClick={() => props.onToggleCompare(candidate)} aria-pressed={isComparing}><GitCompare size={12} /> {isComparing ? 'Selected to compare' : 'Compare'}</button>
            <button className="btn ghost sm" onClick={() => props.onStatus(candidate, 'rejected')} title="Reject this moment"><ThumbsDown size={12} /> Reject</button>
          </div>
        </div>
      )}
    </div>
  )
}

export function IntelligenceScoreBreakdownView({ candidate }: { candidate: ClipCandidate }) {
  const intelligence = candidate.intelligence
  if (!intelligence) return null
  const scoreKeys = Object.keys(INTELLIGENCE_LABELS) as Array<keyof ContentIntelligenceScores>
  return (
    <div className="stack sm">
      <div className="ci-score-heading">
        <strong>Explainable score breakdown</strong>
        <span>Overall estimate · {candidate.overallScore ?? '–'}/100</span>
      </div>
      {scoreKeys.map((key) => {
        const value = intelligence.scores[key]
        return (
          <div className="bar-row" key={key}>
            <span className="bar-label">{INTELLIGENCE_LABELS[key]}</span>
            <div className="score-bar-track">
              {value != null && <div className="score-bar-fill" style={{ width: `${value}%`, background: scoreColor(value) }} />}
            </div>
            <span className="bar-value">{value == null ? '—' : value}</span>
          </div>
        )
      })}
      <div className="tiny" style={{ color: 'var(--text-2)', lineHeight: 1.55 }}>
        <strong>Why this score</strong> — {intelligence.explanation}
      </div>
      <div className="tiny" style={{ color: 'var(--text-3)' }}>
        {intelligence.analysisEngine === 'heuristic-local' ? 'Local heuristic estimate (not a generative AI model)' : `Audit: ${intelligence.analysisEngine}; local content scoring ${intelligence.analyzerVersion}`}.
        {' '}Scores describe transcript and optional waveform characteristics; they do not guarantee or predict views.
        {!intelligence.audioSignalsAvailable && ' Audio / speaker interest was unavailable and is not included in the weighted total.'}
      </div>
      {intelligence.originalStartTime !== candidate.startTime || intelligence.originalEndTime !== candidate.endTime ? (
        <div className="tiny" style={{ color: 'var(--text-3)' }}>
          Original detected range: {formatClock(intelligence.originalStartTime)}–{formatClock(intelligence.originalEndTime)}
        </div>
      ) : null}
    </div>
  )
}

export function ScoreBreakdownView({ scores, explanation, provider }: { scores: ScoreBreakdown; explanation: string | null; provider: string }) {
  return (
    <div className="stack sm">
      {(Object.keys(DIMENSION_LABELS) as Array<keyof ScoreBreakdown>).map((key) => (
        <div className="bar-row" key={key}>
          <span className="bar-label">{DIMENSION_LABELS[key]}</span>
          <div className="score-bar-track"><div className="score-bar-fill" style={{ width: `${scores[key]}%`, background: scoreColor(scores[key]) }} /></div>
          <span className="bar-value">{scores[key]}</span>
        </div>
      ))}
      {explanation && <div className="tiny" style={{ lineHeight: 1.55, color: 'var(--text-2)', marginTop: 4 }}><strong>Why this score</strong> — {explanation}</div>}
      <div className="tiny" style={{ color: 'var(--text-3)' }}>
        Performance Audit — an estimate by <strong>{provider === 'heuristic-local' ? 'the local heuristic analyzer (not an AI model)' : provider}</strong>. It is not a prediction of views.
      </div>
    </div>
  )
}

function CandidateCompareModal(props: { candidates: ClipCandidate[]; onClose: () => void }) {
  return (
    <Modal title="Compare candidate moments" onClose={props.onClose} wide footer={<button className="btn" onClick={props.onClose}>Done</button>}>
      <div className="ci-compare-grid">
        {props.candidates.map((candidate) => (
          <section className="ci-compare-card" key={candidate.id}>
            <div className="section-title">{candidate.title}</div>
            <div className="tiny">{formatClock(candidate.startTime)}–{formatClock(candidate.endTime)} · {Math.round(candidate.endTime - candidate.startTime)}s</div>
            <div className="row wrap" style={{ margin: '8px 0' }}><span className="chip">{categoryLabel(candidate)}</span><span className="chip">{momentTypeLabel(candidate)}</span></div>
            <ScoreValue score={candidate.overallScore} size="lg" />
            <div className="tiny" style={{ lineHeight: 1.55, marginTop: 8 }}>{candidate.intelligence?.explanation ?? candidate.reason}</div>
            <div className="ci-compare-subtitle">Hook</div><div className="tiny">{candidate.intelligence?.suggestedHook ?? candidate.hook}</div>
            <div className="ci-compare-subtitle">Payoff</div><div className="tiny">{candidate.intelligence?.suggestedPayoff ?? 'Not available for this legacy candidate.'}</div>
            {candidate.intelligence && <IntelligenceScoreBreakdownView candidate={candidate} />}
          </section>
        ))}
      </div>
    </Modal>
  )
}

function matchesCategory(candidate: ClipCandidate, categoryId: string): boolean {
  return categoryId === 'all' || getCandidateCategory(candidate) === categoryId
}
