# AI Pipeline

Two independent provider layers — **transcription** and **analysis** — plus a
prompt/template layer and a strict validation gate. Nothing AI-generated is
trusted by type alone: every structure passes zod validation before it can
touch the database or UI.

## Transcription providers (`TranscriptionProvider`)

| id | transport | notes |
|---|---|---|
| `faster-whisper-local` | Python subprocess (`scripts/python/transcribe_faster_whisper.py`) | local, word-level timestamps, model size + compute type configurable, models cached under `<workspace>/models`. Availability probe: `python3 -c "import faster_whisper"`. |
| `openai-compatible` | HTTPS `POST {baseUrl}/audio/transcriptions` (multipart) | OpenAI, Groq, etc. Only used when the user marks the endpoint as audio-capable and provides a key. Sends **only the audio track** (extracted/written to a temp file), never the full video. |
| `import-file` | local file picker | SRT / WebVTT / JSON / plain-text-with-timestamps import — the offline escape hatch. |

Normalized result (stored as `transcript_segments`):

```json
{ "language": "en",
  "segments": [ { "start": 0.0, "end": 4.2, "text": "...", "speaker": "speaker_01",
                  "confidence": 0.93, "words": [ { "word": "…", "start": 0.1, "end": 0.4 } ] } ] }
```

Word timing is optional everywhere (captions fall back to proportional
distribution within a segment).

## Local speaker groups

The Transcript tab can group existing transcript segments by local voice
similarity and lets the user rename groups or correct each segment's speaker.
This is **speaker diarization, not identity recognition**: labels such as
“Speaker 1” do not claim to identify a real person. Transcript text and timing
are preserved. The tool assigns one label per existing transcript segment; it
does not split an ASR segment that contains two speakers.

The optional CPU-only helper is `scripts/python/diarize_resemblyzer.py` and
uses Resemblyzer embeddings plus local clustering. Install it into a Python
interpreter visible on `PATH` with `python -m pip install resemblyzer`. The
first analysis may need an internet connection to obtain pretrained weights;
after the package/model cache is present, audio analysis runs locally. The app
extracts a temporary mono WAV, removes it after the task, and never uploads the
source audio. Manual labels and corrections are stored with the project.

## Analysis providers (`AnalysisProvider`)

| id | transport | notes |
|---|---|---|
| `heuristic-local` | in-process | built-in offline Content Intelligence analyzer. Always available; it is a deterministic heuristic, not a generative AI model. |
| `local-ai-model` | `POST http://localhost:{port}/v1/chat/completions` (OpenAI-compatible) | optional, already-installed local server such as LM Studio or Ollama. The endpoint must be loopback; no key is required or sent, and the app never downloads a model or falls back to another provider. |
| `openai-compatible` | `POST {baseUrl}/chat/completions` | explicitly selected OpenAI-compatible cloud endpoint (OpenAI, OpenRouter, Groq, Together, and similar). Requires the configured key. |
| `anthropic` | `POST https://api.anthropic.com/v1/messages` | explicitly selected Anthropic cloud engine with separate wire format. |

## Prompt layer (`src/prompts/index.ts`)

All prompt text and builders live in the single main-process module
`src/prompts/index.ts`: `DISCOVERY_SYSTEM` / `buildDiscoveryUserPrompt`,
`SCORING_SYSTEM` / `buildScoringUserPrompt`, and `METADATA_SYSTEM` /
`buildMetadataUserPrompt`. Each builder receives structured context
(numbered transcript segments with ids, source metadata, duration targets) and
demands **strict JSON**.

### Anti-hallucination constraints baked into every discovery prompt

- The transcript may contain errors — reason about meaning, don't quote blindly.
- **Timestamps must be expressed as segment id ranges** (`startSegmentId`,
  `endSegmentId`). The application converts ids → real times. This makes
  invented or out-of-range timestamps structurally impossible.
- Never invent dialogue. The excerpt must be reconstructable from the segments.
- Clips must start at a meaningful opening and end after the payoff — no
  mid-thought starts, no dangling endings.
- Prioritize standalone value; inspect the **entire** transcript, not just the
  beginning; avoid near-duplicates of other candidates.
- Respect the requested duration window (short/medium/long), with tolerance.

### Pipeline

```
transcript + saved Content Intelligence profile
  → Local Heuristic Analyzer: sentence-aware candidate windows, discourse/topic
    structure, category/type/audience fit and local audio/speaker support; or
    explicitly selected Local AI Model / cloud discovery
  → segment-id validation + sentence-aware timestamp snapping
  → transparent per-dimension audit and profile-sensitive weighting
  → configurable overlap deduplication + timeline/type/category diversification
  → preserve original boundaries, profile, engine/version/time and explanations
  → persist and show candidates for review; preferences do not erase old work
```

### Malformed model output handling

1. Strip markdown fences / leading prose; attempt JSON extraction.
2. Safe repair: trailing commas, smart quotes, unescaped newlines.
3. Parse → zod. If invalid: **one** retry with a stricter "JSON only" system
   message.
4. Still invalid: fail the operation with a human-readable error
   (`AI_RETURNED_INVALID_JSON`) listing which candidates, if any, survived —
   partial valid candidates are kept, invalid ones dropped with a warning.

### Scoring dimensions (the "Performance Audit")

`hook · emotion · curiosity · completeness · informationDensity · categoryFit ·
typeFit · clarity · shareability · payoff · audienceFit · audioVisualInterest`
(with the last dimension marked unavailable when there is no waveform or
speaker-turn signal) are shown alongside the legacy audit dimensions. Each
score is an explainable heuristic estimate, not a prediction of views or a
guarantee of virality. Local waveform peaks and speaker turns are supporting
signals only; raw media is never sent for moment analysis.

### Metadata generation (`METADATA_SYSTEM` in `src/prompts/index.ts`)

Per clip, on demand: `{ title, description, hashtags[], cta }` validated by
zod, fully editable by the user, platform-preset aware (length/format hints
for TikTok / Reels / Shorts / Generic).

## Privacy rules

- Analysis providers receive **transcript text and lightweight metadata only**
  (duration, topic hints) — never video/audio files.
- The UI states, before an external call, which provider will receive data.
- `heuristic-local`, `faster-whisper-local`, local speaker grouping, and
  `import-file` keep those selected operations on-device. `local-ai-model`
  talks only to a configured loopback address and sends no API key. Cloud
  providers run only when configured and explicitly selected; there is no
  silent fallback. The app never claims "100% private" as a blanket statement.
- API keys live in `secrets.json` (0600, Electron `safeStorage`-encrypted when
  available), never in the database, logs, renderer, or diagnostics.

## Caching (avoid redundant cost)

- Transcripts are cached per project (re-running analysis never re-transcribes).
- Raw provider responses are archived to `projects/<id>/analysis/*.json`.
- Analysis is only re-run on explicit user action (or transcript change).
- Metadata generation is per-clip and only on request.
