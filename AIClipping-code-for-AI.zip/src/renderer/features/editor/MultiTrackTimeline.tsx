import React, { useEffect, useMemo, useRef, useState } from 'react'
import { AudioLines, Copy, Eye, EyeOff, Film, Lock, Magnet, Maximize2, Plus, Redo2, Scissors, Trash2, Type, Undo2, Unlock, Volume2, VolumeX, ZoomIn, ZoomOut } from 'lucide-react'
import type { CameraKeyframe, ClipTimeline, ProjectAsset, TextLayer, TimelineItem, TimelineTrack } from '@shared/types'
import { formatClock } from '@shared/utils/time'
import { sourceDeltaForTimelineDelta, timelineItemDuration, timelineItemEnd } from '@shared/video/time-map'
import { frameDuration, frameTimeTolerance } from '@shared/video/frame-rate'
import { droppedFilePath, mediaUrl } from '../../api/client'

type DragState = { id: string; mode: 'move' | 'left' | 'right'; startX: number; initial: TimelineItem }
type EditDragState =
  | { mode: 'source-left' | 'source-right'; startX: number; start: number; end: number }
  | { mode: 'silence-left' | 'silence-right'; startX: number; index: number; start: number; end: number; min: number; max: number }
  | { mode: 'caption' | 'caption-left' | 'caption-right'; startX: number; key: string; start: number; offset: number }
  | { mode: 'camera'; startX: number; time: number }
  | { mode: 'text' | 'text-left' | 'text-right'; startX: number; layer: TextLayer }

export function MultiTrackTimeline(props: {
  timeline: ClipTimeline
  assets: ProjectAsset[]
  waveforms: Record<string, { peaks: number[]; duration: number }>
  duration: number
  sourceClip?: { name: string; startTime: number; endTime: number; filmstrip?: Array<{ t: number; path: string }> }
  sourceWaveform?: { peaks: number[]; duration: number } | null
  fps?: number | null
  captions?: Array<{ key: string; startTime: number; endTime: number; text: string }>
  textLayers?: TextLayer[]
  captionOffsets?: Record<string, number>
  trackingKeyframes?: Array<{ time: number; x: number; y: number; score: number }>
  cameraKeyframes?: CameraKeyframe[]
  silenceCuts?: Array<{ start: number; end: number; detectedStart?: number; detectedEnd?: number; status?: 'removed' | 'kept' }>
  onChangeSourceRange?: (start: number, end: number) => void
  onChangeSilence?: (index: number, start: number, end: number) => void
  onSetCaptionOffset?: (key: string, offset: number, edge: 'move' | 'start' | 'end') => void
  onSelectTextLayer?: (layer: TextLayer) => void
  onChangeTextLayer?: (id: string, patch: Partial<TextLayer>) => void
  onMoveCameraKeyframe?: (oldTime: number, time: number) => void
  selectedSource?: boolean
  selectedItemId?: string | null
  selectedCaptionKey?: string | null
  selectedSilenceIndex?: number | null
  selectedTextLayerId?: string | null
  selectedCameraKeyframeTime?: number | null
  playing: boolean
  getPlaybackTime: () => number
  onSelectCaption?: (key: string) => void
  onSelectCameraKeyframe?: (time: number) => void
  onSelectTrackingKeyframe?: (keyframe: { time: number; x: number; y: number; score: number }) => void
  onSelectSilence?: (index: number) => void
  onSelectSource?: () => void
  currentTime: number
  onSeek: (time: number) => void
  onChange: (timeline: ClipTimeline) => void
  onUndo: () => void
  onRedo: () => void
  canUndo: boolean
  canRedo: boolean
  snapTargets?: number[]
  onSelectItem?: (item: TimelineItem | null) => void
  onDropFiles: (paths: string[], time: number, track: TimelineTrack) => void
}) {
  const scrollRef = useRef<HTMLDivElement>(null)
  const dragRef = useRef<DragState | null>(null)
  const editDragRef = useRef<EditDragState | null>(null)
  const cursorDragCleanupRef = useRef<(() => void) | null>(null)
  const cursorRef = useRef<HTMLDivElement>(null)
  const cursorLabelRef = useRef<HTMLSpanElement>(null)
  const pinnedTimeRef = useRef<number | null>(null)
  const cursorDraggingRef = useRef(false)
  const dragSeekFrameRef = useRef<number | null>(null)
  const pendingDragSeekRef = useRef<number | null>(null)
  const lastDragSeekAtRef = useRef(0)
  const [pixelsPerSecond, setPixelsPerSecond] = useState(40)
  const [dragTarget, setDragTarget] = useState<string | null>(null)
  const [dropTime, setDropTime] = useState<number | null>(null)
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [selectedTrackingTime, setSelectedTrackingTime] = useState<number | null>(null)
  const span = Math.max(30, props.duration || 30)
  const width = Math.max(1100, span * pixelsPerSecond)
  const assetById = useMemo(() => new Map(props.assets.map((asset) => [asset.id, asset])), [props.assets])
  const selected = props.timeline.items.find((item) => item.id === selectedId) ?? null
  const sourceFilmstripFrame = props.sourceClip?.filmstrip?.reduce<typeof props.sourceClip.filmstrip[number] | null>((nearest, frame) => {
    const middle = (props.sourceClip!.startTime + props.sourceClip!.endTime) / 2
    return !nearest || Math.abs(frame.t - middle) < Math.abs(nearest.t - middle) ? frame : nearest
  }, null)
  const ticks = useMemo(() => {
    const step = pixelsPerSecond > 100 ? 1 : pixelsPerSecond > 45 ? 5 : 10
    return Array.from({ length: Math.floor(span / step) + 1 }, (_, i) => i * step)
  }, [pixelsPerSecond, span])

  useEffect(() => () => {
    cursorDragCleanupRef.current?.()
    if (dragSeekFrameRef.current !== null) cancelAnimationFrame(dragSeekFrameRef.current)
  }, [])

  // Keep the active edit visible when a project opens on a source time well
  // beyond zero, and continue following the playhead only when it reaches the
  // edge of the current view. The sticky track labels occupy the first 145px.
  useEffect(() => {
    const viewport = scrollRef.current
    if (!viewport) return
    const labelWidth = 145
    const usableWidth = Math.max(1, viewport.clientWidth - labelWidth)
    const margin = Math.min(220, usableWidth * 0.2)
    const playheadX = Math.max(0, props.currentTime) * pixelsPerSecond
    const visibleStart = viewport.scrollLeft + labelWidth
    const visibleEnd = viewport.scrollLeft + viewport.clientWidth
    if (playheadX < visibleStart + margin || playheadX > visibleEnd - margin) {
      viewport.scrollLeft = Math.max(0, playheadX - labelWidth - margin)
    }
  }, [props.currentTime, pixelsPerSecond])

  useEffect(() => {
    if (!props.playing) {
      pinnedTimeRef.current = props.currentTime
      positionCursor(props.currentTime, false)
      return
    }
    let frame = 0
    const followPlayback = () => {
      positionCursor(props.getPlaybackTime(), false)
      frame = requestAnimationFrame(followPlayback)
    }
    frame = requestAnimationFrame(followPlayback)
    return () => cancelAnimationFrame(frame)
  }, [props.playing, props.currentTime, props.getPlaybackTime, pixelsPerSecond])

  function positionCursor(time: number, hovering: boolean) {
    const cursor = cursorRef.current
    if (!cursor) return
    cursor.style.setProperty('--cursor-x', `${145 + time * pixelsPerSecond}px`)
    cursor.classList.toggle('hovering', hovering)
    if (cursorLabelRef.current) cursorLabelRef.current.textContent = formatClock(time, true)
  }

  function replaceItem(id: string, patch: Partial<TimelineItem>) {
    const updated = props.timeline.items.find((item) => item.id === id)
    if (updated && selectedId === id) props.onSelectItem?.({ ...updated, ...patch })
    props.onChange({ ...props.timeline, items: props.timeline.items.map((item) => item.id === id ? { ...item, ...patch } : item) })
  }
  function beginEditDrag(event: React.PointerEvent, state: EditDragState) {
    event.stopPropagation()
    event.preventDefault()
    editDragRef.current = state
    const move = (pointer: PointerEvent) => {
      const drag = editDragRef.current
      if (!drag) return
      const delta = (pointer.clientX - drag.startX) / pixelsPerSecond
      if (drag.mode === 'source-left') {
        props.onChangeSourceRange?.(Math.max(0, Math.min(drag.start + delta, drag.end - frameDuration(props.fps))), drag.end)
      } else if (drag.mode === 'source-right') {
        props.onChangeSourceRange?.(drag.start, Math.min(span, Math.max(drag.start + frameDuration(props.fps), drag.end + delta)))
      } else if (drag.mode === 'silence-left') {
        props.onChangeSilence?.(drag.index, Math.max(drag.min, Math.min(drag.start + delta, drag.end - 0.04)), drag.end)
      } else if (drag.mode === 'silence-right') {
        props.onChangeSilence?.(drag.index, drag.start, Math.min(drag.max, Math.max(drag.start + 0.04, drag.end + delta)))
      } else if (drag.mode === 'caption' || drag.mode === 'caption-left' || drag.mode === 'caption-right') {
        const edge = drag.mode === 'caption-left' ? 'start' : drag.mode === 'caption-right' ? 'end' : 'move'
        props.onSetCaptionOffset?.(drag.key, drag.offset + delta, edge)
      } else if (drag.mode === 'camera') {
        const next = Math.max(props.sourceClip?.startTime ?? 0, Math.min(props.sourceClip?.endTime ?? span, drag.time + delta))
        props.onMoveCameraKeyframe?.(drag.time, next)
      } else if (drag.mode === 'text') {
        const duration = drag.layer.endTime - drag.layer.startTime
        const startTime = Math.max(0, Math.min(span - duration, drag.layer.startTime + delta))
        props.onChangeTextLayer?.(drag.layer.id, { startTime, endTime: startTime + duration })
        drag.layer = { ...drag.layer, startTime, endTime: startTime + duration }
        drag.startX = pointer.clientX
      } else if (drag.mode === 'text-left') {
        const startTime = Math.max(0, Math.min(drag.layer.startTime + delta, drag.layer.endTime - 0.1))
        props.onChangeTextLayer?.(drag.layer.id, { startTime })
        drag.layer = { ...drag.layer, startTime }
        drag.startX = pointer.clientX
      } else if (drag.mode === 'text-right') {
        const endTime = Math.max(drag.layer.startTime + 0.1, Math.min(span, drag.layer.endTime + delta))
        props.onChangeTextLayer?.(drag.layer.id, { endTime })
        drag.layer = { ...drag.layer, endTime }
        drag.startX = pointer.clientX
      }
    }
    const up = () => {
      editDragRef.current = null
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerup', up)
    }
    window.addEventListener('pointermove', move)
    window.addEventListener('pointerup', up, { once: true })
  }
  function seekTo(time: number) {
    const next = Math.max(0, Math.min(span, time))
    pinnedTimeRef.current = next
    positionCursor(next, false)
    props.onSeek(next)
  }
  function seekDuringDrag(time: number) {
    pinnedTimeRef.current = time
    positionCursor(time, false)
    pendingDragSeekRef.current = time
    if (dragSeekFrameRef.current !== null) return
    dragSeekFrameRef.current = requestAnimationFrame((now) => {
      dragSeekFrameRef.current = null
      if (now - lastDragSeekAtRef.current < 50 || pendingDragSeekRef.current === null) return
      const pending = pendingDragSeekRef.current
      pendingDragSeekRef.current = null
      lastDragSeekAtRef.current = now
      props.onSeek(pending)
    })
  }
  function flushDragSeek() {
    if (dragSeekFrameRef.current !== null) cancelAnimationFrame(dragSeekFrameRef.current)
    dragSeekFrameRef.current = null
    if (pendingDragSeekRef.current !== null) {
      props.onSeek(pendingDragSeekRef.current)
      pendingDragSeekRef.current = null
      lastDragSeekAtRef.current = performance.now()
    }
    positionCursor(pinnedTimeRef.current ?? props.currentTime, false)
  }
  function adjustSourceRangeByKey(event: React.KeyboardEvent<HTMLSpanElement>, edge: 'start' | 'end') {
    if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return
    event.preventDefault()
    const frame = frameDuration(props.fps)
    const delta = (event.shiftKey ? 1 : frame) * (event.key === 'ArrowLeft' ? -1 : 1)
    const start = props.sourceClip?.startTime ?? 0
    const end = props.sourceClip?.endTime ?? span
    if (edge === 'start') props.onChangeSourceRange?.(Math.max(0, Math.min(end - frame, start + delta)), end)
    else props.onChangeSourceRange?.(start, Math.min(span, Math.max(start + frame, end + delta)))
  }
  function updateHoverCursor(event: React.PointerEvent<HTMLDivElement>) {
    const viewport = scrollRef.current
    if (!viewport) return
    const rect = viewport.getBoundingClientRect()
    const x = event.clientX - rect.left
    if (x < 145 || x > viewport.clientWidth) {
      if (!cursorDraggingRef.current) positionCursor(pinnedTimeRef.current ?? props.currentTime, false)
      return
    }
    const time = Math.max(0, Math.min(span, (viewport.scrollLeft + x - 145) / pixelsPerSecond))
    if (pinnedTimeRef.current === null) positionCursor(time, true)
  }
  function beginCursorDrag(event: React.PointerEvent<HTMLDivElement>) {
    if (event.button !== 0 || (event.target as HTMLElement).closest('.multi-track-label')) return
    const viewport = scrollRef.current
    if (!viewport) return
    cursorDraggingRef.current = true
    cursorDragCleanupRef.current?.()
    const update = (clientX: number) => {
      const rect = viewport.getBoundingClientRect()
      const x = Math.max(145, Math.min(viewport.clientWidth, clientX - rect.left))
      const time = Math.max(0, Math.min(span, (viewport.scrollLeft + x - 145) / pixelsPerSecond))
      seekDuringDrag(time)
    }
    update(event.clientX)
    const move = (pointer: PointerEvent) => update(pointer.clientX)
    const stop = () => {
      flushDragSeek()
      cursorDraggingRef.current = false
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerup', stop)
      window.removeEventListener('pointercancel', stop)
      cursorDragCleanupRef.current = null
    }
    cursorDragCleanupRef.current = stop
    window.addEventListener('pointermove', move)
    window.addEventListener('pointerup', stop, { once: true })
    window.addEventListener('pointercancel', stop, { once: true })
  }
  function addTrack(type: TimelineTrack['type']) {
    const siblings = props.timeline.tracks.filter((track) => track.type === type)
    const id = crypto.randomUUID()
    const name = type === 'audio' ? `Audio ${siblings.length + 1}` : type === 'image' ? `Graphics ${siblings.length + 1}` : `Video ${siblings.length + 2}`
    const track: TimelineTrack = { id, name, type, order: props.timeline.tracks.length, muted: false, hidden: false, locked: false }
    props.onChange({ ...props.timeline, tracks: [...props.timeline.tracks, track] })
  }
  function place(assetId: string, time: number, track: TimelineTrack) {
    const asset = assetById.get(assetId)
    if (!asset || asset.missing || asset.mediaType !== track.type) return
    const duration = asset.duration ?? 5
    const item: TimelineItem = {
      id: crypto.randomUUID(), assetId, trackId: track.id, startTime: Math.max(0, time), sourceIn: 0,
      sourceOut: duration, volume: 1, muted: false, fadeIn: 0, fadeOut: 0, speed: 1, loop: false,
      x: 0, y: 0, scale: 1, rotation: 0, opacity: 1
    }
    props.onChange({ ...props.timeline, items: [...props.timeline.items, item] })
    setSelectedId(item.id)
    props.onSelectItem?.(item)
  }
  function timeFromEvent(event: React.DragEvent | React.PointerEvent, track: TimelineTrack): number {
    const lane = event.currentTarget instanceof HTMLElement ? event.currentTarget.querySelector('.multi-track-lane') : null
    const rect = lane?.getBoundingClientRect()
    if (!rect) return 0
    const x = event.clientX - rect.left
    let time = Math.max(0, x / pixelsPerSecond)
    if (props.timeline.snapEnabled) {
      const targets = [props.currentTime, ...(props.snapTargets ?? []), ...props.timeline.items.flatMap((item) => [item.startTime, timelineItemEnd(item)])]
      const nearest = targets.reduce((best, target) => Math.abs(target - time) < Math.abs(best - time) ? target : best, Number.NaN)
      if (Number.isFinite(nearest) && Math.abs(nearest - time) < 8 / pixelsPerSecond) time = nearest
      time = Math.round(time * 100) / 100
    }
    void track
    return time
  }
  function onDrop(event: React.DragEvent, track: TimelineTrack) {
    event.preventDefault(); setDragTarget(null); setDropTime(null)
    const time = timeFromEvent(event, track)
    const assetId = event.dataTransfer.getData('application/x-clipwright-asset') || event.dataTransfer.getData('text/plain')
    if (assetId && assetById.has(assetId)) { place(assetId, time, track); return }
    // Electron attaches the source path to File objects dropped from Explorer.
    const files = Array.from(event.dataTransfer.files)
    const paths = files.map(droppedFilePath).filter((value): value is string => Boolean(value))
    if (paths.length) props.onDropFiles(paths, time, track)
  }
  function beginDrag(event: React.PointerEvent, item: TimelineItem, mode: DragState['mode']) {
    const track = props.timeline.tracks.find((row) => row.id === item.trackId)
    if (track?.locked) return
    event.stopPropagation(); event.preventDefault(); setSelectedId(item.id); seekTo(item.startTime); props.onSelectItem?.(item)
    dragRef.current = { id: item.id, mode, startX: event.clientX, initial: item }
    const onMove = (move: PointerEvent) => {
      const state = dragRef.current
      if (!state) return
      const dt = (move.clientX - state.startX) / pixelsPerSecond
      const original = state.initial
      if (state.mode === 'move') {
        let startTime = Math.max(0, original.startTime + dt)
        if (props.timeline.snapEnabled) {
          const targets = [props.currentTime, ...(props.snapTargets ?? []), ...props.timeline.items.filter((item) => item.id !== original.id).flatMap((item) => [item.startTime, timelineItemEnd(item)])]
          const nearest = targets.reduce((best, target) => Math.abs(target - startTime) < Math.abs(best - startTime) ? target : best, Number.NaN)
          if (Number.isFinite(nearest) && Math.abs(nearest - startTime) < 8 / pixelsPerSecond) startTime = nearest
          else startTime = Math.round(startTime * 100) / 100
        }
        replaceItem(state.id, { startTime })
      } else if (state.mode === 'left') {
        const delta = Math.max(-original.startTime, Math.min(dt, timelineItemDuration(original) - 0.05))
        replaceItem(state.id, { startTime: original.startTime + delta, sourceIn: original.sourceIn + sourceDeltaForTimelineDelta(delta, original.speed) })
      } else {
        const sourceOut = Math.max(original.sourceIn + 0.05, original.sourceOut + sourceDeltaForTimelineDelta(dt, original.speed))
        replaceItem(state.id, { sourceOut })
      }
    }
    const onUp = () => { dragRef.current = null; window.removeEventListener('pointermove', onMove); window.removeEventListener('pointerup', onUp) }
    window.addEventListener('pointermove', onMove); window.addEventListener('pointerup', onUp, { once: true })
  }
  function updateTrack(id: string, patch: Partial<TimelineTrack>) {
    props.onChange({ ...props.timeline, tracks: props.timeline.tracks.map((track) => track.id === id ? { ...track, ...patch } : track) })
  }
  function splitSelected() {
    if (!selected) return
    const cut = props.currentTime
    const projectOffset = cut - selected.startTime
    const sourceCut = selected.sourceIn + sourceDeltaForTimelineDelta(projectOffset, selected.speed)
    if (sourceCut <= selected.sourceIn + 0.05 || sourceCut >= selected.sourceOut - 0.05) return
    const right: TimelineItem = { ...selected, id: crypto.randomUUID(), startTime: cut, sourceIn: sourceCut }
    props.onChange({ ...props.timeline, items: [...props.timeline.items.map((item) => item.id === selected.id ? { ...item, sourceOut: sourceCut } : item), right] })
    setSelectedId(right.id)
    props.onSelectItem?.(right)
  }
  function duplicateSelected() {
    if (!selected) return
    const duplicate = { ...selected, id: crypto.randomUUID(), startTime: timelineItemEnd(selected) }
    props.onChange({ ...props.timeline, items: [...props.timeline.items, duplicate] })
    setSelectedId(duplicate.id)
    props.onSelectItem?.(duplicate)
  }
  function deleteSelected() {
    if (!selected) return
    props.onChange({ ...props.timeline, items: props.timeline.items.filter((item) => item.id !== selected.id) })
    setSelectedId(null)
    props.onSelectItem?.(null)
  }
  function setSnap() { props.onChange({ ...props.timeline, snapEnabled: !props.timeline.snapEnabled }) }

  return <section className="multi-track-editor" aria-label="Multi-track timeline editor">
    <div className="multi-track-toolbar">
      <div><strong>Timeline layers</strong><span className="tiny muted"> Drop assets or Windows files onto a matching track Â· {pixelsPerSecond}px/s</span></div>
      <div className="row wrap">
        <button className="btn ghost sm icon" onClick={props.onUndo} disabled={!props.canUndo} title="Undo timeline edit"><Undo2 size={13} /></button>
        <button className="btn ghost sm icon" onClick={props.onRedo} disabled={!props.canRedo} title="Redo timeline edit"><Redo2 size={13} /></button>
        <button className={`btn sm${props.timeline.snapEnabled ? ' active' : ''}`} onClick={setSnap} title="Toggle magnet snapping"><Magnet size={13} /> Snap</button>
        <button className="btn sm" onClick={() => addTrack('video')}><Plus size={12} /> Video</button>
        <button className="btn sm" onClick={() => addTrack('audio')}><Plus size={12} /> Audio</button>
        <button className="btn sm" onClick={() => addTrack('image')}><Plus size={12} /> Image</button>
        <button className="btn ghost sm icon" onClick={() => setPixelsPerSecond((v) => Math.max(12, v / 1.25))} title="Zoom out"><ZoomOut size={13} /></button>
        <button className="btn ghost sm icon" onClick={() => setPixelsPerSecond((v) => Math.min(240, v * 1.25))} title="Zoom in"><ZoomIn size={13} /></button>
        <button className="btn ghost sm icon" onClick={() => { const laneWidth = scrollRef.current?.clientWidth ?? 1100; setPixelsPerSecond(Math.max(12, Math.min(240, (laneWidth - 150) / span))) }} title="Fit timeline to window"><Maximize2 size={13} /></button>
        <button className="btn ghost sm icon" onClick={splitSelected} disabled={!selected} title="Split selected clip at playhead"><Scissors size={13} /></button>
        <button className="btn ghost sm icon" onClick={duplicateSelected} disabled={!selected} title="Duplicate selected clip"><Copy size={13} /></button>
        <button className="btn ghost sm icon danger" onClick={deleteSelected} disabled={!selected} title="Remove selected timeline item"><Trash2 size={13} /></button>
      </div>
    </div>
    <div className="multi-track-scroll" ref={scrollRef} onPointerMove={updateHoverCursor} onPointerLeave={() => { if (!cursorDraggingRef.current) positionCursor(pinnedTimeRef.current ?? props.currentTime, false) }} onPointerDownCapture={beginCursorDrag}>
      <div className="multi-track-canvas" style={{ width }}>
        <div className="multi-track-ruler"><div className="multi-track-label">TRACKS</div><div className="multi-track-ruler-body">{ticks.map((time) => <button key={time} style={{ left: time * pixelsPerSecond }} onClick={() => seekTo(time)}>{formatClock(time, true)}<i /></button>)}</div></div>
        {props.sourceClip && <div className="multi-track-row source-track-row">
          <div className="multi-track-label"><span className="track-title"><Film size={13} /> Main source</span><small>{props.sourceClip.name}</small></div>
          <div className="multi-track-lane">
            <button className={`source-track-clip${props.selectedSource ? ' selected' : ''}`} style={{ left: props.sourceClip.startTime * pixelsPerSecond, width: Math.max(18, (props.sourceClip.endTime - props.sourceClip.startTime) * pixelsPerSecond) }} title="Main source clip · drag its edges to trim; click to select" onClick={() => { seekTo(props.sourceClip!.startTime); props.onSelectSource?.() }}>
              {props.sourceWaveform && <AudioWaveform peaks={props.sourceWaveform.peaks} duration={props.sourceWaveform.duration} sourceIn={props.sourceClip.startTime} sourceOut={props.sourceClip.endTime} />}
              {sourceFilmstripFrame && <span className="source-filmstrip" aria-hidden="true"><img src={mediaUrl(sourceFilmstripFrame.path)} alt="" draggable={false} /></span>}
              <span className="source-clip-title">{props.sourceClip.name}</span><small>{formatClock(props.sourceClip.startTime, true)} – {formatClock(props.sourceClip.endTime, true)}</small>
              <span className="source-trim-handle left" role="slider" tabIndex={0} aria-label="Trim source start" aria-valuemin={0} aria-valuemax={props.sourceClip.endTime} aria-valuenow={props.sourceClip.startTime} title="Drag to trim source start · arrow keys step one frame; Shift + arrow steps one second" onClick={(event) => event.stopPropagation()} onKeyDown={(event) => adjustSourceRangeByKey(event, 'start')} onPointerDown={(event) => beginEditDrag(event, { mode: 'source-left', startX: event.clientX, start: props.sourceClip!.startTime, end: props.sourceClip!.endTime })} />
              <span className="source-trim-handle right" role="slider" tabIndex={0} aria-label="Trim source end" aria-valuemin={props.sourceClip.startTime} aria-valuemax={span} aria-valuenow={props.sourceClip.endTime} title="Drag to trim source end · arrow keys step one frame; Shift + arrow steps one second" onClick={(event) => event.stopPropagation()} onKeyDown={(event) => adjustSourceRangeByKey(event, 'end')} onPointerDown={(event) => beginEditDrag(event, { mode: 'source-right', startX: event.clientX, start: props.sourceClip!.startTime, end: props.sourceClip!.endTime })} />
            </button>
            {props.silenceCuts?.map((cut, index) => {
              const start = cut.status === 'kept' ? (cut.detectedStart ?? cut.start) : cut.start
              const end = cut.status === 'kept' ? (cut.detectedEnd ?? cut.end) : cut.end
              return <div key={`${cut.detectedStart ?? cut.start}-${index}`} className={`source-cut-region${cut.status === 'kept' ? ' kept' : ''}${props.selectedSilenceIndex === index ? ' selected' : ''}`} style={{ left: start * pixelsPerSecond, width: Math.max(4, (end - start) * pixelsPerSecond) }} title={`${cut.status === 'kept' ? 'Kept' : 'Removed'} pause · drag either edge to adjust`} onClick={() => { seekTo(start); props.onSelectSilence?.(index) }}>
                {cut.status !== 'kept' && <><button className="source-cut-handle left" aria-label="Adjust pause start" onPointerDown={(event) => { props.onSelectSilence?.(index); beginEditDrag(event, { mode: 'silence-left', startX: event.clientX, index, start: cut.start, end: cut.end, min: cut.detectedStart ?? props.sourceClip!.startTime, max: cut.detectedEnd ?? props.sourceClip!.endTime }) }} /><button className="source-cut-handle right" aria-label="Adjust pause end" onPointerDown={(event) => { props.onSelectSilence?.(index); beginEditDrag(event, { mode: 'silence-right', startX: event.clientX, index, start: cut.start, end: cut.end, min: cut.detectedStart ?? props.sourceClip!.startTime, max: cut.detectedEnd ?? props.sourceClip!.endTime }) }} /></>}
              </div>
            })}
          </div>
        </div>}
        {props.captions && props.captions.length > 0 ? (
          <div className="multi-track-row caption-track-row">
            <div className="multi-track-label"><span className="track-title"><Type size={13} /> Captions</span><small>{props.captions.length} blocks</small></div>
            <div className="multi-track-lane">
              {props.captions.map((caption) => (
                <button key={caption.key} className={`timeline-caption-block${props.selectedCaptionKey === caption.key ? ' selected' : ''}`}
                  style={{ left: caption.startTime * pixelsPerSecond, width: Math.max(20, (caption.endTime - caption.startTime) * pixelsPerSecond) }}
                  title={`${caption.text} · drag to move; drag the edges to adjust timing`}
                  onPointerDown={(event) => {
                    props.onSelectCaption?.(caption.key)
                    beginEditDrag(event, { mode: 'caption', startX: event.clientX, key: caption.key, start: caption.startTime, offset: props.captionOffsets?.[caption.key] ?? 0 })
                  }}
                  onClick={() => { seekTo(caption.startTime); props.onSelectCaption?.(caption.key) }}>
                  <span className="caption-trim-handle left" aria-label="Adjust caption start" onClick={(event) => event.stopPropagation()} onPointerDown={(event) => {
                    event.stopPropagation()
                    const offset = props.captionOffsets?.[`${caption.key}/start`] ?? props.captionOffsets?.[caption.key] ?? 0
                    beginEditDrag(event, { mode: 'caption-left', startX: event.clientX, key: caption.key, start: caption.startTime, offset })
                  }} />
                  {caption.text}
                  <span className="caption-trim-handle right" aria-label="Adjust caption end" onClick={(event) => event.stopPropagation()} onPointerDown={(event) => {
                    event.stopPropagation()
                    const offset = props.captionOffsets?.[`${caption.key}/end`] ?? props.captionOffsets?.[caption.key] ?? 0
                    beginEditDrag(event, { mode: 'caption-right', startX: event.clientX, key: caption.key, start: caption.startTime, offset })
                  }} />
                </button>
              ))}
            </div>
          </div>
        ) : null}
        {props.textLayers && <div className="multi-track-row text-track-row">
          <div className="multi-track-label"><span className="track-title"><Type size={13} /> Text / graphics</span><small>{props.textLayers.length} layers</small></div>
          <div className="multi-track-lane">{props.textLayers.length === 0 && <span className="timeline-empty-track">Add a layer from Text to place it here.</span>}{props.textLayers.map((layer) => <div key={layer.id} className={`timeline-text-block${props.selectedTextLayerId === layer.id || selectedId === `text:${layer.id}` ? ' selected' : ''}`} style={{ left: layer.startTime * pixelsPerSecond, width: Math.max(24, (layer.endTime - layer.startTime) * pixelsPerSecond) }} title={`${layer.text || 'Text layer'} · drag to move; drag edges to trim`} onClick={() => { props.onSelectTextLayer?.(layer); seekTo(layer.startTime) }} onPointerDown={(event) => { props.onSelectTextLayer?.(layer); setSelectedId(`text:${layer.id}`); beginEditDrag(event, { mode: 'text', startX: event.clientX, layer }) }}><span className="text-trim-handle left" onClick={(event) => event.stopPropagation()} onPointerDown={(event) => { event.stopPropagation(); props.onSelectTextLayer?.(layer); beginEditDrag(event, { mode: 'text-left', startX: event.clientX, layer }) }} />{layer.text || 'Text layer'}<span className="text-trim-handle right" onClick={(event) => event.stopPropagation()} onPointerDown={(event) => { event.stopPropagation(); props.onSelectTextLayer?.(layer); beginEditDrag(event, { mode: 'text-right', startX: event.clientX, layer }) }} /></div>)}</div>
        </div>}
        {(props.cameraKeyframes?.length || props.trackingKeyframes?.length) ? <div className="multi-track-row camera-track-row"><div className="multi-track-label"><span className="track-title"><Film size={13} /> Camera / tracking</span><small>{props.cameraKeyframes?.length ?? 0} keyframes</small></div><div className="multi-track-lane">{props.trackingKeyframes?.map((keyframe, index) => <button key={`track-${keyframe.time}-${index}`} className={`timeline-tracking-marker${selectedTrackingTime === keyframe.time ? ' selected' : ''}`} style={{ left: keyframe.time * pixelsPerSecond }} title={`Tracking sample · ${formatClock(keyframe.time, true)} · ${Math.round(keyframe.score * 100)}% confidence`} onClick={() => { setSelectedTrackingTime(keyframe.time); seekTo(keyframe.time); props.onSelectTrackingKeyframe?.(keyframe) }}>•</button>)}{props.cameraKeyframes?.map((keyframe, index) => <button key={`${keyframe.time}-${index}`} className={`timeline-keyframe-marker${props.selectedCameraKeyframeTime !== null && Math.abs(keyframe.time - (props.selectedCameraKeyframeTime ?? -100)) < frameTimeTolerance(props.fps) ? ' selected' : ''}`} style={{ left: keyframe.time * pixelsPerSecond }} title={`Camera keyframe ${formatClock(keyframe.time, true)} · ${keyframe.easing}`} onPointerDown={(event) => { props.onSelectCameraKeyframe?.(keyframe.time); beginEditDrag(event, { mode: 'camera', startX: event.clientX, time: keyframe.time }) }}>◆</button>)}</div></div> : null}
        {[...props.timeline.tracks].sort((a, b) => a.order - b.order).map((track) => {
          const TrackIcon = track.type === 'audio' ? AudioLines : track.type === 'image' ? Eye : Volume2
          return <div className={`multi-track-row ${dragTarget === track.id ? 'drop-target' : ''} ${track.hidden ? 'track-hidden' : ''}`} key={track.id} onDragOver={(event) => { event.preventDefault(); setDragTarget(track.id); setDropTime(timeFromEvent(event, track)) }} onDragLeave={() => { setDragTarget(null); setDropTime(null) }} onDrop={(event) => onDrop(event, track)}>
            <div className="multi-track-label">
              <span className="track-title"><TrackIcon size={13} /> <input aria-label="Track name" value={track.name} onChange={(event) => updateTrack(track.id, { name: event.target.value })} /></span>
              <span className="track-tools">
                {track.type === 'audio' && <button title={track.muted ? 'Unmute track' : 'Mute track'} onClick={() => updateTrack(track.id, { muted: !track.muted })}>{track.muted ? <VolumeX size={12} /> : <Volume2 size={12} />}</button>}
                {track.type !== 'audio' && <button title={track.hidden ? 'Show track' : 'Hide track'} onClick={() => updateTrack(track.id, { hidden: !track.hidden })}>{track.hidden ? <EyeOff size={12} /> : <Eye size={12} />}</button>}
                <button title={track.locked ? 'Unlock track' : 'Lock track'} onClick={() => updateTrack(track.id, { locked: !track.locked })}>{track.locked ? <Lock size={12} /> : <Unlock size={12} />}</button>
              </span>
            </div>
            <div className="multi-track-lane">
              {dragTarget === track.id && dropTime != null && <div className="multi-track-drop-line" style={{ left: dropTime * pixelsPerSecond }} />}
              {props.timeline.items.filter((item) => item.trackId === track.id).map((item) => {
                const asset = assetById.get(item.assetId)
                const duration = timelineItemDuration(item)
                return <div key={item.id} className={`multi-track-item ${track.type} ${selectedId === item.id || props.selectedItemId === item.id ? 'selected' : ''} ${asset?.missing ? 'missing' : ''}`} style={{ left: item.startTime * pixelsPerSecond, width: Math.max(18, duration * pixelsPerSecond), opacity: track.hidden ? 0.45 : 1 }} title={`${asset?.name ?? 'Missing media'} Â· ${formatClock(item.startTime, true)} Â· ${formatClock(duration, true)}`} onClick={() => { setSelectedId(item.id); seekTo(item.startTime); props.onSelectItem?.(item) }} onContextMenu={(event) => { event.preventDefault(); setSelectedId(item.id); seekTo(item.startTime); props.onSelectItem?.(item) }}>
                  <button className="timeline-trim left" aria-label="Trim clip start" onPointerDown={(event) => beginDrag(event, item, 'left')} />
                  <button className="timeline-trim right" aria-label="Trim clip end" onPointerDown={(event) => beginDrag(event, item, 'right')} />
                  {asset && asset.mediaType !== 'audio' && asset.thumbnailPath && <img className="timeline-item-thumbnail" src={mediaUrl(asset.thumbnailPath)} alt="" draggable={false} />}
                  {asset?.mediaType === 'audio' && props.waveforms[asset.id] && <AudioWaveform peaks={props.waveforms[asset.id].peaks} duration={props.waveforms[asset.id].duration} sourceIn={item.sourceIn} sourceOut={item.sourceOut} />}
                  <button className="timeline-item-body" onPointerDown={(event) => beginDrag(event, item, 'move')} onDoubleClick={() => seekTo(item.startTime)}>{asset?.name ?? 'Media Missing'} <span>{formatClock(item.startTime, true)}</span></button>
                </div>
              })}
            </div>
          </div>
        })}
        <div ref={cursorRef} className="multi-track-cursor" aria-hidden="true"><span ref={cursorLabelRef} /></div>
      </div>
    </div>
  </section>
}

function AudioWaveform(props: { peaks: number[]; duration: number; sourceIn: number; sourceOut: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  React.useEffect(() => {
    const canvas = canvasRef.current
    const parent = canvas?.parentElement
    if (!canvas || !parent || props.duration <= 0) return
    const draw = () => {
      const width = Math.max(1, parent.clientWidth)
      const height = Math.max(1, parent.clientHeight)
      const dpr = window.devicePixelRatio || 1
      canvas.width = Math.round(width * dpr); canvas.height = Math.round(height * dpr)
      const context = canvas.getContext('2d')
      if (!context) return
      context.setTransform(dpr, 0, 0, dpr, 0, 0)
      context.clearRect(0, 0, width, height)
      context.fillStyle = 'rgba(186, 224, 194, .8)'
      const start = Math.max(0, Math.floor(props.sourceIn / props.duration * props.peaks.length))
      const end = Math.min(props.peaks.length, Math.ceil(props.sourceOut / props.duration * props.peaks.length))
      const count = Math.max(1, end - start)
      for (let x = 0; x < width; x++) {
        const i = Math.min(end - 1, start + Math.floor(x / width * count))
        const amp = props.peaks[i] ?? 0
        const bar = Math.max(1, amp * (height - 8))
        context.fillRect(x, (height - bar) / 2, 1, bar)
      }
    }
    draw()
    const observer = new ResizeObserver(draw)
    observer.observe(parent)
    return () => observer.disconnect()
  }, [props.peaks, props.duration, props.sourceIn, props.sourceOut])
  return <canvas className="timeline-wave-canvas" aria-label="Source audio waveform" />
}

export function TimelineInspector(props: { item: TimelineItem; asset?: ProjectAsset; onChange: (patch: Partial<TimelineItem>) => void }) {
  return <div className="timeline-inspector">
    <strong>{props.asset?.name ?? 'Missing media'}</strong>
    <label>Start <input type="number" min="0" step="0.01" value={props.item.startTime.toFixed(2)} onChange={(event) => props.onChange({ startTime: Math.max(0, Number(event.target.value)) })} /></label>
    <label>Source in <input type="number" min="0" step="0.01" value={props.item.sourceIn.toFixed(2)} onChange={(event) => props.onChange({ sourceIn: Math.max(0, Math.min(props.item.sourceOut - 0.05, Number(event.target.value))) })} /></label>
    <label>Source out <input type="number" min="0" step="0.01" value={props.item.sourceOut.toFixed(2)} onChange={(event) => props.onChange({ sourceOut: Math.max(props.item.sourceIn + 0.05, Number(event.target.value)) })} /></label>
    {props.asset?.mediaType !== 'image' && <label>Volume <input type="range" min="0" max="2" step="0.01" value={props.item.volume} onChange={(event) => props.onChange({ volume: Number(event.target.value) })} /><span>{Math.round(props.item.volume * 100)}%</span></label>}
    {props.asset?.mediaType === 'audio' && <>
      <label>Fade in <input type="number" min="0" max="30" step="0.05" value={props.item.fadeIn} onChange={(event) => props.onChange({ fadeIn: Math.max(0, Number(event.target.value)) })} /></label>
      <label>Fade out <input type="number" min="0" max="30" step="0.05" value={props.item.fadeOut} onChange={(event) => props.onChange({ fadeOut: Math.max(0, Number(event.target.value)) })} /></label>
      <label>Speed <input type="number" min="0.25" max="4" step="0.05" value={props.item.speed} onChange={(event) => props.onChange({ speed: Math.max(0.25, Math.min(4, Number(event.target.value))) })} /></label>
      <label><input type="checkbox" checked={props.item.muted} onChange={(event) => props.onChange({ muted: event.target.checked })} /> Mute this clip</label>
      <label><input type="checkbox" checked={props.item.loop} onChange={(event) => props.onChange({ loop: event.target.checked })} /> Loop audio</label>
    </>}
    {props.asset?.mediaType === 'video' && <>
      <label>Speed <input type="number" min="0.25" max="4" step="0.05" value={props.item.speed} onChange={(event) => props.onChange({ speed: Math.max(0.25, Math.min(4, Number(event.target.value))) })} /></label>
      <label><input type="checkbox" checked={props.item.muted} onChange={(event) => props.onChange({ muted: event.target.checked })} /> Mute clip audio</label>
    </>}
    {props.asset?.mediaType === 'image' && <>
      <label>Duration <input type="number" min="0.1" step="0.1" value={timelineItemDuration(props.item).toFixed(1)} onChange={(event) => props.onChange({ sourceIn: 0, sourceOut: Math.max(0.1, Number(event.target.value)) })} /></label>
      <label>Opacity <input type="range" min="0" max="1" step="0.01" value={props.item.opacity} onChange={(event) => props.onChange({ opacity: Number(event.target.value) })} /></label>
      <label>Scale <input type="number" min="0.1" max="5" step="0.05" value={props.item.scale} onChange={(event) => props.onChange({ scale: Number(event.target.value) })} /></label>
    </>}
  </div>
}
