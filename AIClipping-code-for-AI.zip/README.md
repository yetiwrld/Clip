# Clipwright Studio

**A local-first AI video clipping & content repurposing studio.**

Clipwright Studio turns long-form video (podcasts, interviews, lectures,
webinars, talking-head recordings) into polished short-form vertical clips —
with transcription, AI-assisted clip discovery, performance audit estimates,
captioning, a clip editor, and local FFmpeg rendering.

- **Local-first**: your media stays on your machine. Nothing is uploaded
  unless you explicitly configure an external AI provider (and only the data
  that operation needs — e.g. transcript text, never the source video).
- **Modular providers**: transcription (local faster-whisper, OpenAI-compatible
  cloud, SRT/VTT/JSON import) and analysis (any OpenAI-compatible endpoint,
  Anthropic, or a built-in offline heuristic analyzer) are pluggable.
- **You stay in control**: the AI recommends moments and explains why; every
  clip, caption, crop and metadata field remains editable.

## Run on Windows (development version)

The repository download contains the **source code**, not a prebuilt installer.
Use these steps to run the desktop app on Windows 10/11 x64.

1. Install **Node.js 22 LTS** from [nodejs.org](https://nodejs.org/). Node.js 20+
   is supported; Node 22 is the tested/recommended version. The installer also
   installs npm and adds both commands to `PATH`.
2. Download `AIClipping-code-for-AI.zip` from the repository and use File
   Explorer's **Extract All…** option. Extract it to a normal writable folder,
   for example `C:\ClipwrightStudio` (not inside `Program Files`).
3. Open PowerShell in that extracted folder. Confirm that `package.json` is in
   the current directory, then run:

   ```powershell
   node --version
   npm --version
   npm ci
   npm run dev
   ```

   `npm ci` installs the locked dependencies, including Electron and the
   FFmpeg/FFprobe packages. The first install needs an internet connection.
   Electron 44 downloads its platform binary separately; `npm run dev` runs
   that download automatically before opening Clipwright Studio. If the first
   launch reports `Electron uninstall`, run `npm exec -- install-electron`
   once, then retry `npm run dev`.
4. In the app, create a project and import a video. The built-in heuristic
   analyzer works offline; transcription can be imported from SRT/VTT/JSON.
   Cloud AI providers and local Whisper are optional.

No separate FFmpeg installation is normally needed. For local Whisper
transcription, install Python and faster-whisper separately; the model is
obtained on first use. Your projects and settings are saved locally in the
Clipwright Studio workspace.

## Build a Windows installer (optional)

From the same PowerShell window and project folder, run:

```powershell
npm run dist:win
```

The expected output is `dist\Clipwright Studio-0.1.0-setup-x64.exe`. This
command builds an installer from source; the repository ZIP itself is not an
installer.

## Tests and other development commands

Generated test media is intentionally not included in the source ZIP. To run
the full tests, generate the fixtures first:

```powershell
npm run fixtures
npm test              # 265 total (176 unit + 89 integration)
npm run typecheck
npm run build
```

Other useful commands:

```powershell
npm run preview:web   # optional browser preview at http://localhost:8787
npm run test:unit
npm run test:integration
```

The browser preview is for development; `npm run dev` is the normal way to
open the desktop app.

## Status and documentation

See `docs/DEVELOPMENT_PLAN.md`, `docs/TASKS.md`, `docs/CHANGELOG.md`,
`docs/QA_REPORT.md`, and `docs/RELEASE_CHECKLIST.md` for implementation status,
verification, and known manual checks.

## License

MIT. Bundled Inter, IBM Plex Sans Condensed, and Source Serif 4 fonts are
licensed under the SIL Open Font License; see `resources/fonts/OFL.txt` and
`docs/FONT_LICENSES.md`.
