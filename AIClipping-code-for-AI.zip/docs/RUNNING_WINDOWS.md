# Running Clipwright Studio

Exact commands, verified in this repository (see `docs/QA_REPORT.md` for what
was executed and what remains to be verified on a real Windows machine).

## Prerequisites

| Requirement | Notes |
| --- | --- |
| **Node.js 20+** | Node 22 is the tested/recommended release; `npm` comes with it. |
| **npm 10+** | Package manager used by the repository (`package-lock.json` present). |
| **Windows 10/11 x64** | Primary target for the packaged app. macOS/Linux work for development. |

That's all — FFmpeg and FFprobe are npm dependencies (`@ffmpeg-installer` /
`@ffprobe-installer`) and ship inside the app. Caption fonts are bundled in
`resources/fonts`. No Python is required unless you enable local Whisper
transcription (the helper script is bundled; the Whisper model downloads on
first use).

## Install

```text
npm ci
```

Verified: completes with `0 vulnerabilities` (Node 22, npm 10).

Electron 44 provides a separate `install-electron` command for its platform
binary. The project's `predev` and `prestart` scripts run it automatically
before launching the desktop app. If launch reports `Electron uninstall`, run
`npm exec -- install-electron` once, then retry `npm run dev`. The download
requires internet access; corporate proxies that intercept TLS may need
`NODE_EXTRA_CA_CERTS` configured.

## Test fixtures (optional, needed for `npm test`)

```text
npm run fixtures
```

Generates `tests/fixtures/media/sample.mp4` (60s, 1280×720),
`tests/fixtures/media/silence.mp4` (8.5s tone → 2.5s silence → tone),
`tests/fixtures/media/incompatible.avi` (MPEG-4 video + MP3 audio, for proxy
playback coverage), and `tests/fixtures/transcript.json` with real FFmpeg. The
files are gitignored — run this once after checkout, or the integration suites
will skip/fail with "Test fixtures are missing".

## Type checking

```text
npm run typecheck
```

Verified: clean for both the Node (main/preload) and Web (renderer) projects.

## Tests

```text
npm test
```

Verified on 2026-10-01: **265/265 passing** (176 unit + 89 integration
across 26 files). Also available separately:

```text
npm run test:unit
npm run test:integration
```

## Development (desktop app)

```text
npm run dev
```

This is the standard command for this repository (`electron-vite dev`): starts
the Vite dev server with hot reload and launches the Electron app.

> Not executable inside this QA sandbox (headless Linux, no display, blocked
> Electron binary CDN) — run it on your Windows machine. The production build,
> full automated suite, and preview backend API are verified here; visual
> interaction in a browser has not been automated.

## Browser preview (no Electron, same backend)

```text
npm run preview:web
```

Verified: serves the built renderer at `http://localhost:8787` with the real
backend services (SQLite + FFmpeg) behind an HTTP bridge. Preview API and
upload-origin safeguards were smoke-tested; file picking, folder reveal and
clipboard fall back to browser alternatives. Open a clip manually to confirm
the stage renders correctly.

## Production build (compile only)

```text
npm run build
```

Verified on 2026-10-01: clean — main 335.33 kB, preload 0.65 kB,
renderer 1,184.78 kB JS + 76.75 kB CSS.

## Windows installer / portable build

```text
npm run dist:win
```

Produces (per `electron-builder.yml`):

```text
dist/Clipwright Studio-0.1.0-setup-x64.exe    NSIS installer
dist/win-unpacked/                            unpacked app directory
```

> Status in this QA: the packaging pipeline starts correctly (native rebuild
> for win32/x64 completed, `dist/win-unpacked` packaging began) but could not
> finish inside the sandbox because the Windows Electron binary download is
> blocked by the sandbox's filtered network (`unable to verify the first
> certificate` fetching the Electron release CDN). **Run `npm run dist:win` on
> a machine with normal internet access** — no project changes are expected to
> be needed. This is documented as NOT TESTED-to-completion in
> `docs/QA_REPORT.md`.

## First run

On first launch the app checks FFmpeg/FFprobe and shows the environment
check. Then: **Projects → create → import a video → transcript → moments →
clip → editor → render → export.** AI providers are optional — the local
heuristic analyzer works fully offline (see `docs/API_SETUP.md`).

## Where your data lives

Workspace root (configurable, default under the OS user-data directory as
`ClipwrightStudio`): per-project folders (`source/`, `renders/`, `thumbnails/`,
`analysis/`), `exports/`, `logs/`, `secrets.json` (API keys, mode 0600, OS
keychain-encrypted where available). Nothing is uploaded anywhere unless you
configure an AI provider (transcript text only — never video files).
