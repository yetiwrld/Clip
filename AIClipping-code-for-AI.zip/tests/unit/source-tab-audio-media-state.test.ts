import fs from 'node:fs'
import path from 'node:path'
import ts from 'typescript'
import { describe, expect, it } from 'vitest'

const sourcePath = path.resolve(process.cwd(), 'src/renderer/features/project/SourceTab.tsx')
const source = ts.createSourceFile(sourcePath, fs.readFileSync(sourcePath, 'utf8'), ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX)

function descendants(node: ts.Node): ts.Node[] {
  const found: ts.Node[] = []
  const visit = (child: ts.Node): void => {
    found.push(child)
    ts.forEachChild(child, visit)
  }
  visit(node)
  return found
}

function readsEventCurrentTarget(node: ts.Node): boolean {
  return ts.isPropertyAccessExpression(node)
    && node.name.text === 'currentTarget'
    && ts.isIdentifier(node.expression)
    && node.expression.text === 'event'
}

function readsMediaProperty(node: ts.Node, property: string): boolean {
  return ts.isPropertyAccessExpression(node)
    && node.name.text === property
    && ts.isPropertyAccessExpression(node.expression)
    && readsEventCurrentTarget(node.expression)
}

function findAudioElement(): ts.JsxSelfClosingElement | undefined {
  return descendants(source).find((node): node is ts.JsxSelfClosingElement =>
    ts.isJsxSelfClosingElement(node) && node.tagName.getText(source) === 'audio'
  )
}

const audio = findAudioElement()

describe('SourceTab audio-only media state', () => {
  it('renders the audio player in the audio-first project branch', () => {
    expect(audio, 'SourceTab should render an audio player').toBeDefined()
    let inAudioFirstBranch = false
    for (let parent: ts.Node | undefined = audio; parent; parent = parent.parent) {
      if (ts.isConditionalExpression(parent)
        && parent.condition.getText(source) === "project.sourceMode === 'audio-first'"
        && parent.whenTrue.pos <= audio!.pos
        && audio!.end <= parent.whenTrue.end) {
        inAudioFirstBranch = true
        break
      }
    }
    expect(inAudioFirstBranch).toBe(true)
  })

  it.each([
    ['onLoadedMetadata', 'duration'],
    ['onTimeUpdate', 'currentTime'],
    ['onSeeked', 'currentTime'],
    ['onCanPlay', 'readyState']
  ])('%s snapshots %s before scheduling the state update', (handlerName, mediaProperty) => {
    expect(audio, 'SourceTab should render an audio-only player').toBeDefined()

    const attribute = audio!.attributes.properties.find((property): property is ts.JsxAttribute =>
      ts.isJsxAttribute(property) && property.name.getText(source) === handlerName
    )
    expect(attribute?.initializer && ts.isJsxExpression(attribute.initializer)).toBe(true)
    const handler = (attribute!.initializer as ts.JsxExpression).expression
    expect(handler && ts.isArrowFunction(handler) && ts.isBlock(handler.body)).toBe(true)
    const body = (handler as ts.ArrowFunction).body as ts.Block

    const captureDeclaration = body.statements
      .filter(ts.isVariableStatement)
      .flatMap((statement) => statement.declarationList.declarations)
      .find((declaration) => declaration.initializer
        && descendants(declaration.initializer).some((node) => readsMediaProperty(node, mediaProperty)))
    expect(captureDeclaration?.name && ts.isIdentifier(captureDeclaration.name)).toBe(true)

    const setStateCall = descendants(body).find((node): node is ts.CallExpression =>
      ts.isCallExpression(node) && ts.isIdentifier(node.expression) && node.expression.text === 'setMediaState'
    )
    expect(setStateCall, `${handlerName} should update media state`).toBeDefined()
    const updater = setStateCall!.arguments[0]
    expect(updater && ts.isArrowFunction(updater)).toBe(true)

    const captureStatementIndex = body.statements.findIndex((statement) =>
      ts.isVariableStatement(statement) && descendants(statement).includes(captureDeclaration!)
    )
    const setStateStatementIndex = body.statements.findIndex((statement) =>
      descendants(statement).includes(setStateCall!)
    )
    expect(captureStatementIndex).toBeGreaterThanOrEqual(0)
    expect(captureStatementIndex).toBeLessThan(setStateStatementIndex)

    const updaterNodes = descendants(updater!)
    expect(updaterNodes.some(readsEventCurrentTarget)).toBe(false)
    expect(updaterNodes.some((node) => ts.isIdentifier(node)
      && node.text === (captureDeclaration!.name as ts.Identifier).text)).toBe(true)
  })
})
