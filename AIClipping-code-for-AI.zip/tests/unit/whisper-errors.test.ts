import { describe, expect, it } from 'vitest'
import { createWhisperFailure } from '../../src/main/services/transcription/index'

describe('local Whisper failures', () => {
  it('turns no-speech results into a clear empty-transcript error', () => {
    const error = createWhisperFailure(
      { code: 'NO_SPEECH', message: 'No speech segments were detected in this audio.' },
      '',
      '{"error":{"code":"NO_SPEECH"}}'
    )

    expect(error.code).toBe('TRANSCRIPTION_EMPTY')
    expect(error.message).toContain('No speech segments')
    expect(error.details).toContain('NO_SPEECH')
  })

  it('surfaces the Python failure and retains useful stderr while dropping progress-only records', () => {
    const error = createWhisperFailure(
      { code: 'TRANSCRIPTION_FAILED', message: 'Invalid data found when processing input.' },
      '{"progress":0.62,"message":"Transcribing audio"}\nDecoder reported a corrupt packet',
      ''
    )

    expect(error.code).toBe('WHISPER_FAILED')
    expect(error.message).toContain('Invalid data found')
    expect(error.details).toContain('TRANSCRIPTION_FAILED')
    expect(error.details).toContain('corrupt packet')
    expect(error.details).not.toContain('0.62')
  })

  it('keeps the model-download hint for model-load failures', () => {
    const error = createWhisperFailure(
      { code: 'MODEL_LOAD_FAILED', message: 'Connection timed out' },
      '',
      ''
    )

    expect(error.code).toBe('WHISPER_MODEL_LOAD_FAILED')
    expect(error.message).toBe('Connection timed out')
    expect(error.hint).toContain('internet connection')
  })

  it('preserves raw process output when the helper emits no structured error', () => {
    const error = createWhisperFailure(undefined, 'RuntimeError: decoder crashed', 'partial output')

    expect(error.code).toBe('WHISPER_FAILED')
    expect(error.details).toContain('RuntimeError: decoder crashed')
    expect(error.details).toContain('partial output')
  })
})
