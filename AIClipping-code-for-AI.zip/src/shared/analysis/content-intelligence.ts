/**
 * Shared Content Intelligence catalog and persisted preference contracts.
 * The offline analyzer consumes the taxonomy as one signal among transcript
 * structure, discourse, context, timing and audio-derived cues; categories are
 * never treated as a keyword-only classifier.
 */

export const CONTENT_CATEGORIES = [
  {
    id: 'relationships-dating', label: 'Relationships & Dating',
    subcategories: [
      { id: 'dating-advice', label: 'Dating advice', terms: ['dating advice', 'dating', 'first date', 'relationship advice', 'red flag', 'green flag'] },
      { id: 'relationship-debates', label: 'Debates', terms: ['relationship debate', 'dating debate', 'who should pay', 'split the bill', 'men should', 'women should'] },
      { id: 'marriage-family', label: 'Marriage & family', terms: ['marriage', 'married', 'husband', 'wife', 'family', 'parenting', 'children'] },
      { id: 'breakups-cheating', label: 'Breakups & cheating', terms: ['breakup', 'broke up', 'cheating', 'cheated', 'affair', 'unfaithful', 'divorce'] },
      { id: 'gender-perspectives', label: 'Gender perspectives', terms: ['gender roles', 'as a man', 'as a woman', 'men and women', 'masculinity', 'femininity'] },
      { id: 'emotional-relationship-stories', label: 'Emotional stories', terms: ['heartbreak', 'fell in love', 'lost someone', 'miss them', 'relationship story', 'betrayed'] }
    ],
    terms: ['relationship', 'dating', 'marriage', 'married', 'partner', 'boyfriend', 'girlfriend', 'husband', 'wife', 'breakup', 'cheating', 'family', 'love', 'gender roles']
  },
  {
    id: 'money-business', label: 'Money & Business',
    subcategories: [
      { id: 'making-money', label: 'Making money', terms: ['make money', 'making money', 'income', 'earn', 'profit', 'revenue', 'cash flow'] },
      { id: 'entrepreneurship', label: 'Entrepreneurship', terms: ['entrepreneur', 'startup', 'small business', 'founder', 'business model', 'customer'] },
      { id: 'business-failures', label: 'Business failures', terms: ['business failed', 'startup failed', 'went bankrupt', 'lost the company', 'failure taught', 'shut down'] },
      { id: 'financial-lessons', label: 'Financial lessons', terms: ['save money', 'investing', 'investment', 'debt', 'budget', 'financial lesson', 'interest rate'] },
      { id: 'wealth-success', label: 'Wealth & success', terms: ['wealth', 'millionaire', 'billionaire', 'net worth', 'success', 'built a company', 'financial freedom'] },
      { id: 'negotiation-sales', label: 'Negotiation & sales', terms: ['negotiate', 'negotiation', 'sales', 'close the deal', 'pricing', 'customer objection'] },
      { id: 'opportunities', label: 'Opportunities', terms: ['opportunity', 'market gap', 'demand', 'untapped', 'business opportunity', 'new market'] }
    ],
    terms: ['money', 'business', 'company', 'startup', 'entrepreneur', 'profit', 'revenue', 'sales', 'wealth', 'invest', 'investment', 'customer', 'market', 'million', 'billion', 'salary', 'negotiate']
  },
  {
    id: 'storytelling', label: 'Storytelling',
    subcategories: [
      { id: 'personal-experiences', label: 'Personal experiences', terms: ['my experience', 'when i was', 'one time', 'i remember', 'this happened to me'] },
      { id: 'survival', label: 'Survival', terms: ['survived', 'survival', 'stranded', 'escaped', 'rescue', 'fight for my life'] },
      { id: 'unexpected-events', label: 'Unexpected events', terms: ['unexpected', 'out of nowhere', 'suddenly', 'never expected', 'what happened next'] },
      { id: 'life-changing-decisions', label: 'Life-changing decisions', terms: ['life changed', 'changed my life', 'decided to leave', 'big decision', 'starting over'] },
      { id: 'crime-mystery-stories', label: 'Crime & mystery', terms: ['mystery', 'crime', 'evidence', 'investigation', 'suspect', 'missing person'] },
      { id: 'childhood', label: 'Childhood', terms: ['when i was a kid', 'as a child', 'growing up', 'my childhood', 'at school'] },
      { id: 'overcoming-hardship', label: 'Overcoming hardship', terms: ['overcame', 'got through', 'hardest time', 'struggled', 'recovered', 'against all odds'] }
    ],
    terms: ['story', 'happened', 'remember', 'when i was', 'one day', 'then', 'suddenly', 'eventually', 'finally', 'survived', 'childhood', 'overcame']
  },
  {
    id: 'celebrity-pop-culture', label: 'Celebrity & Pop Culture',
    subcategories: [
      { id: 'interviews', label: 'Interviews', terms: ['interview', 'asked me', 'they asked', 'on set', 'during the interview'] },
      { id: 'revelations', label: 'Revelations', terms: ['revealed', 'never told anyone', 'first time i have said', 'behind the story', 'secret'] },
      { id: 'entertainment', label: 'Entertainment', terms: ['movie', 'film', 'music', 'album', 'show', 'series', 'performance'] },
      { id: 'controversies', label: 'Controversies', terms: ['controversy', 'backlash', 'cancelled', 'controversial', 'public response'] },
      { id: 'celebrity-careers', label: 'Careers', terms: ['career', 'audition', 'role', 'record deal', 'fame', 'industry'] },
      { id: 'behind-scenes', label: 'Behind-the-scenes', terms: ['behind the scenes', 'on set', 'what really happened', 'production', 'crew'] }
    ],
    terms: ['actor', 'actress', 'celebrity', 'singer', 'artist', 'movie', 'film', 'music', 'album', 'show', 'fame', 'interview', 'on set', 'backstage']
  },
  {
    id: 'motivation-self-improvement', label: 'Motivation & Self-Improvement',
    subcategories: [
      { id: 'discipline', label: 'Discipline', terms: ['discipline', 'consistency', 'show up every day', 'daily routine', 'keep going'] },
      { id: 'confidence', label: 'Confidence', terms: ['confidence', 'believe in yourself', 'self-worth', 'self doubt', 'speak up'] },
      { id: 'personal-development', label: 'Personal development', terms: ['personal growth', 'self improvement', 'become a better', 'develop yourself', 'mindset'] },
      { id: 'productivity', label: 'Productivity', terms: ['productivity', 'focus', 'time management', 'prioritize', 'procrastinate'] },
      { id: 'life-lessons', label: 'Lessons', terms: ['life lesson', 'i learned', 'taught me', 'lesson i wish', 'mistake taught'] },
      { id: 'resilience', label: 'Resilience', terms: ['resilience', 'bounced back', 'kept going', 'recovered', 'persevered'] },
      { id: 'advice-young-people', label: 'Advice for young people', terms: ['young people', 'when you are young', 'at your age', 'advice to my younger self'] }
    ],
    terms: ['discipline', 'confidence', 'growth', 'mindset', 'focus', 'habits', 'resilience', 'purpose', 'goals', 'consistency', 'productivity', 'motivation']
  },
  {
    id: 'technology-ai', label: 'Technology & AI',
    subcategories: [
      { id: 'tech-discoveries', label: 'Discoveries', terms: ['discovered', 'breakthrough', 'new research', 'new technology', 'scientists found'] },
      { id: 'tech-tools', label: 'Tools', terms: ['software tool', 'app', 'tool that', 'automation tool', 'workflow'] },
      { id: 'future-tech', label: 'Future tech', terms: ['future of technology', 'what comes next', 'robotics', 'quantum', 'autonomous'] },
      { id: 'technology-debates', label: 'Debates', terms: ['technology debate', 'should we use ai', 'privacy debate', 'regulation'] },
      { id: 'ai-jobs', label: 'AI & jobs', terms: ['ai will replace', 'artificial intelligence', 'jobs', 'workforce', 'automation', 'layoffs'] },
      { id: 'experiments', label: 'Experiments', terms: ['experiment', 'tested it', 'we tried', 'prototype', 'results showed'] },
      { id: 'tech-tutorials', label: 'Tutorials', terms: ['step by step', 'tutorial', 'how to use', 'setup', 'configuration'] }
    ],
    terms: ['technology', 'tech', 'software', 'computer', 'artificial intelligence', 'ai', 'model', 'robot', 'algorithm', 'automation', 'data', 'app', 'tool']
  },
  {
    id: 'comedy-entertainment', label: 'Comedy & Entertainment',
    subcategories: [
      { id: 'funny-conversations', label: 'Funny conversations', terms: ['funny conversation', 'that is hilarious', 'everyone started laughing', 'banter'] },
      { id: 'unexpected-answers', label: 'Unexpected answers', terms: ['did not expect that', 'unexpected answer', 'wrong answer', 'wait what'] },
      { id: 'punchlines', label: 'Punchlines', terms: ['punchline', 'the joke is', 'that is the joke', 'setup and punchline'] },
      { id: 'awkward-situations', label: 'Awkward situations', terms: ['awkward', 'embarrassing', 'cringe', 'did not know what to say'] },
      { id: 'reactions', label: 'Reactions', terms: ['reaction', 'reacted', 'their face', 'could not believe', 'everyone looked'] },
      { id: 'friendly-arguments', label: 'Friendly arguments', terms: ['friendly argument', 'we disagree', 'playful argument', 'just joking'] },
      { id: 'funny-stories', label: 'Funny stories', terms: ['funny story', 'this one time', 'the funniest thing', 'comedy story'] }
    ],
    terms: ['funny', 'laugh', 'laughed', 'hilarious', 'joke', 'comedy', 'awkward', 'ridiculous', 'punchline', 'reaction', 'banter']
  },
  {
    id: 'career-education', label: 'Career & Education',
    subcategories: [
      { id: 'career-advice', label: 'Advice', terms: ['career advice', 'my advice is', 'interview tip', 'what employers want'] },
      { id: 'salaries', label: 'Salaries', terms: ['salary', 'salaries', 'pay raise', 'compensation', 'hourly rate'] },
      { id: 'workplace-experiences', label: 'Workplace experiences', terms: ['at work', 'my boss', 'workplace', 'office', 'coworker', 'colleague'] },
      { id: 'job-interviews', label: 'Interviews', terms: ['job interview', 'hiring manager', 'asked in an interview', 'resume'] },
      { id: 'student-life', label: 'Student life', terms: ['student', 'university', 'college', 'campus', 'class', 'exam'] },
      { id: 'career-mistakes', label: 'Mistakes', terms: ['career mistake', 'wrong job', 'quit my job', 'bad manager', 'should have asked'] },
      { id: 'career-development', label: 'Development', terms: ['career development', 'promotion', 'skills', 'mentor', 'professional growth'] }
    ],
    terms: ['career', 'job', 'work', 'workplace', 'salary', 'boss', 'employee', 'student', 'school', 'college', 'university', 'interview', 'promotion', 'skills']
  },
  {
    id: 'fitness-health', label: 'Fitness & Health Education',
    subcategories: [
      { id: 'health-advice', label: 'Advice', terms: ['health advice', 'doctor', 'healthcare', 'medical advice', 'symptom'] },
      { id: 'demonstrations', label: 'Demonstrations', terms: ['watch me do', 'demonstration', 'exercise form', 'movement', 'technique'] },
      { id: 'transformations', label: 'Transformations', terms: ['transformation', 'lost weight', 'gained muscle', 'before and after', 'fitness journey'] },
      { id: 'nutrition', label: 'Nutrition', terms: ['nutrition', 'protein', 'calories', 'diet', 'meal', 'hydration'] },
      { id: 'training-mistakes', label: 'Training mistakes', terms: ['training mistake', 'wrong form', 'overtraining', 'injury', 'recovery'] },
      { id: 'healthy-lifestyles', label: 'Healthy lifestyles', terms: ['healthy lifestyle', 'sleep', 'wellbeing', 'mental health', 'daily movement'] }
    ],
    terms: ['fitness', 'health', 'exercise', 'workout', 'training', 'nutrition', 'muscle', 'strength', 'diet', 'sleep', 'recovery', 'wellbeing']
  },
  {
    id: 'psychology-human-behaviour', label: 'Psychology & Human Behaviour',
    subcategories: [
      { id: 'behaviour', label: 'Behaviour', terms: ['human behavior', 'human behaviour', 'people tend to', 'we behave', 'behavioral pattern'] },
      { id: 'social-psychology', label: 'Social psychology', terms: ['social psychology', 'group behavior', 'social influence', 'peer pressure'] },
      { id: 'communication', label: 'Communication', terms: ['communication', 'body language', 'listening', 'conversation', 'conflict resolution'] },
      { id: 'habits', label: 'Habits', terms: ['habit', 'routine', 'automatic behavior', 'break a habit', 'habit loop'] },
      { id: 'decisions', label: 'Decisions', terms: ['decision making', 'decision', 'choice', 'bias', 'risk perception'] },
      { id: 'attraction-social-dynamics', label: 'Attraction & social dynamics', terms: ['attraction', 'social dynamics', 'first impression', 'chemistry', 'status'] },
      { id: 'psychology-discoveries', label: 'Discoveries', terms: ['psychological study', 'research found', 'experiment showed', 'psychologists found'] }
    ],
    terms: ['psychology', 'behavior', 'behaviour', 'social', 'communication', 'habit', 'decision', 'attraction', 'memory', 'bias', 'brain', 'emotion']
  },
  {
    id: 'true-crime-mystery', label: 'True Crime & Mystery',
    subcategories: [
      { id: 'investigative-stories', label: 'Investigative stories', terms: ['investigation', 'investigated', 'case file', 'detective', 'investigator'] },
      { id: 'suspense-revelations', label: 'Suspense & revelations', terms: ['then we found', 'the reveal', 'what happened next', 'shocking discovery', 'plot twist'] },
      { id: 'crime-explanations', label: 'Explanations', terms: ['here is what happened', 'evidence shows', 'the timeline', 'case explained'] },
      { id: 'documented-cases', label: 'Documented cases', terms: ['documented case', 'court records', 'police report', 'official records'] },
      { id: 'evidence', label: 'Evidence', terms: ['evidence', 'forensic', 'fingerprint', 'witness', 'alibi', 'DNA'] },
      { id: 'investigation-narratives', label: 'Investigation narratives', terms: ['we followed the trail', 'suspect', 'missing', 'the clue', 'investigation revealed'] }
    ],
    terms: ['crime', 'murder', 'case', 'detective', 'evidence', 'suspect', 'investigation', 'court', 'forensic', 'mystery', 'missing', 'witness']
  },
  {
    id: 'sports', label: 'Sports',
    subcategories: [
      { id: 'athlete-stories', label: 'Athlete stories', terms: ['athlete', 'champion', 'training story', 'career started', 'team story'] },
      { id: 'sports-debates', label: 'Debates', terms: ['greatest of all time', 'sports debate', 'who is better', 'referee decision'] },
      { id: 'training-performance', label: 'Training & performance', terms: ['training', 'performance', 'recovery', 'personal best', 'conditioning'] },
      { id: 'tactics', label: 'Tactics', terms: ['tactic', 'strategy', 'formation', 'game plan', 'defense'] },
      { id: 'memorable-moments', label: 'Memorable moments', terms: ['final minute', 'last second', 'winning goal', 'comeback', 'record breaking'] },
      { id: 'sports-controversies', label: 'Controversies', terms: ['sports controversy', 'doping', 'suspension', 'controversial call', 'scandal'] }
    ],
    terms: ['sport', 'football', 'soccer', 'basketball', 'athlete', 'team', 'coach', 'match', 'game', 'champion', 'tournament', 'training', 'tactic']
  },
  {
    id: 'african-nigerian-conversations', label: 'African & Nigerian Conversations',
    subcategories: [
      { id: 'african-culture', label: 'Culture', terms: ['culture', 'tradition', 'custom', 'tribe', 'language', 'heritage'] },
      { id: 'african-experiences', label: 'African experiences', terms: ['in nigeria', 'in africa', 'growing up in nigeria', 'african experience', 'back home'] },
      { id: 'african-relationships', label: 'Relationships & marriage', terms: ['bride price', 'traditional marriage', 'family expectations', 'marriage in nigeria'] },
      { id: 'african-business', label: 'Business', terms: ['naira', 'small business in nigeria', 'market trader', 'african startup', 'business in africa'] },
      { id: 'social-discussions', label: 'Social discussions', terms: ['in our society', 'social issue', 'what people say', 'community discussion'] },
      { id: 'diaspora', label: 'Diaspora', terms: ['diaspora', 'moved abroad', 'living overseas', 'back home', 'immigrant experience'] },
      { id: 'african-humour', label: 'Humour', terms: ['african humour', 'nigerian humour', 'naija', 'wahala', 'omo', 'abeg'] }
    ],
    terms: ['nigeria', 'nigerian', 'africa', 'african', 'naira', 'lagos', 'abuja', 'naija', 'diaspora', 'yoruba', 'igbo', 'hausa', 'wahala']
  },
  {
    id: 'educational-informational', label: 'Educational & Informational',
    subcategories: [
      { id: 'facts', label: 'Facts', terms: ['fact', 'data shows', 'according to the study', 'statistic'] },
      { id: 'explanations', label: 'Explanations', terms: ['this means', 'the reason is', 'in other words', 'explained'] },
      { id: 'tutorials', label: 'Tutorials', terms: ['how to', 'step by step', 'first you', 'tutorial', 'follow these steps'] },
      { id: 'practical-knowledge', label: 'Practical knowledge', terms: ['practical tip', 'use this', 'in practice', 'you can apply', 'checklist'] },
      { id: 'misconceptions', label: 'Misconceptions', terms: ['common misconception', 'myth', 'not true', 'people get this wrong', 'actually'] },
      { id: 'discoveries', label: 'Discoveries', terms: ['discovery', 'research found', 'new finding', 'we discovered', 'breakthrough'] }
    ],
    terms: ['explain', 'explained', 'because', 'therefore', 'for example', 'research', 'study', 'fact', 'learn', 'tutorial', 'steps', 'evidence', 'means']
  },
  {
    id: 'general-mixed', label: 'General / Mixed Content',
    subcategories: [
      { id: 'mixed-conversation', label: 'Mixed conversation', terms: ['conversation', 'discussion', 'talking about', 'what do you think'] },
      { id: 'podcast-qa', label: 'Podcast Q&A', terms: ['question', 'answer', 'ask me', 'listener question', 'podcast'] },
      { id: 'variety', label: 'Variety / let the analyzer decide', terms: [] }
    ],
    terms: []
  }
] as const

export type ContentCategoryId = (typeof CONTENT_CATEGORIES)[number]['id']
export type ContentSubcategoryId = (typeof CONTENT_CATEGORIES)[number]['subcategories'][number]['id']

export const MOMENT_TYPES = [
  { id: 'controversial-statement', label: 'Controversial Statement', clipType: 'strong-opinion', terms: ['unpopular opinion', 'controversial', 'people will disagree', 'the truth is', 'i disagree'] },
  { id: 'shocking-revelation', label: 'Shocking Revelation', clipType: 'surprising-fact', terms: ['never told anyone', 'the truth came out', 'revealed', 'nobody knew', 'shocking'] },
  { id: 'emotional-story', label: 'Emotional Story', clipType: 'emotional-moment', terms: ['i cried', 'heartbreaking', 'lost someone', 'i was scared', 'i missed', 'emotional'] },
  { id: 'funny-unexpected-moment', label: 'Funny / Unexpected Moment', clipType: 'humor', terms: ['that was funny', 'everyone laughed', 'unexpected answer', 'awkward', 'punchline', 'hilarious'] },
  { id: 'powerful-lesson', label: 'Powerful Lesson', clipType: 'lesson', terms: ['i learned', 'the lesson', 'taught me', 'what i learned', 'mistake taught'] },
  { id: 'practical-advice', label: 'Practical Advice', clipType: 'advice', terms: ['you should', 'you need to', 'here is how', 'my advice', 'the key is', 'step by step'] },
  { id: 'interesting-discovery', label: 'Interesting Discovery', clipType: 'surprising-fact', terms: ['i discovered', 'research found', 'it turns out', 'we found', 'what surprised me'] },
  { id: 'strong-debate', label: 'Strong Debate', clipType: 'debate', terms: ['i disagree', 'you are wrong', 'but that is not', 'on the other hand', 'why would you'] },
  { id: 'personal-confession', label: 'Personal Confession', clipType: 'story', terms: ['i have to admit', 'to be honest', 'i never told', 'i was ashamed', 'i made a mistake'] },
  { id: 'inspiring-transformation', label: 'Inspiring Transformation', clipType: 'transformation', terms: ['everything changed', 'turned my life around', 'used to be', 'now i am', 'transformed'] },
  { id: 'suspenseful-story', label: 'Suspenseful Story', clipType: 'story', terms: ['suddenly', 'what happened next', 'then i heard', 'until one day', 'the door opened'] },
  { id: 'complete-story', label: 'Complete Story', clipType: 'story', terms: ['in the end', 'eventually', 'finally', 'after that', 'that is how it ended'] },
  { id: 'educational-explanation', label: 'Educational Explanation', clipType: 'question-answer', terms: ['this is why', 'the reason', 'for example', 'that means', 'step by step'] },
  { id: 'automatic-best', label: 'Automatically Select Best Moments', clipType: 'other', terms: [] },
  { id: 'all-moments', label: 'All Moments', clipType: 'other', terms: [] }
] as const

export type MomentTypeId = (typeof MOMENT_TYPES)[number]['id']
export type CandidateMomentTypeId = Exclude<MomentTypeId, 'automatic-best' | 'all-moments'>

export const AUDIENCES = [
  { id: 'general', label: 'General' },
  { id: 'young-adults', label: 'Young adults' },
  { id: 'entrepreneurs', label: 'Entrepreneurs' },
  { id: 'students', label: 'Students' },
  { id: 'professionals', label: 'Professionals' },
  { id: 'entertainment-viewers', label: 'Entertainment viewers' },
  { id: 'african-audience', label: 'African audience' },
  { id: 'international-audience', label: 'International audience' },
  { id: 'custom', label: 'Custom' }
] as const
export type AudienceId = (typeof AUDIENCES)[number]['id']

export const DURATION_CHOICES = [
  { id: '15-30', label: '15–30 seconds', min: 15, max: 30 },
  { id: '30-45', label: '30–45 seconds', min: 30, max: 45 },
  { id: '45-60', label: '45–60 seconds', min: 45, max: 60 },
  { id: '60-90', label: '60–90 seconds', min: 60, max: 90 },
  { id: '90-180', label: '90–180 seconds', min: 90, max: 180 }
] as const
export type DurationChoiceId = (typeof DURATION_CHOICES)[number]['id']

export const DISCOVERY_MODES = [
  { id: 'balanced', label: 'Balanced', description: 'Balance hook, clarity, context and payoff.' },
  { id: 'high-engagement', label: 'High Engagement Potential', description: 'Emphasize hooks, curiosity, emotion and discussion value.' },
  { id: 'educational-value', label: 'Educational Value', description: 'Emphasize clear explanations, useful information and takeaways.' },
  { id: 'storytelling', label: 'Storytelling', description: 'Emphasize narrative progression, suspense and a satisfying ending.' },
  { id: 'emotional-moments', label: 'Emotional Moments', description: 'Emphasize personal stakes and emotional resolution.' },
  { id: 'debate-discussion', label: 'Debate & Discussion', description: 'Emphasize a clear claim, counterpoint and substantive exchange.' },
  { id: 'strict-quality', label: 'Strict Quality', description: 'Prefer clean context, intelligibility and complete payoff; return fewer moments.' }
] as const
export type DiscoveryModeId = (typeof DISCOVERY_MODES)[number]['id']

export const ANALYSIS_ENGINES = [
  { id: 'heuristic-local', label: 'Local Heuristic Analyzer', description: 'Offline, deterministic transcript-structure analysis; not a generative AI model.' },
  { id: 'local-ai-model', label: 'Optional Local AI Model', description: 'Uses an already installed OpenAI-compatible model server on this computer; no key or model download is required.' },
  { id: 'openai-compatible', label: 'OpenAI-compatible cloud provider', description: 'Explicitly sends transcript text and analysis instructions to the configured endpoint.' },
  { id: 'anthropic', label: 'Anthropic cloud provider', description: 'Explicitly sends transcript text and analysis instructions to Anthropic.' }
] as const
export type ContentAnalysisEngineId = (typeof ANALYSIS_ENGINES)[number]['id']
export type AnalysisSensitivity = 'low' | 'balanced' | 'high'

export interface ContentIntelligenceProfile {
  categoryId: ContentCategoryId
  subcategoryIds: string[]
  momentTypeIds: MomentTypeId[]
  audienceId: AudienceId
  customAudience: string
  durationMode: 'automatic' | 'preset' | 'custom'
  durationPreset: DurationChoiceId
  customDurationMin: number
  customDurationMax: number
  candidateCountMode: 'preset' | 'custom'
  requestedCandidates: number
  discoveryMode: DiscoveryModeId
  engine: ContentAnalysisEngineId
  sensitivity: AnalysisSensitivity
  minimumQualityScore: number
  duplicateSensitivity: AnalysisSensitivity
  useAudioSignals: boolean
}

export const DEFAULT_CONTENT_INTELLIGENCE_PROFILE: ContentIntelligenceProfile = {
  categoryId: 'general-mixed',
  subcategoryIds: [],
  momentTypeIds: ['automatic-best'],
  audienceId: 'general',
  customAudience: '',
  durationMode: 'automatic',
  durationPreset: '30-45',
  customDurationMin: 30,
  customDurationMax: 60,
  candidateCountMode: 'preset',
  requestedCandidates: 10,
  discoveryMode: 'balanced',
  engine: 'heuristic-local',
  sensitivity: 'balanced',
  minimumQualityScore: 40,
  duplicateSensitivity: 'balanced',
  useAudioSignals: true
}

export interface ContentIntelligenceScores {
  hook: number
  emotion: number
  curiosity: number
  completeness: number
  informationDensity: number
  categoryFit: number
  typeFit: number
  clarity: number
  shareability: number
  payoff: number
  audioVisualInterest: number | null
  audienceFit: number
}

export interface ContentIntelligenceCandidateMetadata {
  /** User target, plus the inferred category when the target is General/Mixed. */
  categoryId: ContentCategoryId
  inferredCategoryId: ContentCategoryId
  subcategoryIds: string[]
  momentTypeId: CandidateMomentTypeId
  matchedMomentTypeIds: CandidateMomentTypeId[]
  scores: ContentIntelligenceScores
  explanation: string
  strengths: string[]
  limitations: string[]
  suggestedHook: string
  suggestedPayoff: string
  boundaryRationale: string
  durationDeviationReason: string | null
  originalStartTime: number
  originalEndTime: number
  analysisEngine: ContentAnalysisEngineId
  analyzerVersion: string
  analyzedAt: string
  profile: ContentIntelligenceProfile
  audioSignalsAvailable: boolean
}

export function normalizeContentIntelligenceProfile(value?: Partial<ContentIntelligenceProfile> | null): ContentIntelligenceProfile {
  const source = value ?? {}
  const categoryIds = new Set<string>(CONTENT_CATEGORIES.map((category) => category.id))
  const momentIds = new Set<string>(MOMENT_TYPES.map((moment) => moment.id))
  const audienceIds = new Set<string>(AUDIENCES.map((audience) => audience.id))
  const durationIds = new Set<string>(DURATION_CHOICES.map((choice) => choice.id))
  const modeIds = new Set<string>(DISCOVERY_MODES.map((mode) => mode.id))
  const engineIds = new Set<string>(ANALYSIS_ENGINES.map((engine) => engine.id))
  const sensitivityIds = new Set<string>(['low', 'balanced', 'high'])
  const categoryId = categoryIds.has(String(source.categoryId)) ? source.categoryId as ContentCategoryId : DEFAULT_CONTENT_INTELLIGENCE_PROFILE.categoryId
  const category = CONTENT_CATEGORIES.find((item) => item.id === categoryId)!
  const subcategoryIds = Array.isArray(source.subcategoryIds)
    ? [...new Set(source.subcategoryIds.filter((id): id is string => typeof id === 'string' && category.subcategories.some((sub) => sub.id === id)))].slice(0, 12)
    : []
  const momentTypeIds = Array.isArray(source.momentTypeIds)
    ? [...new Set(source.momentTypeIds.filter((id): id is MomentTypeId => typeof id === 'string' && momentIds.has(id)))].slice(0, MOMENT_TYPES.length)
    : [...DEFAULT_CONTENT_INTELLIGENCE_PROFILE.momentTypeIds]
  const sortedRange = (min: number, max: number): [number, number] => {
    const safeMin = Math.max(6, Math.min(179, Number.isFinite(min) ? Math.round(min) : 30))
    const safeMax = Math.max(safeMin + 1, Math.min(180, Number.isFinite(max) ? Math.round(max) : 60))
    return [safeMin, safeMax]
  }
  const [customDurationMin, customDurationMax] = sortedRange(
    source.customDurationMin ?? DEFAULT_CONTENT_INTELLIGENCE_PROFILE.customDurationMin,
    source.customDurationMax ?? DEFAULT_CONTENT_INTELLIGENCE_PROFILE.customDurationMax
  )
  const requestedCandidates = Math.max(1, Math.min(40, Math.round(Number(source.requestedCandidates ?? DEFAULT_CONTENT_INTELLIGENCE_PROFILE.requestedCandidates))))
  return {
    categoryId,
    subcategoryIds,
    momentTypeIds: momentTypeIds.length ? momentTypeIds : ['automatic-best'],
    audienceId: audienceIds.has(String(source.audienceId)) ? source.audienceId as AudienceId : 'general',
    customAudience: typeof source.customAudience === 'string' ? source.customAudience.trim().slice(0, 80) : '',
    durationMode: source.durationMode === 'preset' || source.durationMode === 'custom' ? source.durationMode : 'automatic',
    durationPreset: durationIds.has(String(source.durationPreset)) ? source.durationPreset as DurationChoiceId : '30-45',
    customDurationMin,
    customDurationMax,
    candidateCountMode: source.candidateCountMode === 'custom' ? 'custom' : 'preset',
    requestedCandidates,
    discoveryMode: modeIds.has(String(source.discoveryMode)) ? source.discoveryMode as DiscoveryModeId : 'balanced',
    engine: engineIds.has(String(source.engine)) ? source.engine as ContentAnalysisEngineId : 'heuristic-local',
    sensitivity: sensitivityIds.has(String(source.sensitivity)) ? source.sensitivity as AnalysisSensitivity : 'balanced',
    minimumQualityScore: Math.max(0, Math.min(100, Math.round(Number(source.minimumQualityScore ?? DEFAULT_CONTENT_INTELLIGENCE_PROFILE.minimumQualityScore)))),
    duplicateSensitivity: sensitivityIds.has(String(source.duplicateSensitivity)) ? source.duplicateSensitivity as AnalysisSensitivity : 'balanced',
    useAudioSignals: source.useAudioSignals !== false
  }
}

export function profileDurationRange(profileValue: ContentIntelligenceProfile): { min: number; max: number; automatic: boolean } {
  const profile = normalizeContentIntelligenceProfile(profileValue)
  if (profile.durationMode === 'custom') {
    return { min: profile.customDurationMin, max: profile.customDurationMax, automatic: false }
  }
  if (profile.durationMode === 'preset') {
    const choice = DURATION_CHOICES.find((item) => item.id === profile.durationPreset)!
    return { min: choice.min, max: choice.max, automatic: false }
  }
  // Automatic discovery considers short standalone exchanges and complete
  // stories, then the score weights recommend a suitable duration by structure.
  return { min: 15, max: 180, automatic: true }
}

export function duplicateOverlapThreshold(sensitivity: AnalysisSensitivity): number {
  if (sensitivity === 'low') return 0.7
  if (sensitivity === 'high') return 0.42
  return 0.55
}
