import type { ScoreBreakdown, TranscriptSegment } from '@shared/types'
import { AppError } from '@shared/errors'
import {
  CONTENT_CATEGORIES,
  DEFAULT_CONTENT_INTELLIGENCE_PROFILE,
  MOMENT_TYPES,
  duplicateOverlapThreshold,
  normalizeContentIntelligenceProfile,
  profileDurationRange,
  type CandidateMomentTypeId,
  type ContentAnalysisEngineId,
  type ContentCategoryId,
  type ContentIntelligenceCandidateMetadata,
  type ContentIntelligenceProfile,
  type ContentIntelligenceScores,
  type MomentTypeId
} from '@shared/analysis/content-intelligence'
import { boundaryQuality, deadAirRatio, sentenceSpans, snapToSentenceBoundaries } from '@shared/analysis/boundaries'
import type { SentenceSpan } from '@shared/analysis/boundaries'
import type { ValidatedWithScores } from '@shared/candidates'
import { excerptFor } from '@shared/candidates'

export const CONTENT_ANALYZER_VERSION = 'content-intelligence-1.0.0'
const SPECIAL_MOMENT_TYPES = new Set<MomentTypeId>(['automatic-best', 'all-moments'])
const STOP_WORDS = new Set(`a about above after again against all am an and any are as at be because been before being below between both but by can could did do does doing down during each few for from further had has have having he her here hers herself him himself his how i if in into is it its itself just me more most my myself nor of on once only or other our ours ourselves out over own same she should so some such than that the their theirs them themselves then there these they this those through to too under until up very was we were what when where which while who whom why with would you your yours yourself yourselves um uh er ah like actually basically literally really`.split(/\s+/))
const EMOTION_TERMS = ['afraid', 'angry', 'ashamed', 'betrayed', 'cried', 'crying', 'devastated', 'embarrassed', 'excited', 'fear', 'furious', 'grief', 'heartbroken', 'hope', 'lonely', 'love', 'miss', 'pain', 'proud', 'regret', 'relief', 'scared', 'shame', 'struggled', 'survived', 'tears', 'terrified', 'worried']
const STORY_TERMS = ['after that', 'eventually', 'finally', 'one day', 'one night', 'remember when', 'suddenly', 'then', 'until', 'when i was', 'years ago']
const PAYOFF_TERMS = ['as a result', 'eventually', 'finally', 'in the end', 'that is why', 'that is how', 'the result', 'which meant', 'so now', 'so i learned', 'it worked', 'we found out']
const QUESTION_TERMS = ['how', 'what', 'when', 'where', 'which', 'who', 'why']
const CONTRAST_TERMS = ['although', 'but', 'disagree', 'however', 'instead', 'nevertheless', 'on the other hand', 'rather', 'whereas', 'yet']
const EXPLANATION_TERMS = ['because', 'for example', 'for instance', 'in other words', 'means that', 'the reason', 'therefore', 'this means', 'which is why']
const SURPRISE_TERMS = ['cannot believe', 'did not expect', 'never expected', 'out of nowhere', 'plot twist', 'shocked', 'surprisingly', 'turns out', 'unexpected']
const LAUGHTER_TERMS = ['laugh', 'laughed', 'laughing', 'hilarious', 'joke', 'kidding', 'punchline', 'funny']
const FILLER_TERMS = ['um', 'uh', 'er', 'ah', 'you know', 'sort of', 'kind of', 'i mean', 'basically', 'actually', 'literally']
const INCOMPLETE_OPENERS = /^(and|because|but|he|it|she|so|that|they|this|these|those|which|we|well|yeah)\b/i
const OPEN_HOOK = /^(?:\s)*(?:why|how|what if|did you know|here is|here's|the truth|i never|i used to|nobody|no one|stop|wait|listen|imagine|the problem|the reason|this is why)\b/i
const SENTENCE_END = /[.!?…]["')\]]?\s*$/
const FIRST_PERSON = /\b(i|i'm|i've|i was|my|me|we|our|us)\b/i
const SECOND_PERSON = /\b(you|your|you're|you've)\b/i
const NUMBER = /\b\d+(?:[.,]\d+)?\s?(?:%|percent|thousand|million|billion|years?|months?|weeks?|days?|hours?|dollars?|naira|pounds?|euros?)?\b/i

export interface AudioSignalSummary {
  duration: number
  peaks: number[]
  available: boolean
}

export interface IntelligenceAnalysisOptions {
  audio?: AudioSignalSummary | null
  engine?: ContentAnalysisEngineId
  analyzedAt?: string
  maxCandidates?: number
  signal?: AbortSignal
  onProgress?: (progress: number) => void
}

export interface IntelligentCandidate extends Omit<ValidatedWithScores, 'scores' | 'overallScore' | 'scoreExplanation' | 'intelligence'> {
  scores: ScoreBreakdown
  overallScore: number
  scoreExplanation: string
  intelligence: ContentIntelligenceCandidateMetadata
}

interface WindowRange {
  startTime: number
  endTime: number
  originalStartTime: number
  originalEndTime: number
  startSegmentId: number
  endSegmentId: number
  transcriptExcerpt: string
  reason: string
  title: string
  hook: string
  clipType: string
  scores: ScoreBreakdown
  overallScore: number
  scoreExplanation: string
  intelligence: ContentIntelligenceCandidateMetadata
}

interface WindowFeatures {
  text: string
  normalized: string
  sentences: string[]
  topicCoherence: number
  wordCount: number
  contentWords: string[]
  fillerCount: number
  wordsPerSecond: number
  questionCount: number
  questionAnswer: boolean
  contrastCount: number
  explanationCount: number
  storyProgression: number
  payoffCount: number
  emotionCount: number
  firstPersonCount: number
  secondPersonCount: number
  laughterCount: number
  surpriseCount: number
  numberCount: number
  uniqueContentRatio: number
  speakerChanges: number
  sentenceEnd: boolean
  cleanStart: boolean
  boundaryScore: number
  deadAir: number
  opening: string
  ending: string
  nextContext: string
}

const REGEX_CACHE = new Map<string, RegExp>()

function normalizeText(text: string): string {
  return ` ${text.normalize('NFKC').toLocaleLowerCase().replace(/[^\p{L}\p{N}%]+/gu, ' ').trim().replace(/\s+/g, ' ')} `
}

function hasTerm(text: string, term: string): boolean {
  const normalizedTerm = term.toLocaleLowerCase().replace(/[^\p{L}\p{N}%]+/gu, ' ').trim().replace(/\s+/g, ' ')
  if (!normalizedTerm) return false
  return text.includes(` ${normalizedTerm} `)
}

function termHits(text: string, terms: readonly string[]): string[] {
  return [...new Set(terms.filter((term) => hasTerm(text, term)))]
}

const GENERIC_TOPIC_TERMS = new Set(['after', 'because', 'eventually', 'finally', 'happened', 'learn', 'story', 'then', 'work'])
const SENTENCE_TOPIC_CACHE = new Map<string, ContentCategoryId | null>()

function sentenceTopic(sentence: string): ContentCategoryId | null {
  const key = normalizeText(sentence)
  if (SENTENCE_TOPIC_CACHE.has(key)) return SENTENCE_TOPIC_CACHE.get(key) ?? null
  const ranked = CONTENT_CATEGORIES
    .filter((category) => category.id !== 'general-mixed')
    .map((category) => ({
      id: category.id,
      hits: category.terms.filter((term) => term.length >= 4 && !GENERIC_TOPIC_TERMS.has(term) && hasTerm(key, term)).length
    }))
    .sort((a, b) => b.hits - a.hits)
  const topic = ranked[0]?.hits ? ranked[0].id : null
  if (SENTENCE_TOPIC_CACHE.size >= 4096) SENTENCE_TOPIC_CACHE.clear()
  SENTENCE_TOPIC_CACHE.set(key, topic)
  return topic
}

function topicCoherence(sentences: string[]): number {
  const topics = sentences.map(sentenceTopic).filter((topic): topic is ContentCategoryId => topic !== null)
  if (topics.length < 2) return 86
  const counts = new Map<ContentCategoryId, number>()
  let transitions = 0
  for (let index = 0; index < topics.length; index++) {
    counts.set(topics[index], (counts.get(topics[index]) ?? 0) + 1)
    if (index > 0 && topics[index] !== topics[index - 1]) transitions++
  }
  const dominantShare = Math.max(...counts.values()) / topics.length
  return clamp(50 + dominantShare * 50 - Math.max(0, counts.size - 1) * 7 - (transitions / Math.max(1, topics.length - 1)) * 14)
}

function countMatches(text: string, pattern: RegExp): number {
  const flags = pattern.flags.includes('g') ? pattern.flags : `${pattern.flags}g`
  const key = `${pattern.source}/${flags}`
  let cached = REGEX_CACHE.get(key)
  if (!cached) {
    cached = new RegExp(pattern.source, flags)
    REGEX_CACHE.set(key, cached)
  }
  cached.lastIndex = 0
  return [...text.matchAll(cached)].length
}

function clamp(value: number): number {
  return Math.round(Math.max(0, Math.min(100, value)))
}

function ensureAnalysisNotAborted(signal?: AbortSignal): void {
  if (signal?.aborted) throw new AppError('PROCESS_CANCELLED', 'Content analysis was cancelled.')
}

function average(values: number[]): number {
  return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0
}

function rangeForType(type: CandidateMomentTypeId): { min: number; max: number } {
  if (type === 'funny-unexpected-moment') return { min: 15, max: 30 }
  if (type === 'complete-story' || type === 'suspenseful-story' || type === 'emotional-story' || type === 'inspiring-transformation') {
    return { min: 45, max: 180 }
  }
  if (type === 'educational-explanation' || type === 'practical-advice') return { min: 30, max: 60 }
  return { min: 30, max: 90 }
}

function durationFit(duration: number, target: { min: number; max: number }): number {
  if (duration >= target.min && duration <= target.max) return 92
  const distance = duration < target.min ? target.min - duration : duration - target.max
  const scale = Math.max(10, (target.max - target.min) * 0.8)
  return clamp(92 - (distance / scale) * 78)
}

function overlapFraction(a: { startTime: number; endTime: number }, b: { startTime: number; endTime: number }): number {
  const intersection = Math.min(a.endTime, b.endTime) - Math.max(a.startTime, b.startTime)
  return intersection <= 0 ? 0 : intersection / Math.max(0.001, Math.min(a.endTime - a.startTime, b.endTime - b.startTime))
}

function segmentRangeForTimes(segments: TranscriptSegment[], startTime: number, endTime: number): [number, number] {
  let startIndex = segments.findIndex((segment) => segment.endTime > startTime - 0.001)
  if (startIndex < 0) startIndex = 0
  let endIndex = -1
  for (let index = segments.length - 1; index >= startIndex; index--) {
    if (segments[index].startTime < endTime + 0.001) {
      endIndex = index
      break
    }
  }
  return [startIndex, Math.max(startIndex, endIndex)]
}

function sentenceBoundaryState(startTime: number, endTime: number, spans: SentenceSpan[]): { start: SentenceSpan | null; end: SentenceSpan | null } {
  let start: SentenceSpan | null = null
  let end: SentenceSpan | null = null
  for (const span of spans) {
    if (startTime >= span.start - 0.001 && startTime <= span.end + 0.001) start = span
    if (endTime >= span.start - 0.001 && endTime <= span.end + 0.001) end = span
  }
  return { start, end }
}

function extractFeatures(
  segments: TranscriptSegment[],
  startIndex: number,
  endIndex: number,
  spans: SentenceSpan[]
): WindowFeatures {
  const window = segments.slice(startIndex, endIndex + 1)
  const text = window.map((segment) => segment.text.trim()).join(' ').replace(/\s+/g, ' ').trim()
  const normalized = normalizeText(text)
  const words = text.split(/\s+/).filter(Boolean)
  const contentWords = words
    .map((word) => word.toLocaleLowerCase().replace(/[^\p{L}\p{N}']/gu, ''))
    .filter((word) => word.length > 2 && !STOP_WORDS.has(word))
  const duration = Math.max(0.2, window.at(-1)!.endTime - window[0].startTime)
  const sentenceParts = text.split(/(?<=[.!?…])\s+/).map((sentence) => sentence.trim()).filter(Boolean)
  const nearbyStart = Math.max(0, startIndex - 2)
  const previousText = segments.slice(nearbyStart, startIndex).map((segment) => segment.text).join(' ').trim()
  const followingText = segments.slice(endIndex + 1, Math.min(segments.length, endIndex + 3)).map((segment) => segment.text).join(' ').trim()
  const previous = segments[startIndex - 1]
  const spansState = sentenceBoundaryState(window[0].startTime, window.at(-1)!.endTime, spans)
  const cleanStart = !previous || SENTENCE_END.test(previous.text.trim()) || previous.endTime + 0.9 < window[0].startTime || previous.speaker !== window[0].speaker
  const speakerChanges = window.slice(1).filter((segment, index) => Boolean(segment.speaker && window[index].speaker && segment.speaker !== window[index].speaker)).length
  const questionCount = countMatches(text, /\?/g) + (countMatches(normalized, /\b(why|how|what|when|where|who)\b/g) > 0 ? 1 : 0)
  const answerCueCount = termHits(normalized, ['because', 'the answer', 'the reason', 'here is why', 'that is why', 'what happens is', 'it means']).length
  const questionAnswer = questionCount > 0 && answerCueCount > 0
  const contrastCount = termHits(normalized, CONTRAST_TERMS).length
  const explanationCount = termHits(normalized, EXPLANATION_TERMS).length
  const storyProgression = termHits(normalized, STORY_TERMS).length
  const payoffCount = termHits(normalized, PAYOFF_TERMS).length
  const emotionCount = termHits(normalized, EMOTION_TERMS).length
  const firstPersonCount = countMatches(normalized, FIRST_PERSON)
  const secondPersonCount = countMatches(normalized, SECOND_PERSON)
  const laughterCount = termHits(normalized, LAUGHTER_TERMS).length
  const surpriseCount = termHits(normalized, SURPRISE_TERMS).length
  const numberCount = countMatches(text, NUMBER)
  const uniqueContentRatio = new Set(contentWords).size / Math.max(1, contentWords.length)
  const boundary = boundaryQuality({ startTime: window[0].startTime, endTime: window.at(-1)!.endTime }, spans)
  const deadAir = deadAirRatio({ startTime: window[0].startTime, endTime: window.at(-1)!.endTime }, segments)
  const opening = window.slice(0, 2).map((segment) => segment.text.trim()).join(' ')
  const ending = window.at(-1)!.text.trim()
  // Nearby text is inspected for referents and unresolved transitions, but it
  // is never included in the candidate excerpt or sent to an external provider.
  const nextContext = `${previousText} ${followingText}`.trim()

  return {
    text,
    normalized,
    sentences: sentenceParts.length ? sentenceParts : [text],
    topicCoherence: topicCoherence(sentenceParts.length ? sentenceParts : [text]),
    wordCount: words.length,
    contentWords,
    fillerCount: termHits(normalized, FILLER_TERMS).length,
    wordsPerSecond: words.length / duration,
    questionCount,
    questionAnswer,
    contrastCount,
    explanationCount,
    storyProgression,
    payoffCount,
    emotionCount,
    firstPersonCount,
    secondPersonCount,
    laughterCount,
    surpriseCount,
    numberCount,
    uniqueContentRatio,
    speakerChanges,
    sentenceEnd: SENTENCE_END.test(ending),
    cleanStart: cleanStart && (!spansState.start || window[0].startTime <= spansState.start.start + 0.55),
    boundaryScore: boundary.score,
    deadAir,
    opening,
    ending,
    nextContext
  }
}

function categoryFitFor(categoryId: ContentCategoryId, features: WindowFeatures, subcategoryIds: string[] = []): { score: number; matches: string[]; subcategories: string[] } {
  const category = CONTENT_CATEGORIES.find((item) => item.id === categoryId)!
  if (categoryId === 'general-mixed') return { score: 50, matches: [], subcategories: [] }
  const categoryHits = termHits(features.normalized, category.terms)
  const selectedSubcategories = category.subcategories.filter((subcategory) => subcategoryIds.includes(subcategory.id))
  const subHits = selectedSubcategories.flatMap((subcategory) => termHits(features.normalized, subcategory.terms))
  const selectedTerms = selectedSubcategories.length ? subHits : []
  const sentenceCoverage = category.terms.filter((term) => features.sentences.some((sentence) => hasTerm(normalizeText(sentence), term))).length
  const independentSignals = new Set([...categoryHits, ...selectedTerms]).size
  let score = 23 + Math.min(36, independentSignals * 9) + Math.min(18, Math.max(0, sentenceCoverage - 1) * 6)
  if (independentSignals >= 2 && sentenceCoverage >= 2) score += 10
  if (features.explanationCount > 0 && ['educational-informational', 'technology-ai', 'career-education', 'fitness-health'].includes(categoryId)) score += 5
  if (features.storyProgression > 0 && ['storytelling', 'true-crime-mystery', 'celebrity-pop-culture'].includes(categoryId)) score += 5
  if (selectedSubcategories.length) {
    const subcategoryCoverage = selectedSubcategories.filter((subcategory) => termHits(features.normalized, subcategory.terms).length > 0).length
    score = score * 0.68 + (selectedTerms.length ? Math.min(100, 32 + selectedTerms.length * 17 + subcategoryCoverage * 8) : 12) * 0.32
  }
  return {
    score: clamp(score),
    matches: [...new Set([...categoryHits, ...selectedTerms])].slice(0, 6),
    subcategories: selectedSubcategories.filter((subcategory) => termHits(features.normalized, subcategory.terms).length > 0).map((subcategory) => subcategory.id)
  }
}

function inferCategory(features: WindowFeatures): { categoryId: ContentCategoryId; score: number; matches: string[]; subcategories: string[] } {
  const ranked = CONTENT_CATEGORIES
    .filter((category) => category.id !== 'general-mixed')
    .map((category) => ({ categoryId: category.id, ...categoryFitFor(category.id, features) }))
    .sort((a, b) => b.score - a.score)
  const first = ranked[0]
  return first && first.score >= 37
    ? { categoryId: first.categoryId, score: first.score, matches: first.matches, subcategories: first.subcategories }
    : { categoryId: 'general-mixed', score: first?.score ?? 30, matches: [], subcategories: [] }
}

function audienceFit(profile: ContentIntelligenceProfile, inferredCategory: ContentCategoryId, features: WindowFeatures): number {
  if (profile.audienceId === 'general') return 72
  const categoryGroups: Record<string, ContentCategoryId[]> = {
    'young-adults': ['relationships-dating', 'motivation-self-improvement', 'career-education', 'psychology-human-behaviour'],
    entrepreneurs: ['money-business', 'career-education', 'technology-ai'],
    students: ['career-education', 'educational-informational', 'technology-ai'],
    professionals: ['career-education', 'money-business', 'technology-ai', 'psychology-human-behaviour'],
    'entertainment-viewers': ['comedy-entertainment', 'celebrity-pop-culture', 'sports', 'true-crime-mystery'],
    'african-audience': ['african-nigerian-conversations', 'relationships-dating', 'money-business', 'comedy-entertainment'],
    'international-audience': ['educational-informational', 'technology-ai', 'sports', 'storytelling']
  }
  if (profile.audienceId === 'custom') {
    const audienceTerms = normalizeText(profile.customAudience).trim().split(/\s+/).filter((word) => word.length > 3)
    const termMatches = audienceTerms.filter((word) => hasTerm(features.normalized, word)).length
    return clamp(50 + Math.min(30, termMatches * 12) + (termMatches > 0 && features.secondPersonCount > 0 ? 8 : 0))
  }
  const groups = categoryGroups[profile.audienceId] ?? []
  let score = groups.includes(inferredCategory) ? 82 : 57
  if (profile.audienceId === 'young-adults' && features.firstPersonCount > 0 && features.emotionCount > 0) score += 6
  if (profile.audienceId === 'entrepreneurs' && inferredCategory === 'money-business' && features.numberCount > 0) score += 6
  if (profile.audienceId === 'students' && inferredCategory === 'educational-informational' && features.explanationCount > 0) score += 6
  if (profile.audienceId === 'african-audience' && inferredCategory === 'african-nigerian-conversations') score += 10
  return clamp(score)
}

function momentTypeScores(features: WindowFeatures): Record<CandidateMomentTypeId, number> {
  const personalStory = features.firstPersonCount > 0 && features.storyProgression > 0
  const emotionalStory = personalStory && features.emotionCount > 0
  const results: Record<CandidateMomentTypeId, number> = {
    'controversial-statement': clamp(28 + features.contrastCount * 8 + Number(/\b(unpopular opinion|the truth is|i disagree|people are wrong|should never)\b/i.test(features.text)) * 24 + Number(features.speakerChanges > 0) * 8),
    'shocking-revelation': clamp(24 + features.surpriseCount * 17 + Number(/\b(revealed|secret|nobody knew|never told)\b/i.test(features.normalized)) * 16 + features.numberCount * 4),
    'emotional-story': clamp(20 + Number(emotionalStory) * 30 + Math.min(30, features.emotionCount * 9) + Math.min(12, features.payoffCount * 5)),
    'funny-unexpected-moment': clamp(22 + Math.min(35, features.laughterCount * 15) + features.surpriseCount * 10 + Math.min(16, features.speakerChanges * 6) + Number(/\b(wait what|no way|seriously)\b/i.test(features.normalized)) * 9),
    'powerful-lesson': clamp(26 + Number(/\b(i learned|lesson|taught me|what i learned|mistake taught)\b/i.test(features.normalized)) * 24 + features.payoffCount * 7 + features.explanationCount * 5),
    'practical-advice': clamp(24 + Number(SECOND_PERSON.test(features.text)) * 8 + Number(/\b(you should|you need to|here is how|here's how|step one|first you|my advice)\b/i.test(features.text)) * 24 + features.explanationCount * 6),
    'interesting-discovery': clamp(24 + Number(/\b(discovered|found out|research|study|it turns out|we found)\b/i.test(features.normalized)) * 21 + features.numberCount * 8 + features.surpriseCount * 8 + features.explanationCount * 5),
    'strong-debate': clamp(22 + Math.min(26, features.contrastCount * 10) + Math.min(24, features.speakerChanges * 10) + Number(/\b(i disagree|you're wrong|you are wrong|not true|on the other hand)\b/i.test(features.text)) * 18),
    'personal-confession': clamp(20 + Number(FIRST_PERSON.test(features.text)) * 8 + Number(/\b(i have to admit|to be honest|i never told|i was ashamed|my fault|i made a mistake)\b/i.test(features.text)) * 26 + features.emotionCount * 7 + Number(personalStory) * 10),
    'inspiring-transformation': clamp(20 + Number(/\b(used to|now i|everything changed|turned my life around|transformed|from .{1,35} to)\b/i.test(features.text)) * 25 + Number(personalStory) * 12 + features.payoffCount * 7 + features.emotionCount * 4),
    'suspenseful-story': clamp(22 + Math.min(24, features.storyProgression * 8) + features.surpriseCount * 11 + Number(/\b(until|then i heard|what happened next|the door|suddenly)\b/i.test(features.normalized)) * 16 + features.payoffCount * 5),
    'complete-story': clamp(20 + Number(personalStory) * 14 + Math.min(24, features.storyProgression * 7) + Math.min(28, features.payoffCount * 10) + Number(features.sentenceEnd) * 10 - Math.max(0, 65 - features.topicCoherence) * 0.65),
    'educational-explanation': clamp(22 + Math.min(30, features.explanationCount * 10) + Number(/\b(for example|for instance|step by step|this means|the reason)\b/i.test(features.normalized)) * 18 + features.numberCount * 4 + Number(features.sentenceEnd) * 6)
  }
  return results
}

function selectedMomentTypes(profile: ContentIntelligenceProfile): CandidateMomentTypeId[] {
  return profile.momentTypeIds.filter((id): id is CandidateMomentTypeId => !SPECIAL_MOMENT_TYPES.has(id))
}

function chooseMomentType(scores: Record<CandidateMomentTypeId, number>, profile: ContentIntelligenceProfile): CandidateMomentTypeId {
  const selected = selectedMomentTypes(profile)
  const types = selected.length ? selected : Object.keys(scores) as CandidateMomentTypeId[]
  return types.sort((a, b) => scores[b] - scores[a])[0] ?? 'complete-story'
}

function modeWeights(profile: ContentIntelligenceProfile): Record<keyof ContentIntelligenceScores, number> {
  const weights: Record<keyof ContentIntelligenceScores, number> = {
    hook: 0.11,
    emotion: 0.07,
    curiosity: 0.1,
    completeness: 0.12,
    informationDensity: 0.09,
    categoryFit: 0.12,
    typeFit: 0.11,
    clarity: 0.09,
    shareability: 0.07,
    payoff: 0.08,
    audioVisualInterest: 0.03,
    audienceFit: 0.04
  }
  const mode = profile.discoveryMode
  if (mode === 'high-engagement') Object.assign(weights, { hook: 0.16, emotion: 0.1, curiosity: 0.15, completeness: 0.08, informationDensity: 0.05, categoryFit: 0.08, typeFit: 0.12, clarity: 0.06, shareability: 0.12, payoff: 0.04, audioVisualInterest: 0.03, audienceFit: 0.01 })
  if (mode === 'educational-value') Object.assign(weights, { hook: 0.08, emotion: 0.04, curiosity: 0.08, completeness: 0.13, informationDensity: 0.19, categoryFit: 0.13, typeFit: 0.09, clarity: 0.14, shareability: 0.03, payoff: 0.08, audioVisualInterest: 0.01, audienceFit: 0.02 })
  if (mode === 'storytelling') Object.assign(weights, { hook: 0.1, emotion: 0.1, curiosity: 0.13, completeness: 0.17, informationDensity: 0.04, categoryFit: 0.07, typeFit: 0.1, clarity: 0.07, shareability: 0.04, payoff: 0.13, audioVisualInterest: 0.03, audienceFit: 0.04 })
  if (mode === 'emotional-moments') Object.assign(weights, { hook: 0.1, emotion: 0.2, curiosity: 0.1, completeness: 0.13, informationDensity: 0.04, categoryFit: 0.07, typeFit: 0.09, clarity: 0.07, shareability: 0.05, payoff: 0.1, audioVisualInterest: 0.02, audienceFit: 0.05 })
  if (mode === 'debate-discussion') Object.assign(weights, { hook: 0.12, emotion: 0.07, curiosity: 0.13, completeness: 0.11, informationDensity: 0.08, categoryFit: 0.08, typeFit: 0.17, clarity: 0.1, shareability: 0.06, payoff: 0.04, audioVisualInterest: 0.02, audienceFit: 0.04 })
  if (mode === 'strict-quality') Object.assign(weights, { hook: 0.07, emotion: 0.04, curiosity: 0.08, completeness: 0.18, informationDensity: 0.1, categoryFit: 0.09, typeFit: 0.07, clarity: 0.17, shareability: 0.03, payoff: 0.13, audioVisualInterest: 0.01, audienceFit: 0.07 })
  if (profile.categoryId !== 'general-mixed') {
    weights.categoryFit += 0.04
    weights.clarity -= 0.01
    weights.hook -= 0.01
    weights.audioVisualInterest -= 0.01
    weights.audienceFit -= 0.01
  }
  if (profile.momentTypeIds.some((id) => !SPECIAL_MOMENT_TYPES.has(id))) {
    weights.typeFit += 0.05
    weights.informationDensity -= 0.02
    weights.shareability -= 0.01
    weights.hook -= 0.01
    weights.completeness -= 0.01
  }
  return weights
}

function weightedOverall(scores: ContentIntelligenceScores, profile: ContentIntelligenceProfile): number {
  const weights = modeWeights(profile)
  let total = 0
  let weightTotal = 0
  for (const key of Object.keys(weights) as Array<keyof ContentIntelligenceScores>) {
    const score = scores[key]
    if (score == null) continue
    total += score * weights[key]
    weightTotal += weights[key]
  }
  return clamp(weightTotal ? total / weightTotal : 0)
}

function audioInterest(
  segments: TranscriptSegment[],
  startTime: number,
  endTime: number,
  features: WindowFeatures,
  audio?: AudioSignalSummary | null
): { score: number | null; available: boolean } {
  const speakerAvailable = segments.some((segment) => segment.speaker)
  const audioAvailable = Boolean(audio?.available && audio.peaks.length && audio.duration > 0)
  if (!audioAvailable && !speakerAvailable) return { score: null, available: false }
  const dynamicScores: number[] = []
  if (audioAvailable) {
    const summary = audio!
    const from = Math.max(0, Math.floor((startTime / summary.duration) * summary.peaks.length))
    const to = Math.min(summary.peaks.length, Math.max(from + 1, Math.ceil((endTime / summary.duration) * summary.peaks.length)))
    const values = summary.peaks.slice(from, to)
    const mean = average(values)
    const variance = average(values.map((value) => (value - mean) ** 2))
    const variation = Math.sqrt(variance)
    const peak = Math.max(0, ...values)
    const relativePeak = mean > 0.005 ? peak / mean : 0
    dynamicScores.push(clamp(38 + mean * 24 + variation * 155 + Math.min(18, Math.max(0, relativePeak - 1) * 7)))
  }
  if (speakerAvailable) dynamicScores.push(clamp(48 + Math.min(42, features.speakerChanges * 11) + (features.questionAnswer ? 5 : 0)))
  return { score: clamp(average(dynamicScores)), available: true }
}

function scoreWindow(
  segments: TranscriptSegment[],
  startIndex: number,
  endIndex: number,
  range: { startTime: number; endTime: number; originalStartTime: number; originalEndTime: number },
  spans: SentenceSpan[],
  profileValue: ContentIntelligenceProfile,
  options: IntelligenceAnalysisOptions
): IntelligentCandidate {
  const profile = normalizeContentIntelligenceProfile(profileValue)
  const features = extractFeatures(segments, startIndex, endIndex, spans)
  const duration = Math.max(0.1, range.endTime - range.startTime)
  const category = profile.categoryId === 'general-mixed'
    ? inferCategory(features)
    : { categoryId: profile.categoryId, ...categoryFitFor(profile.categoryId, features, profile.subcategoryIds) }
  const inferred = profile.categoryId === 'general-mixed' ? category.categoryId : inferCategory(features).categoryId
  const typeScores = momentTypeScores(features)
  const primaryType = chooseMomentType(typeScores, profile)
  const suggestedDuration = profile.durationMode === 'automatic' ? rangeForType(primaryType) : profileDurationRange(profile)
  const durationScore = durationFit(duration, suggestedDuration)
  const selectedTypes = selectedMomentTypes(profile)
  const bestTypeScore = selectedTypes.length
    ? Math.max(...selectedTypes.map((id) => typeScores[id]))
    : typeScores[primaryType]
  const typeFit = clamp(bestTypeScore * 0.86 + durationScore * 0.14)
  const previous = segments[startIndex - 1]
  const startsMidThought = Boolean(previous && !features.cleanStart)
  const unresolvedOpening = INCOMPLETE_OPENERS.test(features.text) || /^(this|that|it|they|he|she)\b/i.test(features.text)
  const endingHasPayoff = features.payoffCount > 0 || features.questionAnswer || typeScores['complete-story'] >= 68
  const hookCue = OPEN_HOOK.test(features.opening) ? 24 : 0
  const openingQuestion = /\?|\b(why|how|what if|did you know)\b/i.test(features.opening) ? 19 : 0
  const statementStrength = /\b(the truth|the problem|i used to|nobody|never|most people|one thing)\b/i.test(features.opening) ? 14 : 0
  const hook = clamp(34 + hookCue + openingQuestion + statementStrength + Math.min(16, features.surpriseCount * 8) + Math.min(10, features.numberCount * 4) - (startsMidThought ? 14 : 0))
  const emotion = clamp(24 + Math.min(34, features.emotionCount * 10) + Math.min(18, features.firstPersonCount * 3) + (typeScores['emotional-story'] > 55 ? 9 : 0) + (features.speakerChanges > 0 ? 4 : 0))
  const curiosity = clamp(25 + Math.min(18, features.questionCount * 8) + Math.min(25, features.surpriseCount * 11) + Math.min(18, features.storyProgression * 6) + (features.contrastCount > 0 ? 9 : 0) + (endingHasPayoff ? 8 : 0))
  const topicShiftPenalty = Math.max(0, 65 - features.topicCoherence) * (profile.categoryId === 'general-mixed' ? 0.42 : 0.18)
  const completeness = clamp(34 + (features.cleanStart ? 19 : -14) + (features.sentenceEnd ? 21 : -13) + Math.min(16, features.payoffCount * 6) + (unresolvedOpening ? -15 : 0) + (features.deadAir > 0.25 ? -10 : 0) + Math.round((features.boundaryScore - 0.5) * 18) - topicShiftPenalty)
  const uniqueRatio = features.uniqueContentRatio
  const exampleBonus = termHits(features.normalized, ['for example', 'for instance', 'imagine', 'let us say', 'suppose']).length * 6
  const informationDensity = clamp(25 + uniqueRatio * 34 + Math.min(20, features.contentWords.length * 0.8) + Math.min(14, features.numberCount * 5) + exampleBonus - Math.max(0, features.fillerCount - 1) * 5)
  const categoryFit = category.score
  const pace = features.wordsPerSecond
  const paceScore = pace >= 1.7 && pace <= 3.8 ? 91 : pace >= 1.2 && pace <= 4.6 ? 73 : 48
  const sentenceClarity = clamp(84 - Math.max(0, average(features.sentences.map((sentence) => sentence.split(/\s+/).length)) - 22) * 1.7)
  const clarity = clamp(paceScore * 0.58 + sentenceClarity * 0.26 + (features.fillerCount ? Math.max(38, 86 - features.fillerCount * 7) : 88) * 0.16 - (unresolvedOpening ? 11 : 0))
  const audience = audienceFit(profile, inferred, features)
  const audienceCue = profile.audienceId === 'general' ? 0 : (audience - 55) * 0.14
  const shareability = clamp(30 + hook * 0.22 + curiosity * 0.14 + emotion * 0.12 + clarity * 0.1 + (endingHasPayoff ? 10 : 0) + audienceCue)
  const payoff = clamp(26 + Math.min(32, features.payoffCount * 12) + (features.questionAnswer ? 14 : 0) + (features.sentenceEnd ? 13 : -8) + Math.min(14, features.storyProgression * 4) + (features.nextContext && /^(because|and then|so|which|but)\b/i.test(features.nextContext) ? -8 : 0))
  const audio = audioInterest(segments.slice(startIndex, endIndex + 1), range.startTime, range.endTime, features, options.audio)
  const scores: ContentIntelligenceScores = {
    hook,
    emotion,
    curiosity,
    completeness,
    informationDensity,
    categoryFit,
    typeFit,
    clarity,
    shareability,
    payoff,
    audioVisualInterest: audio.score,
    audienceFit: audience
  }
  const overallScore = weightedOverall(scores, profile)
  const matchedMomentTypeIds = (Object.keys(typeScores) as CandidateMomentTypeId[])
    .filter((type) => typeScores[type] >= Math.max(47, typeScores[primaryType] - 13))
    .sort((a, b) => typeScores[b] - typeScores[a])
    .slice(0, 4)
  const effectiveCategory = CONTENT_CATEGORIES.find((item) => item.id === inferred)!
  const selectedSubcategories = profile.categoryId === 'general-mixed'
    ? effectiveCategory.subcategories
      .filter((subcategory) => termHits(features.normalized, subcategory.terms).length > 0)
      .map((subcategory) => subcategory.id)
      .slice(0, 3)
    : category.subcategories
  const reasons: string[] = []
  if (hook >= 64) reasons.push('opens with a question, claim, contrast or curiosity cue')
  if (completeness >= 68) reasons.push('starts and ends close to complete sentence boundaries')
  if (payoff >= 62) reasons.push('contains an answer, consequence or closing payoff')
  if (categoryFit >= 50 && category.matches.length) reasons.push(`fits ${effectiveCategory.label.toLowerCase()} through ${category.matches.slice(0, 3).join(', ')}`)
  if (typeFit >= 58) reasons.push(`has a ${MOMENT_TYPES.find((item) => item.id === primaryType)?.label.toLowerCase()} structure`)
  if (informationDensity >= 62) reasons.push('includes several distinct, specific information cues')
  if (features.questionAnswer) reasons.push('moves from a question toward an explanation or answer')
  if (features.speakerChanges > 0) reasons.push('includes a speaker turn that may add conversational energy')
  const limitations: string[] = []
  if (hook < 48) limitations.push('the opening has few explicit hook cues')
  if (completeness < 58) limitations.push('the start or end may still depend on surrounding context')
  if (clarity < 58) limitations.push('speech pace, long sentences or filler reduce transcript clarity')
  if (categoryFit < 42 && profile.categoryId !== 'general-mixed') limitations.push('category fit is uncertain from the transcript text')
  if (!audio.available) limitations.push('no usable waveform or speaker-turn signal was available')
  if (!reasons.length) reasons.push('selected for its combined structure, context, clarity and fit signals')
  const boundaryRationale = range.startTime !== range.originalStartTime || range.endTime !== range.originalEndTime
    ? `Sentence-aware boundaries adjusted the suggested range from ${range.originalStartTime.toFixed(1)}–${range.originalEndTime.toFixed(1)}s to ${range.startTime.toFixed(1)}–${range.endTime.toFixed(1)}s to preserve a complete thought or payoff.`
    : 'Suggested edges align with the selected transcript window; review the preview before creating a clip.'
  const configuredRange = profileDurationRange(profile)
  const durationDeviationReason = duration < configuredRange.min || duration > configuredRange.max
    ? `The complete thought/payoff needs about ${Math.round(duration)}s, outside the ${configuredRange.min}–${configuredRange.max}s target; the analyzer kept context rather than cutting a sentence.`
    : null
  const typeDefinition = MOMENT_TYPES.find((item) => item.id === primaryType)!
  const titleSentence = features.sentences[0] ?? features.text
  const title = makeTitle(titleSentence)
  const suggestedHook = trimWords(features.sentences[0] ?? features.opening, 18)
  const suggestedPayoff = trimWords(features.sentences.at(-1) ?? features.ending, 28)
  const analyzedAt = options.analyzedAt ?? new Date().toISOString()
  const engine = options.engine ?? profile.engine
  const intelligence: ContentIntelligenceCandidateMetadata = {
    categoryId: profile.categoryId,
    inferredCategoryId: inferred,
    subcategoryIds: selectedSubcategories,
    momentTypeId: primaryType,
    matchedMomentTypeIds,
    scores,
    explanation: `${reasons.join('; ')}. ${limitations.length ? `Consider: ${limitations.join('; ')}. ` : ''}Scores are transparent heuristic estimates, not a prediction of views or guaranteed virality.`,
    strengths: reasons,
    limitations,
    suggestedHook,
    suggestedPayoff,
    boundaryRationale,
    durationDeviationReason,
    originalStartTime: range.originalStartTime,
    originalEndTime: range.originalEndTime,
    analysisEngine: engine,
    analyzerVersion: CONTENT_ANALYZER_VERSION,
    analyzedAt,
    profile,
    audioSignalsAvailable: audio.available
  }
  const scoresLegacy: ScoreBreakdown = {
    hook,
    contextCompleteness: completeness,
    clarity,
    retention: clamp(curiosity * 0.48 + payoff * 0.52),
    emotionalImpact: emotion,
    standaloneValue: clamp(completeness * 0.55 + categoryFit * 0.2 + payoff * 0.25),
    shareability,
    visualSuitability: audio.score ?? 55
  }
  const scoreExplanation = intelligence.explanation
  const clipType = typeDefinition.clipType
  return {
    startTime: range.startTime,
    endTime: range.endTime,
    startSegmentId: segments[startIndex].id,
    endSegmentId: segments[endIndex].id,
    title,
    hook: suggestedHook,
    reason: intelligence.explanation,
    clipType,
    transcriptExcerpt: excerptFor(segments, segments[startIndex].id, segments[endIndex].id),
    scores: scoresLegacy,
    overallScore,
    scoreExplanation,
    intelligence
  }
}

function makeTitle(sentence: string): string {
  const words = sentence.replace(/^[^\p{L}\p{N}"']+/u, '').split(/\s+/).filter(Boolean)
  return words.slice(0, 9).join(' ').replace(/[.!?…]+$/, '') + (words.length > 9 ? '…' : '') || 'Notable moment'
}

function trimWords(text: string, maximum: number): string {
  const words = text.trim().split(/\s+/).filter(Boolean)
  return words.slice(0, maximum).join(' ') + (words.length > maximum ? '…' : '')
}

function sensitivityThreshold(profile: ContentIntelligenceProfile): number {
  const sensitivityOffset = profile.sensitivity === 'low' ? -10 : profile.sensitivity === 'high' ? 9 : 0
  const strictOffset = profile.discoveryMode === 'strict-quality' ? 8 : 0
  return Math.max(20, Math.min(95, profile.minimumQualityScore + sensitivityOffset + strictOffset))
}

function candidateAllowed(candidate: IntelligentCandidate, profile: ContentIntelligenceProfile): boolean {
  if (candidate.overallScore < sensitivityThreshold(profile)) return false
  if (profile.categoryId !== 'general-mixed' && candidate.intelligence.scores.categoryFit < (profile.sensitivity === 'high' ? 38 : 25)) return false
  const chosenTypes = selectedMomentTypes(profile)
  if (chosenTypes.length && Math.max(...chosenTypes.map((type) => candidate.intelligence.scores.typeFit * 0.45 + (candidate.intelligence.matchedMomentTypeIds.includes(type) ? candidate.intelligence.scores.typeFit * 0.55 : 0))) < (profile.sensitivity === 'high' ? 54 : 43)) return false
  return true
}

/**
 * Sentence-aware local candidate generation. It reads the selected window and
 * nearby transcript context, identifies discourse/narrative structures, then
 * combines those signals with fit, duration, clarity and available waveform
 * data. The deterministic engine remains usable fully offline.
 */
export function runContentIntelligenceAnalysis(
  segments: TranscriptSegment[],
  profileValue: ContentIntelligenceProfile = DEFAULT_CONTENT_INTELLIGENCE_PROFILE,
  options: IntelligenceAnalysisOptions = {}
): IntelligentCandidate[] {
  if (!segments.length) return []
  const profile = normalizeContentIntelligenceProfile(profileValue)
  const durationRange = profileDurationRange(profile)
  const minimum = durationRange.automatic ? 12 : Math.max(6, durationRange.min * 0.65)
  const maximum = durationRange.automatic ? 180 : Math.min(180, durationRange.max * 1.35)
  const spans = sentenceSpans(segments)
  const candidates: IntelligentCandidate[] = []
  const seen = new Set<string>()
  const maxCandidates = Math.max(1, Math.min(40, options.maxCandidates ?? profile.requestedCandidates))

  const progressStride = Math.max(1, Math.floor(segments.length / 50))
  for (let startIndex = 0; startIndex < segments.length; startIndex++) {
    ensureAnalysisNotAborted(options.signal)
    if (startIndex % progressStride === 0) options.onProgress?.(startIndex / Math.max(1, segments.length))
    if (segments[startIndex].endTime - segments[startIndex].startTime > maximum + 1) continue
    for (let endIndex = startIndex; endIndex < segments.length; endIndex++) {
      ensureAnalysisNotAborted(options.signal)
      const originalStartTime = segments[startIndex].startTime
      const originalEndTime = segments[endIndex].endTime
      const originalDuration = originalEndTime - originalStartTime
      if (originalDuration > maximum * 1.25) break
      if (originalDuration < minimum) continue
      const boundary = snapToSentenceBoundaries(
        { startTime: originalStartTime, endTime: originalEndTime },
        spans,
        { minLengthSec: minimum, maxLengthSec: maximum }
      )
      const startTime = Math.max(0, boundary.startTime)
      const endTime = Math.max(startTime + 0.5, boundary.endTime)
      const duration = endTime - startTime
      if (duration < minimum * 0.75 || duration > maximum * 1.4) continue
      const [adjustedStartIndex, adjustedEndIndex] = segmentRangeForTimes(segments, startTime, endTime)
      const key = `${Math.round(startTime * 2)}:${Math.round(endTime * 2)}`
      if (seen.has(key)) continue
      seen.add(key)
      const candidate = scoreWindow(
        segments,
        adjustedStartIndex,
        adjustedEndIndex,
        { startTime, endTime, originalStartTime, originalEndTime },
        spans,
        profile,
        options
      )
      const wordCount = candidate.transcriptExcerpt.split(/\s+/).filter(Boolean).length
      if (wordCount < 10 || candidate.transcriptExcerpt.replace(/\s/g, '').length < 35) continue
      if (!candidateAllowed(candidate, profile)) continue
      const reasonParts = candidate.intelligence.strengths
      candidates.push({
        ...candidate,
        reason: reasonParts.join('; '),
        intelligence: candidate.intelligence
      })
    }
  }

  ensureAnalysisNotAborted(options.signal)
  options.onProgress?.(1)
  return selectDiverseWindows(candidates, maxCandidates, profile)
}

/** Score external-provider candidates with the same local, explainable audit. */
export function annotateProviderCandidates(
  candidates: ValidatedWithScores[],
  segments: TranscriptSegment[],
  profileValue: ContentIntelligenceProfile,
  options: IntelligenceAnalysisOptions = {}
): IntelligentCandidate[] {
  const profile = normalizeContentIntelligenceProfile(profileValue)
  const spans = sentenceSpans(segments)
  ensureAnalysisNotAborted(options.signal)
  return candidates.map((candidate) => {
    ensureAnalysisNotAborted(options.signal)
    const [startIndex, endIndex] = segmentRangeForTimes(segments, candidate.startTime, candidate.endTime)
    const result = scoreWindow(
      segments,
      startIndex,
      endIndex,
      {
        startTime: candidate.startTime,
        endTime: candidate.endTime,
        originalStartTime: candidate.originalStartTime ?? candidate.startTime,
        originalEndTime: candidate.originalEndTime ?? candidate.endTime
      },
      spans,
      profile,
      options
    )
    return {
      ...candidate,
      scores: candidate.scores ?? result.scores,
      overallScore: result.overallScore,
      scoreExplanation: result.scoreExplanation,
      reason: result.reason,
      clipType: result.clipType,
      hook: candidate.hook || result.hook,
      title: candidate.title || result.title,
      intelligence: result.intelligence
    }
  }).filter((candidate) => candidateAllowed(candidate, profile))
}

function selectDiverseWindows(
  candidates: IntelligentCandidate[],
  maxCandidates: number,
  profile: ContentIntelligenceProfile
): IntelligentCandidate[] {
  if (!candidates.length) return []
  const threshold = duplicateOverlapThreshold(profile.duplicateSensitivity)
  const ranked = [...candidates].sort((a, b) => b.overallScore - a.overallScore || a.startTime - b.startTime)
  const target = Math.min(40, maxCandidates * 2)
  const selected: IntelligentCandidate[] = []
  const typeCounts = new Map<string, number>()
  const timelineBuckets = new Set<number>()
  const totalDuration = Math.max(1, ranked.at(-1)!.endTime - ranked[0].startTime)
  const bucketSize = totalDuration / Math.max(1, maxCandidates)
  const pickScore = (candidate: IntelligentCandidate): number => {
    const type = candidate.intelligence.momentTypeId
    const bucket = Math.floor((candidate.startTime - ranked[0].startTime) / Math.max(1, bucketSize))
    const novelty = (typeCounts.get(type) ?? 0) === 0 ? 5 : -Math.min(7, (typeCounts.get(type) ?? 0) * 2)
    const timelineBonus = timelineBuckets.has(bucket) ? -2 : 4
    const selectedTypeBonus = selectedMomentTypes(profile).includes(type) ? 3 : 0
    return candidate.overallScore + novelty + timelineBonus + selectedTypeBonus
  }
  const remaining = [...ranked]
  while (selected.length < maxCandidates && remaining.length) {
    remaining.sort((a, b) => pickScore(b) - pickScore(a))
    const next = remaining.shift()!
    if (selected.some((prior) => overlapFraction(prior, next) > threshold)) continue
    selected.push(next)
    const type = next.intelligence.momentTypeId
    typeCounts.set(type, (typeCounts.get(type) ?? 0) + 1)
    const bucket = Math.floor((next.startTime - ranked[0].startTime) / Math.max(1, bucketSize))
    timelineBuckets.add(bucket)
  }
  // Include a limited alternate boundary/variation for comparison when it is
  // a genuinely overlapping alternative, leaving final candidate caps to the
  // existing shared moment-grouping and approval-preserving repository flow.
  const alternateFor = new Set<string>()
  for (const candidate of ranked) {
    if (selected.length >= target) break
    if (selected.includes(candidate)) continue
    const anchor = selected.find((item) => overlapFraction(item, candidate) > threshold)
    const anchorKey = anchor ? `${anchor.startTime.toFixed(1)}:${anchor.endTime.toFixed(1)}` : ''
    if (anchor && !alternateFor.has(anchorKey) && (Math.abs(anchor.startTime - candidate.startTime) > 0.4 || Math.abs(anchor.endTime - candidate.endTime) > 0.4)) {
      selected.push(candidate)
      alternateFor.add(anchorKey)
    }
  }
  return selected.sort((a, b) => a.startTime - b.startTime)
}

export function legacyPresetForProfile(profile: ContentIntelligenceProfile): 'short' | 'medium' | 'long' | 'mixed' {
  if (profile.durationMode === 'automatic') return 'mixed'
  const min = profile.durationMode === 'custom' ? profile.customDurationMin : Number(profile.durationPreset.split('-')[0])
  const max = profile.durationMode === 'custom' ? profile.customDurationMax : Number(profile.durationPreset.split('-')[1])
  if (max <= 30) return 'short'
  if (min >= 60) return 'long'
  return 'medium'
}

export function effectiveAnalysisProfile(
  projectProfile: ContentIntelligenceProfile | undefined,
  globalProfile: ContentIntelligenceProfile
): ContentIntelligenceProfile {
  return normalizeContentIntelligenceProfile(projectProfile ?? globalProfile)
}
