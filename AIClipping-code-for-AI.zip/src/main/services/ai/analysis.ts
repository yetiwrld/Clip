import fs from 'node:fs'
import path from 'node:path'
import { AppError } from '@shared/errors'
import type { AnalysisSummary, ClipCandidate, ProviderAvailability, ScoreBreakdown, TranscriptSegment } from '@shared/types'
import {
  assignMomentMetadata, dedupeCandidates, excerptFor, validateCandidate,
  clampScore, aggregateScore,
  type RawCandidate, type RawScores, type ValidatedWithScores
} from '@shared/candidates'
import { rawCandidatesResponseSchema, rawScoresResponseSchema, rawMetadataResponseSchema } from '@shared/schemas'
import {
  duplicateOverlapThreshold,
  normalizeContentIntelligenceProfile,
  profileDurationRange,
  CONTENT_CATEGORIES,
  MOMENT_TYPES,
  DISCOVERY_MODES,
  AUDIENCES,
  type ContentIntelligenceProfile,
  type ContentAnalysisEngineId
} from '@shared/analysis/content-intelligence'
import { buildDiscoveryUserPrompt, buildScoringUserPrompt, DISCOVERY_SYSTEM, SCORING_SYSTEM } from '@prompts/index'
import type { AppContext } from '../app-context'
import { candidatesRepo, projectsRepo, segmentsRepo } from '../database/repositories'
import { getSettings } from '../settings'
import { chatComplete, extractJson, isLocalAiEndpoint } from './chat'
import { annotateProviderCandidates, type AudioSignalSummary, CONTENT_ANALYZER_VERSION } from './content-intelligence'
import { runHeuristicAnalysis } from './heuristic'
import { buildWaveform } from '../media/frames'

/**
 * Clip discovery + performance audit orchestration (spec §15–19).
 *
 * Pipeline: transcript → provider candidates → zod validation →
 * segment-id→time conversion → dedup into moments → audit scores → persist.
 * Raw provider output is archived to projects/<id>/analysis/ for cache/debug.
 */

export type AnalysisProviderId = 'heuristic-local' | 'local-ai-model' | 'openai-compatible' | 'anthropic'

export interface AnalysisOptions {
  projectId: string
  providerId: AnalysisProviderId
  onEvent: (stage: string, progress: number | null, message: string) => void
  signal: AbortSignal
}

export async function runAnalysis(ctx: AppContext, opts: AnalysisOptions): Promise<AnalysisSummary> {
  const project = projectsRepo.get(ctx.db, opts.projectId)
  if (!project) throw new AppError('PROJECT_NOT_FOUND', 'That project no longer exists.')

  const segments = segmentsRepo.listForProject(ctx.db, opts.projectId)
  if (segments.length === 0) {
    throw new AppError(
      'NO_TRANSCRIPT',
      'This project has no transcript yet.',
      'Transcribe the video or import a transcript file first — analysis reads the transcript, not the video.'
    )
  }

  const settings = getSettings(ctx)
  const profile = normalizeContentIntelligenceProfile(
    project.settings.contentIntelligence ?? settings.contentIntelligence
  )
  const durationRange = profileDurationRange(profile)
  const preset = project.settings.durationPreset ?? settings.video.targetDurationPreset
  const maxCandidates = profile.requestedCandidates
  const analyzedAt = new Date().toISOString()

  projectsRepo.setStatus(ctx.db, opts.projectId, 'analyzing', 'Analyzing transcript')
  opts.onEvent('discovering', 0.08, 'Preparing transcript structure and content preferences')

  let audioSignals: AudioSignalSummary | null = null
  if (profile.useAudioSignals && project.hasAudio && project.sourcePath) {
    opts.onEvent('audio-analysis', 0.12, 'Checking local waveform and speaker cues (audio stays on this device)')
    try {
      const waveform = await buildWaveform(ctx, project, 600, 'source', opts.signal)
      audioSignals = {
        duration: waveform.duration,
        peaks: waveform.peaks,
        available: !waveform.silent && waveform.peaks.length > 0
      }
    } catch (error) {
      if (opts.signal.aborted) throw error
      ctx.logger.warn('analysis', 'audio-signals.unavailable', String(error))
      audioSignals = null
    }
  }

  let providerLabel: string
  let validated: ValidatedWithScores[] = []
  const rejected: string[] = []
  const auditOptions = { audio: audioSignals, engine: opts.providerId as ContentAnalysisEngineId, analyzedAt }

  if (opts.providerId === 'heuristic-local') {
    providerLabel = 'heuristic-local'
    const intelligent = runHeuristicAnalysis(segments, {
      minSeconds: durationRange.min,
      maxSeconds: durationRange.max,
      maxCandidates,
      intelligenceProfile: profile,
      audioSignals: audioSignals ?? undefined,
      engine: opts.providerId,
      analyzedAt,
      signal: opts.signal,
      onProgress: (progress) => opts.onEvent('discovering', 0.16 + progress * 0.56, 'Scanning transcript structure, topic coherence and candidate context')
    })
    validated = intelligent.map((candidate) => ({
      startTime: candidate.startTime,
      endTime: candidate.endTime,
      originalStartTime: candidate.intelligence?.originalStartTime,
      originalEndTime: candidate.intelligence?.originalEndTime,
      boundaryRationale: candidate.intelligence?.boundaryRationale,
      startSegmentId: candidate.startSegmentId,
      endSegmentId: candidate.endSegmentId,
      title: candidate.title,
      hook: candidate.hook,
      reason: candidate.reason,
      clipType: candidate.clipType,
      transcriptExcerpt: candidate.transcript?.trim() || excerptFor(segments, candidate.startSegmentId, candidate.endSegmentId),
      scores: candidate.scores,
      overallScore: candidate.overallScore,
      scoreExplanation: candidate.scoreExplanation,
      intelligence: candidate.intelligence ?? null
    }))
    opts.onEvent('scoring', 0.78, 'Scoring hook, context, structure, fit, payoff and available audio cues')
  } else {
    providerLabel = opts.providerId
    const discovered = await aiDiscovery(ctx, opts, segments, project, {
      minSeconds: durationRange.min,
      maxSeconds: durationRange.max,
      maxCandidates,
      preset,
      profile,
      targetDurationRange: { min: durationRange.min, max: durationRange.max }
    }, rejected)
    validated = annotateProviderCandidates(discovered, segments, profile, auditOptions)
  }

  if (validated.length === 0) {
    projectsRepo.setStatus(ctx.db, opts.projectId, 'analysis_failed', 'No valid candidates were produced')
    throw new AppError(
      'ANALYSIS_NO_CANDIDATES',
      'The analysis produced no valid clip candidates.',
      rejected.length
        ? `${rejected.length} raw candidates were rejected: ${rejected[0]}`
        : 'Try a different duration preset, a longer transcript, or a different analysis provider.'
    )
  }

  // Group overlapping alternatives with the user-selected duplicate sensitivity.
  opts.onEvent('deduplicating', 0.88, 'Removing overlapping duplicates and diversifying moments')
  const { moments, variationsGrouped } = dedupeCandidates(validated, duplicateOverlapThreshold(profile.duplicateSensitivity))
  const withMoments = assignMomentMetadata(moments, opts.projectId)
  const selectedMomentIndexes = diversifyMomentGroups(moments, maxCandidates, profile)
  const selectedKeys = new Set(selectedMomentIndexes.map((index) => `moment-${opts.projectId.slice(0, 8)}-${index}`))
  const selectedGroups = withMoments.filter((candidate) => selectedKeys.has(candidate.momentKey))
  const best = selectedGroups.filter((candidate) => candidate.rankInMoment === 0)
  const extras = selectedGroups
    .filter((candidate) => candidate.rankInMoment > 0)
    .slice(0, Math.max(0, maxCandidates - best.length))
  const finalCandidates = [...best, ...extras].sort((a, b) => a.startTime - b.startTime || a.rankInMoment - b.rankInMoment)

  // Persist
  const persisted = candidatesRepo.replaceForProject(ctx.db, opts.projectId, finalCandidates.map((c) => ({
    projectId: opts.projectId,
    startTime: c.startTime,
    endTime: c.endTime,
    startSegmentId: c.startSegmentId,
    endSegmentId: c.endSegmentId,
    title: c.title,
    hook: c.hook,
    transcriptExcerpt: c.transcriptExcerpt,
    reason: c.reason,
    clipType: c.clipType,
    scores: c.scores,
    overallScore: c.overallScore,
    scoreExplanation: c.scoreExplanation,
    intelligence: c.intelligence ?? null,
    provider: providerLabel,
    momentKey: c.momentKey,
    rankInMoment: c.rankInMoment,
    status: 'discovered' as const
  })))

  // Archive raw output for cache/debug
  try {
    const analysisDir = path.join(ctx.projectDir(opts.projectId), 'analysis')
    fs.mkdirSync(analysisDir, { recursive: true })
    fs.writeFileSync(path.join(analysisDir, `candidates-${providerLabel}.json`), JSON.stringify({
      run: { engine: opts.providerId, analyzerVersion: CONTENT_ANALYZER_VERSION, analyzedAt, profile, audioSignalsAvailable: Boolean(audioSignals?.available) },
      candidates: persisted
    }, null, 2))
  } catch {
    /* non-fatal */
  }

  projectsRepo.setStatus(ctx.db, opts.projectId, 'analyzed', null)
  const updated = projectsRepo.get(ctx.db, opts.projectId)
  if (updated) ctx.events.publish({ type: 'project:update', project: updated })

  const summary: AnalysisSummary = {
    foundMoments: moments.length,
    keptCandidates: persisted.length,
    variationsGrouped,
    rejected: rejected.length,
    provider: providerLabel
  }
  ctx.logger.info('analysis', 'done', `project=${opts.projectId} moments=${summary.foundMoments} kept=${summary.keptCandidates}`)
  return summary
}

function diversifyMomentGroups(
  moments: ValidatedWithScores[][],
  limit: number,
  profile: ContentIntelligenceProfile
): number[] {
  const available = moments.map((_, index) => index)
  const selected: number[] = []
  const typeCounts = new Map<string, number>()
  const categoryCounts = new Map<string, number>()
  const timeBuckets = new Set<number>()
  const firstTime = Math.min(...moments.map((group) => group[0]?.startTime ?? 0))
  const lastTime = Math.max(...moments.map((group) => group[0]?.endTime ?? 0))
  const bucketSize = Math.max(1, (lastTime - firstTime) / Math.max(1, limit))
  const getType = (index: number) => moments[index][0]?.intelligence?.momentTypeId ?? moments[index][0]?.clipType ?? 'other'
  const getCategory = (index: number) => moments[index][0]?.intelligence?.inferredCategoryId ?? 'general-mixed'

  while (selected.length < limit && available.length) {
    available.sort((a, b) => {
      const candidateA = moments[a][0]
      const candidateB = moments[b][0]
      const scoreA = candidateA?.overallScore ?? 0
      const scoreB = candidateB?.overallScore ?? 0
      const typeBonusA = (typeCounts.get(getType(a)) ?? 0) === 0 ? 6 : -Math.min(8, (typeCounts.get(getType(a)) ?? 0) * 2)
      const typeBonusB = (typeCounts.get(getType(b)) ?? 0) === 0 ? 6 : -Math.min(8, (typeCounts.get(getType(b)) ?? 0) * 2)
      const categoryBonusA = (categoryCounts.get(getCategory(a)) ?? 0) === 0 ? 3 : -2
      const categoryBonusB = (categoryCounts.get(getCategory(b)) ?? 0) === 0 ? 3 : -2
      const bucketA = Math.floor(((candidateA?.startTime ?? firstTime) - firstTime) / bucketSize)
      const bucketB = Math.floor(((candidateB?.startTime ?? firstTime) - firstTime) / bucketSize)
      const timeBonusA = timeBuckets.has(bucketA) ? -2 : 4
      const timeBonusB = timeBuckets.has(bucketB) ? -2 : 4
      const modeBoost = profile.discoveryMode === 'strict-quality' ? 0 : 1
      return scoreB + typeBonusB + categoryBonusB + timeBonusB + modeBoost - (scoreA + typeBonusA + categoryBonusA + timeBonusA + modeBoost)
    })
    const next = available.shift()!
    selected.push(next)
    const type = getType(next)
    const category = getCategory(next)
    typeCounts.set(type, (typeCounts.get(type) ?? 0) + 1)
    categoryCounts.set(category, (categoryCounts.get(category) ?? 0) + 1)
    const candidate = moments[next][0]
    const bucket = Math.floor(((candidate?.startTime ?? firstTime) - firstTime) / bucketSize)
    timeBuckets.add(bucket)
  }
  return selected.sort((a, b) => (moments[a][0]?.startTime ?? 0) - (moments[b][0]?.startTime ?? 0))
}

function chatProviderForAnalysis(providerId: AnalysisProviderId): 'anthropic' | 'local-ai-model' | 'openai-compatible' {
  if (providerId === 'anthropic') return 'anthropic'
  if (providerId === 'local-ai-model') return 'local-ai-model'
  return 'openai-compatible'
}

async function aiDiscovery(
  ctx: AppContext,
  opts: AnalysisOptions,
  segments: TranscriptSegment[],
  project: { name: string; duration: number | null },
  params: {
    minSeconds: number
    maxSeconds: number
    maxCandidates: number
    preset: string
    profile: ContentIntelligenceProfile
    targetDurationRange: { min: number; max: number }
  },
  rejections: string[]
): Promise<ValidatedWithScores[]> {
  const numbered = segments.map((s) => ({ id: s.id, start: s.startTime, end: s.endTime, text: s.text }))
  const selectedCategory = CONTENT_CATEGORIES.find((category) => category.id === params.profile.categoryId)!
  const selectedSubcategories = selectedCategory.subcategories
    .filter((subcategory) => params.profile.subcategoryIds.includes(subcategory.id))
    .map((subcategory) => subcategory.label)
  const selectedTypes = MOMENT_TYPES.filter((moment) => params.profile.momentTypeIds.includes(moment.id)).map((moment) => moment.label)
  const userPrompt = buildDiscoveryUserPrompt({
    segments: numbered,
    durationPreset: params.preset as 'short' | 'medium' | 'long' | 'mixed',
    minSeconds: params.minSeconds,
    maxSeconds: params.maxSeconds,
    maxCandidates: params.maxCandidates,
    sourceTitle: 'Transcript only — source filename withheld',
    sourceDurationSeconds: null,
    categoryLabel: selectedCategory.label,
    subcategoryLabels: selectedSubcategories,
    momentTypeLabels: selectedTypes,
    audienceLabel: AUDIENCES.find((audience) => audience.id === params.profile.audienceId)?.label ?? 'General',
    customAudience: params.profile.audienceId === 'custom' ? params.profile.customAudience : '',
    discoveryModeLabel: DISCOVERY_MODES.find((mode) => mode.id === params.profile.discoveryMode)?.label ?? 'Balanced',
    automaticDuration: params.profile.durationMode === 'automatic'
  })

  // --- Pass 1: discovery
  let raws: RawCandidate[] = []
  const maxRetries = 1
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    const system = attempt === 0 ? DISCOVERY_SYSTEM : `${DISCOVERY_SYSTEM}\n\nCRITICAL: Your previous response was not parseable JSON. Respond with ONLY the JSON object — no fences, no prose.`
    opts.onEvent('discovering', 0.2 + attempt * 0.15, attempt === 0 ? 'Asking the AI provider to find moments' : 'Model output was malformed — retrying with a stricter prompt')
    const raw = await chatComplete(
      ctx,
      chatProviderForAnalysis(opts.providerId),
      [
        { role: 'system', content: system },
        { role: 'user', content: userPrompt }
      ],
      { jsonMode: true, signal: opts.signal }
    )
    const parsed = extractJson<{ candidates?: RawCandidate[] }>(raw)
    const validatedResponse = rawCandidatesResponseSchema.safeParse(parsed)
    if (validatedResponse.success) {
      raws = validatedResponse.data.candidates
      break
    }
    if (attempt === maxRetries) {
      throw new AppError(
        'AI_RETURNED_INVALID_JSON',
        'The AI provider responded, but its candidate list could not be parsed.',
        'Retry the analysis, or switch to another provider/model in Settings → AI.',
        raw.slice(-800)
      )
    }
  }

  // --- Validate + convert to times
  const validCtx = {
    segments,
    sourceDuration: project.duration,
    durationPreset: params.preset as 'short' | 'medium' | 'long' | 'mixed',
    targetDurationRange: params.targetDurationRange
  }
  const validated: ValidatedWithScores[] = []
  for (const raw of raws) {
    const result = validateCandidate(raw, validCtx)
    if ('candidate' in result) {
      validated.push({ ...result.candidate, scores: null, overallScore: null, scoreExplanation: null })
    } else {
      // structurally impossible timestamps / bad ranges are dropped, not trusted
      rejections.push(result.rejection)
      ctx.logger.warn('analysis', 'candidate.rejected', result.rejection)
    }
  }
  if (validated.length === 0) {
    throw new AppError(
      'ANALYSIS_NO_VALID_CANDIDATES',
      'The AI returned candidates, but none referenced valid transcript segments.',
      'This can happen with very short transcripts. Try the local heuristic provider or a longer duration preset.'
    )
  }

  // --- Pass 2: audit scores
  opts.onEvent('scoring', 0.6, 'Auditing candidates')
  const scoringContext = validated.map((c, index) => ({
    index,
    title: c.title,
    excerpt: c.transcriptExcerpt,
    durationSeconds: c.endTime - c.startTime
  }))
  const scoringRaw = await chatComplete(
    ctx,
    chatProviderForAnalysis(opts.providerId),
    [
      { role: 'system', content: SCORING_SYSTEM },
      { role: 'user', content: buildScoringUserPrompt({ candidates: scoringContext }) }
    ],
    { jsonMode: true, signal: opts.signal }
  )
  const scoringParsed = extractJson<{ scores?: RawScores[] }>(scoringRaw)
  const scoringValidated = rawScoresResponseSchema.safeParse(scoringParsed)

  if (scoringValidated.success) {
    const byIndex = new Map(scoringValidated.data.scores.map((s) => [s.candidateIndex, s]))
    for (const [index, cand] of validated.entries()) {
      const s = byIndex.get(index)
      if (s) {
        const scores: ScoreBreakdown = {
          hook: clampScore(s.hook),
          contextCompleteness: clampScore(s.contextCompleteness),
          clarity: clampScore(s.clarity),
          retention: clampScore(s.retention),
          emotionalImpact: clampScore(s.emotionalImpact),
          standaloneValue: clampScore(s.standaloneValue),
          shareability: clampScore(s.shareability),
          visualSuitability: clampScore(s.visualSuitability)
        }
        cand.scores = scores
        cand.overallScore = aggregateScore(scores)
        cand.scoreExplanation = s.explanation || 'No explanation was provided by the model.'
      }
    }
  } else {
    // Scoring is optional-ish: candidates remain usable without audit numbers
    ctx.logger.warn('analysis', 'scoring.invalid', 'audit scores could not be parsed; candidates kept without scores')
  }

  return validated
}

// ------------------------------------------------------------- providers ----

export async function listAnalysisProviders(ctx: AppContext): Promise<ProviderAvailability[]> {
  const settings = getSettings(ctx)
  const localModelOk = isLocalAiEndpoint(settings.ai.openai.baseUrl) && Boolean(settings.ai.openai.model)
  const openaiOk = Boolean(settings.ai.openai.baseUrl && settings.ai.openai.model) && ctx.secrets.get('ai:openai-compatible') != null
  const anthropicOk = Boolean(settings.ai.anthropic.model) && ctx.secrets.get('ai:anthropic') != null
  return [
    {
      id: 'heuristic-local',
      label: 'Local heuristic analyzer',
      kind: 'analysis',
      available: true,
      configured: true,
      message: 'Always available offline. Uses transcript structure, discourse/context cues and available local waveform data; this is a deterministic heuristic, not a generative AI model.'
    },
    {
      id: 'local-ai-model',
      label: 'Optional Local AI Model',
      kind: 'analysis',
      available: localModelOk,
      configured: localModelOk,
      message: localModelOk
        ? 'Uses the configured loopback OpenAI-compatible model server. No API key is sent and the app does not download a model; the service must already be running.'
        : 'Requires an already installed OpenAI-compatible model server, a localhost/127.0.0.1 base URL, and a model name in Settings → AI. No API key or model download is required.',
      fixHint: 'Settings → AI (configure a local endpoint)'
    },
    {
      id: 'openai-compatible',
      label: 'OpenAI-compatible endpoint',
      kind: 'analysis',
      available: openaiOk,
      configured: openaiOk,
      message: openaiOk
        ? `Sends the transcript to ${settings.ai.openai.baseUrl} for semantic analysis.`
        : 'Requires base URL, model, and API key in Settings → AI.',
      fixHint: 'Settings → AI'
    },
    {
      id: 'anthropic',
      label: 'Anthropic (Claude)',
      kind: 'analysis',
      available: anthropicOk,
      configured: anthropicOk,
      message: anthropicOk
        ? 'Sends the transcript to api.anthropic.com for semantic analysis.'
        : 'Requires an Anthropic API key in Settings → AI.',
      fixHint: 'Settings → AI'
    }
  ]
}

export function getCandidates(ctx: AppContext, projectId: string): ClipCandidate[] {
  return candidatesRepo.listForProject(ctx.db, projectId)
}

export function updateCandidate(ctx: AppContext, id: string, patch: {
  status?: ClipCandidate['status']
  startTime?: number
  endTime?: number
}): ClipCandidate {
  let candidate = candidatesRepo.get(ctx.db, id)
  if (!candidate) throw new AppError('CANDIDATE_NOT_FOUND', 'That clip candidate no longer exists.')
  if (patch.startTime !== undefined || patch.endTime !== undefined) {
    const project = projectsRepo.get(ctx.db, candidate.projectId)
    if (!project) throw new AppError('PROJECT_NOT_FOUND', 'The project for this candidate no longer exists.')
    const startTime = patch.startTime ?? candidate.startTime
    const endTime = patch.endTime ?? candidate.endTime
    if (!(Number.isFinite(startTime) && Number.isFinite(endTime) && startTime >= 0 && endTime > startTime)) {
      throw new AppError('CANDIDATE_RANGE_INVALID', 'The candidate end must be after its start.', 'Enter a valid range in seconds.')
    }
    if (project.duration != null && endTime > project.duration + 0.5) {
      throw new AppError('CANDIDATE_RANGE_INVALID', 'The candidate end is past the source duration.')
    }
    const segments = segmentsRepo.listForProject(ctx.db, project.id)
    const covered = segments.filter((segment) => segment.endTime > startTime && segment.startTime < endTime)
    if (!covered.length) throw new AppError('CANDIDATE_RANGE_INVALID', 'The selected range contains no transcript segments.')
    const startSegment = covered[0]
    const endSegment = covered.at(-1)!
    const intelligence = candidate.intelligence ? {
      ...candidate.intelligence,
      boundaryRationale: `Manually adjusted to ${startTime.toFixed(1)}–${endTime.toFixed(1)}s. Original detected edges (${candidate.intelligence.originalStartTime.toFixed(1)}–${candidate.intelligence.originalEndTime.toFixed(1)}s) and prior score rationale are preserved for comparison.`
    } : null
    candidate = candidatesRepo.updateBoundary(ctx.db, id, {
      startTime,
      endTime,
      startSegmentId: startSegment.id,
      endSegmentId: endSegment.id,
      transcriptExcerpt: excerptFor(segments, startSegment.id, endSegment.id),
      intelligence
    }) ?? candidate
  }
  if (patch.status) {
    candidate = candidatesRepo.updateStatus(ctx.db, id, patch.status) ?? candidate
  }
  return candidate
}
