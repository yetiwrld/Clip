import fs from 'node:fs'
import path from 'node:path'
import { describe, expect, it } from 'vitest'

const editorPath = path.resolve(process.cwd(), 'src/renderer/features/editor/EditorPage.tsx')
const stylePath = path.resolve(process.cwd(), 'src/renderer/styles/global.css')
const editorSource = fs.readFileSync(editorPath, 'utf8')
const styleSource = fs.readFileSync(stylePath, 'utf8')

describe('editor workspace UI contract', () => {
  it('keeps navigation, preview, properties and the resizable timeline in the editor shell', () => {
    expect(editorSource).toContain('aria-label="Editor workflows"')
    expect(editorSource).toContain('className="editor-stage"')
    expect(editorSource).toContain('id="editor-inspector"')
    expect(editorSource).toContain('id="editor-timeline-content"')
    expect(editorSource).toContain('aria-valuenow={Math.round(timelineHeight)}')
    expect(editorSource).toContain('onKeyDown={resizeTimelineByKeyboard}')
    expect(editorSource).toContain("toolPanelCollapsed ? ' tools-collapsed' : ''")
    expect(editorSource).toContain("inspectorCollapsed ? ' inspector-collapsed' : ''")
  })

  it('lets the mobile inspector open when a desktop collapse preference is still set', () => {
    expect(styleSource).toContain('.editor-body.inspector-collapsed > .editor-inspector.mobile-open {\n    display: block;')
    expect(editorSource).toContain('if (window.matchMedia(\'(max-width: 680px)\').matches) {\n      setInspectorOpen((open) => !open)')
  })

  it('routes every inspector quick-jump choice to a real property section', () => {
    const jump = editorSource.match(/<div className="inspector-jump">([\s\S]*?)<\/div>/)?.[1]
    expect(jump).toBeDefined()
    const targets = [...jump!.matchAll(/<option value="([a-z]+)">/g)].map((match) => match[1])
    expect(targets).toEqual(['trim', 'silence', 'audio', 'crop', 'camera', 'captions', 'text', 'output', 'metadata'])
    for (const target of targets) expect(editorSource).toContain(`data-inspector-section="${target}"`)
  })

  it('retains the editor transport, trim and undo/redo keyboard shortcuts', () => {
    for (const shortcut of [
      "e.code === 'Space'",
      "e.key === 'j' || e.key === 'J'",
      "e.key === 'k' || e.key === 'K'",
      "e.key === 'l' || e.key === 'L'",
      "e.key === ','",
      "e.key === '.'",
      "e.key === 'i' || e.key === 'I'",
      "e.key === 'o' || e.key === 'O'",
      "e.key === 'Home'",
      "e.key === 'End'"
    ]) expect(editorSource).toContain(shortcut)
  })
})
