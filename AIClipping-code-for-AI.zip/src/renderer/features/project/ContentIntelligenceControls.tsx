import React from 'react'
import { Field, Switch } from '../../components/ui'
import {
  ANALYSIS_ENGINES,
  AUDIENCES,
  CONTENT_CATEGORIES,
  DISCOVERY_MODES,
  DURATION_CHOICES,
  MOMENT_TYPES,
  normalizeContentIntelligenceProfile,
  type ContentIntelligenceProfile,
  type DurationChoiceId,
  type MomentTypeId
} from '@shared/analysis/content-intelligence'

const PRESET_COUNTS = [5, 10, 15, 20]

export function ContentIntelligenceControls(props: {
  value: ContentIntelligenceProfile
  onChange: (profile: ContentIntelligenceProfile) => void
  showTuning?: boolean
  disabled?: boolean
}) {
  const profile = normalizeContentIntelligenceProfile(props.value)
  const category = CONTENT_CATEGORIES.find((item) => item.id === profile.categoryId) ?? CONTENT_CATEGORIES.at(-1)!

  function update(patch: Partial<ContentIntelligenceProfile>) {
    props.onChange(normalizeContentIntelligenceProfile({ ...profile, ...patch }))
  }

  function setDuration(selection: string) {
    if (selection === 'automatic') {
      update({ durationMode: 'automatic' })
    } else if (selection === 'custom') {
      update({ durationMode: 'custom' })
    } else {
      update({ durationMode: 'preset', durationPreset: selection as DurationChoiceId })
    }
  }

  function setCandidateCount(selection: string) {
    if (selection === 'custom') {
      update({ candidateCountMode: 'custom' })
    } else {
      update({ candidateCountMode: 'preset', requestedCandidates: Number(selection) })
    }
  }

  function toggleSubcategory(id: string) {
    const selected = profile.subcategoryIds.includes(id)
    update({ subcategoryIds: selected ? profile.subcategoryIds.filter((item) => item !== id) : [...profile.subcategoryIds, id] })
  }

  function toggleMomentType(id: MomentTypeId) {
    if (id === 'all-moments' || id === 'automatic-best') {
      update({ momentTypeIds: [id] })
      return
    }
    const explicit = profile.momentTypeIds.filter((item) => item !== 'all-moments' && item !== 'automatic-best')
    const next = explicit.includes(id) ? explicit.filter((item) => item !== id) : [...explicit, id]
    update({ momentTypeIds: next.length ? next : ['automatic-best'] })
  }

  const durationSelection = profile.durationMode === 'automatic'
    ? 'automatic'
    : profile.durationMode === 'custom'
      ? 'custom'
      : profile.durationPreset
  const countSelection = profile.candidateCountMode === 'custom' || !PRESET_COUNTS.includes(profile.requestedCandidates)
    ? 'custom'
    : String(profile.requestedCandidates)

  return (
    <div className="ci-controls stack sm">
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 12 }}>
        <Field label="Content category" hint="Category fit changes what is prioritized and how candidate scores are weighted.">
          <select className="select" disabled={props.disabled} value={profile.categoryId} onChange={(event) => update({ categoryId: event.target.value as ContentIntelligenceProfile['categoryId'], subcategoryIds: [] })}>
            {CONTENT_CATEGORIES.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}
          </select>
        </Field>
        <Field label="Optional subcategories" hint="Select any relevant themes; leave empty to use the full category.">
          <details className="ci-subcategory-details">
            <summary className="ci-subcategory-summary">
              {profile.subcategoryIds.length ? `${profile.subcategoryIds.length} selected` : 'Choose subcategories'}
            </summary>
            <div className="ci-choice-grid">
              {category.subcategories.map((item) => {
                const selected = profile.subcategoryIds.includes(item.id)
                return (
                  <button
                    key={item.id}
                    type="button"
                    className={`ci-choice ${selected ? 'selected' : ''}`}
                    aria-pressed={selected}
                    disabled={props.disabled}
                    onClick={() => toggleSubcategory(item.id)}
                  >
                    {item.label}
                  </button>
                )
              })}
            </div>
          </details>
        </Field>
      </div>

      <fieldset className="ci-fieldset">
        <legend className="field-label">Moment types <span className="tiny">· multi-select</span></legend>
        <div className="ci-choice-grid">
          {MOMENT_TYPES.map((item) => {
            const selected = profile.momentTypeIds.includes(item.id)
            return (
              <button
                key={item.id}
                type="button"
                className={`ci-choice ${selected ? 'selected' : ''} ${item.id === 'automatic-best' || item.id === 'all-moments' ? 'special' : ''}`}
                aria-pressed={selected}
                disabled={props.disabled}
                onClick={() => toggleMomentType(item.id)}
              >
                {item.label}
              </button>
            )
          })}
        </div>
        <div className="field-hint">“All Moments” leaves type unrestricted. “Automatically Select Best Moments” balances the strongest structures and diversifies the results.</div>
      </fieldset>

      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))', gap: 12 }}>
        <Field label="Target audience">
          <select className="select" disabled={props.disabled} value={profile.audienceId} onChange={(event) => update({ audienceId: event.target.value as ContentIntelligenceProfile['audienceId'] })}>
            {AUDIENCES.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}
          </select>
        </Field>
        <Field label="Recommended duration" hint={profile.durationMode === 'automatic' ? 'The analyzer chooses a suitable range from the story, explanation or exchange structure.' : 'Sentence completion may justify a small, explicitly explained overrun.'}>
          <select className="select" disabled={props.disabled} value={durationSelection} onChange={(event) => setDuration(event.target.value)}>
            <option value="automatic">Automatic recommendation</option>
            {DURATION_CHOICES.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}
            <option value="custom">Custom range…</option>
          </select>
        </Field>
        <Field label="Requested candidates">
          <select className="select" disabled={props.disabled} value={countSelection} onChange={(event) => setCandidateCount(event.target.value)}>
            {PRESET_COUNTS.map((count) => <option key={count} value={count}>{count} candidates</option>)}
            <option value="custom">Custom…</option>
          </select>
        </Field>
        <Field label="Discovery mode">
          <select className="select" disabled={props.disabled} value={profile.discoveryMode} onChange={(event) => update({ discoveryMode: event.target.value as ContentIntelligenceProfile['discoveryMode'] })}>
            {DISCOVERY_MODES.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}
          </select>
        </Field>
        <Field label="Analysis engine" hint={`${ANALYSIS_ENGINES.find((engine) => engine.id === profile.engine)?.description ?? 'Explicitly selected analysis engine.'} Cloud runs are never selected automatically.`}>
          <select className="select" disabled={props.disabled} value={profile.engine} onChange={(event) => update({ engine: event.target.value as ContentIntelligenceProfile['engine'] })}>
            {ANALYSIS_ENGINES.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}
          </select>
        </Field>
      </div>

      {profile.audienceId === 'custom' && (
        <Field label="Describe the audience" hint="This text is used as a local relevance hint. If a cloud engine is selected, the audience instruction is sent with the transcript request.">
          <input className="input" disabled={props.disabled} maxLength={80} value={profile.customAudience} onChange={(event) => update({ customAudience: event.target.value })} placeholder="e.g. first-time founders in West Africa" />
        </Field>
      )}

      {profile.durationMode === 'custom' && (
        <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 12 }}>
          <Field label="Minimum seconds">
            <input className="input" type="number" min={6} max={179} value={profile.customDurationMin} disabled={props.disabled} onChange={(event) => update({ customDurationMin: Number(event.target.value) })} />
          </Field>
          <Field label="Maximum seconds">
            <input className="input" type="number" min={7} max={180} value={profile.customDurationMax} disabled={props.disabled} onChange={(event) => update({ customDurationMax: Number(event.target.value) })} />
          </Field>
        </div>
      )}

      {countSelection === 'custom' && (
        <Field label="Candidate count" hint="Choose between 1 and 40 candidates. Existing clips and approvals are not removed when preferences change.">
          <input className="input" type="number" min={1} max={40} value={profile.requestedCandidates} disabled={props.disabled} onChange={(event) => update({ requestedCandidates: Number(event.target.value), candidateCountMode: 'custom' })} />
        </Field>
      )}

      {props.showTuning && (
        <>
          <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))', gap: 12 }}>
            <Field label="Discovery sensitivity" hint="Higher sensitivity is more selective, producing fewer candidates.">
              <select className="select" disabled={props.disabled} value={profile.sensitivity} onChange={(event) => update({ sensitivity: event.target.value as ContentIntelligenceProfile['sensitivity'] })}>
                <option value="low">Broad</option>
                <option value="balanced">Balanced</option>
                <option value="high">Selective</option>
              </select>
            </Field>
            <Field label="Duplicate sensitivity" hint="Higher sensitivity groups more similar or overlapping ranges together.">
              <select className="select" disabled={props.disabled} value={profile.duplicateSensitivity} onChange={(event) => update({ duplicateSensitivity: event.target.value as ContentIntelligenceProfile['duplicateSensitivity'] })}>
                <option value="low">Low · keep more variations</option>
                <option value="balanced">Balanced</option>
                <option value="high">High · group more overlaps</option>
              </select>
            </Field>
          </div>
          <Field label={`Minimum quality threshold · ${profile.minimumQualityScore}/100`} hint="Only candidates at or above the effective threshold are returned. Sensitivity and Strict Quality mode can raise or lower it.">
            <input className="range" type="range" min={20} max={90} step={1} disabled={props.disabled} value={profile.minimumQualityScore} onChange={(event) => update({ minimumQualityScore: Number(event.target.value) })} />
          </Field>
        </>
      )}

      <Switch
        checked={profile.useAudioSignals}
        disabled={props.disabled}
        onChange={(useAudioSignals) => update({ useAudioSignals })}
        label="Use available local audio signals"
        hint="When source audio exists, a cached FFmpeg waveform peak profile and transcript speaker turns can support the audit. Raw audio is not sent to cloud analysis."
      />
    </div>
  )
}
