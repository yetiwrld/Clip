# Release Checklist — Clipwright Studio

Run before every release. Automated gates marked *(this QA)* were verified
on 2026-10-02 for v0.0.1. The Windows Actions build is complete; a clean-machine
installer acceptance is still required before calling it fully release-tested.

## 1. Automated gates

- [x] `npm ci` — clean, 0 vulnerabilities *(this QA)*
- [x] `npm run typecheck` — clean *(this QA)*
- [x] `npm run fixtures` — generates test media *(this QA)*
- [x] `npm test` — 276/276 (183 unit + 93 integration) *(this QA)*
- [x] `npm run build` — clean *(this QA)*

## 2. Packaging (Windows runner/machine required)

- [x] v0.0.1 Windows Actions run 36948924824 completes and uploads `Clipwright-Studio-Windows-x64-unsigned`
- [x] `npm run dist:win` completes on the Windows runner (the script installs Electron before building)
- [x] `dist/Clipwright Studio-0.0.1-setup-x64.exe` produced and artifact uploaded
- [ ] Installer installs and launches on a clean Windows 11 x64 machine without Node/npm
- [ ] Confirm the expected unsigned-publisher/SmartScreen behavior; no signing certificate is configured
- [ ] First-run welcome guide appears with three workflow steps; optional setup check shows bundled FFmpeg/FFprobe OK
- [ ] Bundled caption fonts render in preview and output
- [ ] Uninstaller removes the app (user data kept by design)

## 3. Smoke test on the packaged app (Windows)

- [ ] Create project → import a real long video → plays in preview
- [ ] Transcript import (SRT) or local Whisper transcription
- [ ] Heuristic analysis works offline (network off)
- [ ] Provider configured → Test connection → success with latency
- [ ] AI analysis → moments with audit scores → create clip
- [ ] Open an existing clip in the editor; stage loads without blanking,
      including while switching between clips and after a failed load
- [ ] Editor: trim/captions/crop/metadata changes persist after app restart
- [ ] UI pass: preview is prominent at desktop/narrow widths; timeline fit/zoom,
      snap, drag/trim, split, duplicate, delete, locks and track menu respond
- [ ] Add a timed image/video overlay; verify preview and exported position,
      opacity, start, and end match
- [ ] Verify preview/export audio parity for source + timeline audio,
      speed, item/track mute, volume, and fade-in/fade-out
- [ ] Render 9:16 → output plays, correct aspect; render 4:5 → 1080×1350
- [ ] Export produces mp4 + metadata files; Reveal folder opens Explorer
- [ ] Settings → Storage & privacy lists preview caches; remove a proxy/cache and confirm it can regenerate
- [ ] Confirm cleanup leaves original/imported media, transcripts, completed renders, exports and diagnostic JSON intact
- [ ] Cancel a running render; retry a failed one; interrupted tasks resume
      only with explicit user action
- [ ] Delete a project (with confirmation) while its import runs → app survives
- [ ] API key never visible in UI/logs/diagnostics export

## 4. GonkaRouter / provider acceptance (with a real key)

- [ ] Base URL `https://api.gonkarouter.io/v1`, key pasted in Settings → AI
- [ ] Test connection → "Connection successful — model responded correctly"
- [ ] Model ID with `/` accepted verbatim (e.g. `zai-org/GLM-5.3-Flash`)
- [ ] If gateway rejects `response_format`: analysis still succeeds (auto
      fallback), or JSON mode disabled manually
- [ ] If 401 with Bearer: switch **API key header** to `x-api-key` → success
- [ ] Full AI workflow: analyze → audit scores → clip → generate metadata

## 5. Release hygiene

- [x] Version bumped in `package.json` to v0.0.1
- [x] `docs/CHANGELOG.md` updated
- [x] `docs/TEST_RESULTS.md` updated with the v0.0.1 build and test results
- [ ] No secrets/keys in the repo (`git grep -E "sk-[A-Za-z0-9]|gk-"` clean)
- [x] No generated fixtures or compiled build output included in the source archive
- [ ] Tag the release commit
