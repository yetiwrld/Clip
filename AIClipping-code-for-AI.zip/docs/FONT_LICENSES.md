﻿# Bundled caption font licenses

The application bundles these font files for caption preview and export. They are distributed under the SIL Open Font License 1.1 (OFL-1.1), which permits use, modification, and redistribution subject to the license terms. The license text is included beside each font family.

| Family | Included files | License text | Source |
|---|---|---|---|
| Inter | `Inter_400Regular.ttf`, `Inter_600SemiBold.ttf`, `Inter_700Bold.ttf`, `Inter_800ExtraBold.ttf`, `Inter_900Black.ttf` | `resources/fonts/OFL.txt` | [Google Fonts Inter](https://github.com/google/fonts/tree/main/ofl/inter) |
| IBM Plex Sans Condensed | Regular, Medium, Semibold, Bold | `resources/fonts/IBM-Plex-OFL.txt` | [Google Fonts IBM Plex Sans Condensed](https://github.com/google/fonts/tree/main/ofl/ibmplexsanscondensed) |
| Source Serif 4 | Variable font, with regular, semibold and bold weights exposed | `resources/fonts/Source-Serif-OFL.txt` | [Google Fonts Source Serif 4](https://github.com/google/fonts/tree/main/ofl/sourceserif4) |

Inter and IBM Plex use distinct static font files for each listed weight. Source Serif 4 is a variable font and the editor only offers named weights supported by its weight axis. Font metadata used by the editor is defined in `src/shared/constants/index.ts`.
