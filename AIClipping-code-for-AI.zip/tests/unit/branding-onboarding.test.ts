import fs from 'node:fs'
import path from 'node:path'
import { describe, expect, it } from 'vitest'

const root = process.cwd()
const read = (filePath: string) => fs.readFileSync(path.join(root, filePath), 'utf8')

describe('Clipwright v0.0.1 branding and first-run welcome', () => {
  it('keeps the application and lockfile version aligned at 0.0.1', () => {
    const pkg = JSON.parse(read('package.json')) as { version: string }
    const lock = JSON.parse(read('package-lock.json')) as {
      version: string
      packages: { '': { version: string } }
    }

    expect(pkg.version).toBe('0.0.1')
    expect(lock.version).toBe(pkg.version)
    expect(lock.packages[''].version).toBe(pkg.version)
  })

  it('uses the Clipwright mark in the app shell, welcome guide, and desktop window', () => {
    const app = read('src/renderer/App.tsx')
    const welcome = read('src/renderer/features/onboarding/FirstRunModal.tsx')
    const main = read('src/main/index.ts')

    expect(fs.existsSync(path.join(root, 'src/renderer/public/clipwright-logo.png'))).toBe(true)
    expect(app).toContain('src="./clipwright-logo.png"')
    expect(welcome).toContain('src="./clipwright-logo.png"')
    expect(main).toContain("'clipwright-logo.png'")
    expect(app).toContain('Developed by yetiwrld')
  })

  it('explains the core workflow in three steps and preserves optional setup checks', () => {
    const welcome = read('src/renderer/features/onboarding/FirstRunModal.tsx')

    expect(welcome.match(/className="welcome-step"/g)).toHaveLength(3)
    expect(welcome).toContain('Import a video')
    expect(welcome).toContain('Find the moments')
    expect(welcome).toContain('Edit and export')
    expect(welcome).toContain('Check setup')
    expect(welcome).toContain('Start creating')
  })
})
