#!/usr/bin/env bash
# Rebuild a working REA install with a Ghidra provider in a Debian/Ubuntu sandbox.
# Everything heavy goes to /var/tmp (NOT /tmp -- that is a small tmpfs here).
# Run: bash setup.sh
set -euo pipefail

RT=/var/tmp/rt
NODE_VER=24.22.1
GHIDRA_BUILD=Ghidra_12.1.4_build
GHIDRA_ZIP=ghidra_12.1.4_PUBLIC_20260921.zip

mkdir -p "$RT"

# ---------- 1. Node (REA needs ^22.23.4 || ^24.22.1 || >=26.12.1) ----------
if [ ! -x "$RT/node24/bin/node" ]; then
  echo "==> Node $NODE_VER"
  curl -sSL -o "$RT/n.tar.xz" "https://nodejs.org/dist/v$NODE_VER/node-v$NODE_VER-linux-x64.tar.xz"
  tar -xf "$RT/n.tar.xz" -C "$RT"
  mv "$RT/node-v$NODE_VER-linux-x64" "$RT/node24"
  rm "$RT/n.tar.xz"
fi
export PATH="$RT/node24/bin:$PATH"
node -v

# ---------- 2. JDK 21 (Ghidra 12.1.x requires 21; system java is often 11) ----------
if [ ! -x "$RT/jdk21/bin/java" ]; then
  echo "==> Temurin JDK 21"
  curl -sSL -o "$RT/jdk21.tar.gz" \
    "https://api.adoptium.net/v3/binary/latest/21/ga/linux/x64/jdk/hotspot/normal/eclipse"
  mkdir -p "$RT/jdk21"
  tar -xzf "$RT/jdk21.tar.gz" -C "$RT/jdk21" --strip-components=1
  rm "$RT/jdk21.tar.gz"
fi
export JAVA_HOME="$RT/jdk21"

# ---------- 3. Ghidra 12.1.x ----------
if [ ! -d "$RT/ghidra_12.1.4_PUBLIC" ]; then
  echo "==> Ghidra 12.1.4 (570 MB download, 876 MB extracted)"
  curl -sSL -o "$RT/ghidra.zip" \
    "https://github.com/NationalSecurityAgency/ghidra/releases/download/$GHIDRA_BUILD/$GHIDRA_ZIP"
  ( cd "$RT" && unzip -q ghidra.zip && rm ghidra.zip )
fi
export GHIDRA_INSTALL_DIR="$RT/ghidra_12.1.4_PUBLIC"

# ---------- 3b. Chromium for website analysis ----------
export PLAYWRIGHT_BROWSERS_PATH="$RT/pw"
if [ ! -d "$RT/pw/chromium-1248" ]; then
  echo "==> Chromium (Playwright build) + system deps"
  npx --yes playwright@latest install chromium
  sudo -n env PATH="$RT/node24/bin:$PATH" npx --yes playwright@latest install-deps chromium || \
    echo "   (install-deps failed; Chromium may need libnspr4/libnss3 manually)"
fi

# ---------- 4. REA ----------
echo "==> rea-agents"
npm install -g rea-agents --no-fund --no-audit

# ---------- 5. Verify ----------
export HOME="$RT/home"; mkdir -p "$HOME"
echo
echo "==> rea doctor"
rea doctor | head -40

cat <<'EOF'

Ready. Export these in every shell that will run rea:

  export PATH=/var/tmp/rt/node24/bin:$PATH
  export JAVA_HOME=/var/tmp/rt/jdk21
  export GHIDRA_INSTALL_DIR=/var/tmp/rt/ghidra_12.1.4_PUBLIC
  export PLAYWRIGHT_BROWSERS_PATH=/var/tmp/rt/pw

Quick smoke test (no engine needed):

  rea inspect-go-binary <some-go-binary> --format json

Website analysis (start the browser first):

  /var/tmp/rt/pw/chromium-1248/chrome-linux64/chrome --headless=new --no-sandbox \
    --disable-gpu --disable-dev-shm-usage --remote-debugging-port=9222 \
    --user-data-dir=/var/tmp/rt/chrome-profile about:blank &

  T=$(curl -sX PUT "http://127.0.0.1:9222/json/new?https://example.com" | python3 -c "import json,sys;print(json.load(sys.stdin)['id'])")
  rea list-browser-targets http://127.0.0.1:9222
  rea analyze-web-bundle http://127.0.0.1:9222 "$T" --format json

With an engine:

  rea analyze ./target --format md
  rea decompile-all ./target --output ./out
  rea decompile ./target 0x4011c0 --format json
EOF
